"""
СИМУЛЯЦИЯ: карта/враги/башни/волны + среда TDEnv (маски, награды).

Собран склейкой файлов: sim, env
"""
from __future__ import annotations

from .data import BOSS_ENEMY_ID, BUILD, CHANCE_CRITICAL_DAMAGE, CRITICAL_DAMAGE_MULTIPLIER, DT, ENEMY_TYPES_DATA, IDLE, LAST_ACTIONS_HISTORY, LOG_DAMAGE_CAP, LOG_DPS_CAP, LOG_HP_CAP, LOG_KILLS_CAP, MAX_BUILDS_PER_WAVE, MAX_ENEMIES, MAX_TARGETS_PER_TOWER, MAX_TOWERS, MAX_TOWER_LEVEL, REGULAR_ENEMY_IDS, SELL, STRENGTHENING_ENEMIES, STRENGTHENING_ENEMIES_DOP, STRENGTHENING_MONEY, TOTAL_TOWER_TYPES, TOWER_TYPES_DATA, TowerType, UPGRADE, WAVE_AUTO_START_DELAY, WAVE_DURATION, compute_deck_meta, compute_map_meta

# ============================================================================
# СЕКЦИЯ: sim.py
# ============================================================================
import math
import random
from collections import deque
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np


# ============================================================================
# ЛЕГЕНДА КАРТЫ
# ============================================================================
CELL_EMPTY = 0
CELL_ROAD = 1
CELL_OBSTACLE = 2


# ============================================================================
# СИМУЛЯТОР КАРТЫ
# ============================================================================
class MapSimulator:
    """Извлекает путь, считает расстояния до дороги, проверяет клетки."""

    def __init__(self, map_matrix: np.ndarray):
        self.map = np.array(map_matrix, dtype=np.int32)
        self.height, self.width = self.map.shape
        self.path: List[Tuple[int, int]] = self._extract_path()
        self._path_index: Dict[Tuple[int, int], int] = {
            cell: i for i, cell in enumerate(self.path)
        }
        self._road_dist = self._compute_road_distance()
        self.path_x = np.array([p[0] for p in self.path], dtype=np.float32)
        self.path_y = np.array([p[1] for p in self.path], dtype=np.float32)

    # ---------------- путь ----------------
    def _road_neighbors(self, x: int, y: int) -> List[Tuple[int, int]]:
        out = []
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.height and 0 <= ny < self.width and self.map[nx, ny] == CELL_ROAD:
                out.append((nx, ny))
        return out

    def _components(self, road_cells: List[Tuple[int, int]]) -> List[List[Tuple[int, int]]]:
        """Компоненты связности дороги (по 4-соседству)."""
        road_set = set(road_cells)
        seen: set = set()
        comps: List[List[Tuple[int, int]]] = []
        for cell in road_cells:
            if cell in seen:
                continue
            comp = []
            q = deque([cell])
            seen.add(cell)
            while q:
                cur = q.popleft()
                comp.append(cur)
                for nb in self._road_neighbors(*cur):
                    if nb in road_set and nb not in seen:
                        seen.add(nb)
                        q.append(nb)
            comps.append(comp)
        return comps

    def _bfs(self, start: Tuple[int, int], allowed: set):
        dist = {start: 0}
        prev: Dict[Tuple[int, int], Optional[Tuple[int, int]]] = {start: None}
        q = deque([start])
        while q:
            cur = q.popleft()
            for nb in self._road_neighbors(*cur):
                if nb in allowed and nb not in dist:
                    dist[nb] = dist[cur] + 1
                    prev[nb] = cur
                    q.append(nb)
        return dist, prev

    def _extract_path(self) -> List[Tuple[int, int]]:
        """
        Строит ОДИН непрерывный путь: диаметр самой большой связной компоненты
        дороги (BFS от концевой клетки до самой удалённой концевой клетки).

        Важно: раньше «недостижимые» куски дороги дописывались в конец пути —
        на картах с развилками (например map_05) враги телепортировались между
        несвязанными участками. Теперь путь всегда непрерывный, а боковые
        ответвления остаются просто дорогой (они видны в признаках карты и в
        покрытии башен).
        """
        road_cells = [(int(x), int(y)) for x, y in np.argwhere(self.map == CELL_ROAD)]
        if not road_cells:
            return []

        # самая большая компонента (детерминированно: при равенстве — меньший индекс)
        comps = self._components(road_cells)
        comps.sort(key=lambda c: (-len(c), min(x * self.width + y for x, y in c)))
        allowed = set(comps[0])

        endpoints = [c for c in allowed if len(self._road_neighbors(*c)) <= 1]
        candidates = endpoints if endpoints else sorted(allowed)

        # от первой концевой клетки (минимальный линейный индекс) — BFS
        start = min(candidates, key=lambda c: c[0] * self.width + c[1])
        dist, prev = self._bfs(start, allowed)

        # самая удалённая достижимая клетка (при равенстве — меньший индекс)
        target = max(dist.keys(), key=lambda c: (dist[c], -c[0] * self.width - c[1]))

        path: List[Tuple[int, int]] = []
        cur: Optional[Tuple[int, int]] = target
        while cur is not None:
            path.append(cur)
            cur = prev[cur]
        path.reverse()
        return path

    # ---------------- расстояния до дороги ----------------
    def _compute_road_distance(self) -> np.ndarray:
        """Многоисточниковый BFS: манхэттенское расстояние до ближайшей клетки дороги."""
        INF = 10 ** 6
        dist = np.full((self.height, self.width), INF, dtype=np.int32)
        q = deque()
        for x, y in self.path:
            dist[x, y] = 0
            q.append((x, y))
        while q:
            cx, cy = q.popleft()
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nx, ny = cx + dx, cy + dy
                if 0 <= nx < self.height and 0 <= ny < self.width:
                    if dist[nx, ny] > dist[cx, cy] + 1:
                        dist[nx, ny] = dist[cx, cy] + 1
                        q.append((nx, ny))
        dist[dist >= INF] = 999
        return dist

    # ---------------- запросы ----------------
    def is_buildable(self, x: int, y: int) -> bool:
        return (0 <= x < self.height and 0 <= y < self.width and self.map[x, y] == CELL_EMPTY)

    def get_distance_to_road(self, x: int, y: int) -> int:
        if not (0 <= x < self.height and 0 <= y < self.width):
            return 999
        return int(self._road_dist[x, y])

    def get_path_index(self, x: int, y: int) -> int:
        if not self.path:
            return 0
        best_i, best_d = 0, 1e18
        for i, (px, py) in enumerate(self.path):
            d = (px - x) ** 2 + (py - y) ** 2
            if d < best_d:
                best_d, best_i = d, i
        return best_i

    def road_coverage(self, x: int, y: int, radius: float) -> int:
        """Сколько клеток дороги попадает в радиус (в клетках)."""
        if len(self.path_x) == 0:
            return 0
        r2 = radius * radius
        dx = self.path_x - x
        dy = self.path_y - y
        return int(np.count_nonzero(dx * dx + dy * dy <= r2))


# ============================================================================
# HP / НАГРАДА ВРАГА (формулы игры, БАЛАНС ЗАМОРОЖЕН)
# ============================================================================
def enemy_hp_multiplier(wave_number: int) -> float:
    return 1.0 + max(0.0, wave_number * (STRENGTHENING_ENEMIES +
                                         STRENGTHENING_ENEMIES_DOP * wave_number))


def enemy_reward_multiplier(wave_number: int) -> float:
    return 1.0 + wave_number * STRENGTHENING_MONEY


# ============================================================================
# ГЕНЕРАТОР ВОЛН (логика Godot: 20 сек, интервалы 0.1..1.0, босс в конце)
# ============================================================================
class WaveGenerator:
    WAVE_DURATION = WAVE_DURATION

    @staticmethod
    def generate_wave(wave_number: int, rng: Optional[random.Random] = None) -> List[Dict]:
        rng = rng or random
        enemies: List[Dict] = []
        remaining_time = WaveGenerator.WAVE_DURATION
        min_spawn_delay = 0.1

        ids = REGULAR_ENEMY_IDS
        weights = [1.0 - (i / (len(ids) + 1.0)) for i in ids]

        while remaining_time > 0:
            enemy_id = rng.choices(ids, weights=weights, k=1)[0]
            max_delay = min(1.0, remaining_time)
            if remaining_time < min_spawn_delay:
                delay = remaining_time
            else:
                delay = round(rng.uniform(min_spawn_delay, max_delay), 1)
            enemies.append({"type": ENEMY_TYPES_DATA[enemy_id], "delay": float(delay)})
            remaining_time -= delay

        enemies.append({"type": ENEMY_TYPES_DATA[BOSS_ENEMY_ID], "delay": 2.0})
        return enemies


# ============================================================================
# МЕНЕДЖЕР ВРАГОВ (SoA)
# ============================================================================
class EnemyManager:
    """Враги в виде Structure-of-Arrays: быстро и без аллокаций на каждом шаге."""

    def __init__(self, path: List[Tuple[int, int]], max_enemies: int = MAX_ENEMIES):
        self.path = path
        self.path_length = len(path)
        self.max_enemies = max_enemies
        n = max_enemies

        self.hp = np.zeros(n, dtype=np.float32)
        self.max_hp = np.zeros(n, dtype=np.float32)
        self.speed = np.zeros(n, dtype=np.float32)
        self.cell_index = np.zeros(n, dtype=np.int32)
        self.progress = np.zeros(n, dtype=np.float32)
        self.reward = np.zeros(n, dtype=np.float32)
        self.base_damage = np.ones(n, dtype=np.int32)

        self.slow_until = np.zeros(n, dtype=np.float32)
        self.slow_intensity = np.zeros(n, dtype=np.float32)
        self.poison_damage = np.zeros(n, dtype=np.float32)
        self.poison_timer = np.zeros(n, dtype=np.float32)

        self.pos_x = np.zeros(n, dtype=np.float32)
        self.pos_y = np.zeros(n, dtype=np.float32)

        self.path_x = (np.array([p[0] for p in path], dtype=np.float32)
                       if path else np.zeros(0, dtype=np.float32))
        self.path_y = (np.array([p[1] for p in path], dtype=np.float32)
                       if path else np.zeros(0, dtype=np.float32))

        self.count = 0
        self.spawned_total = 0

    # ---------------- lifecycle ----------------
    def reset(self):
        self.count = 0
        self.spawned_total = 0
        self.hp.fill(0.0)

    def add_enemy(self, enemy_type, wave_number: int, difficulty: float = 1.0):
        if self.count >= self.max_enemies or not self.path:
            return
        i = self.count
        hp = enemy_type.base_hp * enemy_hp_multiplier(wave_number) * difficulty
        self.hp[i] = hp
        self.max_hp[i] = hp
        self.speed[i] = enemy_type.speed_cells
        self.cell_index[i] = 0
        self.progress[i] = 0.0
        self.reward[i] = enemy_type.reward * enemy_reward_multiplier(wave_number)
        self.base_damage[i] = 1
        self.slow_until[i] = 0.0
        self.slow_intensity[i] = 0.0
        self.poison_damage[i] = 0.0
        self.poison_timer[i] = 0.0
        self.pos_x[i] = self.path_x[0]
        self.pos_y[i] = self.path_y[0]
        self.count += 1
        self.spawned_total += 1

    # ---------------- update ----------------
    def update_all(self, dt: float, current_time: float):
        if self.count == 0 or self.path_length == 0:
            return
        n = self.count
        hp = self.hp[:n]
        poison_timer = self.poison_timer[:n]
        poison_dmg = self.poison_damage[:n]

        # яд
        poisoned = poison_timer > 0
        if poisoned.any():
            hp[poisoned] -= poison_dmg[poisoned] * dt
            poison_timer[poisoned] -= dt
            killed_timer = poison_timer <= 0
            poison_dmg[killed_timer] = 0.0

        # скорость с учётом замедления
        slow_mult = np.ones(n, dtype=np.float32)
        slowed = current_time < self.slow_until[:n]
        if slowed.any():
            slow_mult[slowed] = np.maximum(
                0.3, 1.0 - self.slow_intensity[:n][slowed] / 100.0
            )

        self.progress[:n] += self.speed[:n] * slow_mult * dt

        # продвижение по клеткам
        last = self.path_length - 1
        for i in range(n):
            while self.progress[i] >= 1.0 and self.cell_index[i] < last:
                self.cell_index[i] += 1
                self.progress[i] -= 1.0

        # мировые координаты
        idx = self.cell_index[:n]
        prog = self.progress[:n]
        at_end = idx >= last
        idx_safe = np.minimum(idx, last - 1) if last > 0 else idx
        if last > 0:
            x0 = self.path_x[idx_safe]
            x1 = self.path_x[idx_safe + 1]
            y0 = self.path_y[idx_safe]
            y1 = self.path_y[idx_safe + 1]
            self.pos_x[:n] = np.where(at_end, self.path_x[-1], x0 + (x1 - x0) * prog)
            self.pos_y[:n] = np.where(at_end, self.path_y[-1], y0 + (y1 - y0) * prog)
        else:
            self.pos_x[:n] = self.path_x[0]
            self.pos_y[:n] = self.path_y[0]

    # ---------------- эффекты ----------------
    def apply_damage(self, idx: int, damage: float):
        if 0 <= idx < self.count:
            self.hp[idx] -= damage

    def apply_slow(self, idx: int, intensity: float, duration: float, current_time: float):
        if 0 <= idx < self.count:
            new_end = current_time + duration
            if new_end > self.slow_until[idx] or intensity > self.slow_intensity[idx]:
                self.slow_until[idx] = new_end
                self.slow_intensity[idx] = max(self.slow_intensity[idx], intensity)

    def apply_poison(self, idx: int, dps: float, duration: float):
        if 0 <= idx < self.count:
            self.poison_damage[idx] += dps
            self.poison_timer[idx] = max(self.poison_timer[idx], duration)

    def push_back(self, idx: int, distance_percent: float) -> float:
        """Отбрасывает врага по пути на % длины пути. Возвращает фактический откат (клетки)."""
        if not (0 <= idx < self.count) or self.path_length == 0:
            return 0.0
        before = float(self.cell_index[idx]) + float(self.progress[idx])
        cells_back = (distance_percent / 100.0) * self.path_length
        self.progress[idx] -= cells_back
        while self.progress[idx] < 0 and self.cell_index[idx] > 0:
            self.cell_index[idx] -= 1
            self.progress[idx] += 1.0
        if self.cell_index[idx] <= 0:
            self.cell_index[idx] = 0
            self.progress[idx] = max(0.0, self.progress[idx])
        after = float(self.cell_index[idx]) + float(self.progress[idx])
        return max(0.0, before - after)

    # ---------------- павшие / дошедшие ----------------
    def remove_dead_and_finished(self) -> Tuple[float, int, int]:
        """Возвращает (заработанные деньги, убийства, урон базе)."""
        if self.count == 0:
            return 0.0, 0, 0

        money = 0.0
        kills = 0
        leaks = 0
        write = 0
        last = self.path_length - 1

        for read in range(self.count):
            if self.hp[read] <= 0.0:
                money += float(self.reward[read])
                kills += 1
                continue
            if self.cell_index[read] >= last:
                leaks += int(self.base_damage[read])
                continue
            if write != read:
                for arr in (self.hp, self.max_hp, self.speed, self.cell_index,
                            self.progress, self.reward, self.base_damage,
                            self.slow_until, self.slow_intensity,
                            self.poison_damage, self.poison_timer,
                            self.pos_x, self.pos_y):
                    arr[write] = arr[read]
            write += 1

        self.count = write
        return money, kills, leaks

    # ---------------- выбор целей ----------------
    def find_targets_in_range(self, x: float, y: float, tower_range: float,
                              max_targets: int = MAX_TARGETS_PER_TOWER) -> np.ndarray:
        """Индексы врагов в радиусе, отсортированные по прогрессу (сначала лидеры)."""
        if self.count == 0:
            return np.zeros(0, dtype=np.int32)

        n = self.count
        dx = self.pos_x[:n] - x
        dy = self.pos_y[:n] - y
        dist2 = dx * dx + dy * dy
        mask = (dist2 <= tower_range * tower_range) & (self.hp[:n] > 0)
        idx = np.nonzero(mask)[0]
        if idx.size == 0:
            return np.zeros(0, dtype=np.int32)

        prog = self.cell_index[idx].astype(np.float32) + self.progress[idx]
        order = np.argsort(-prog, kind="stable")
        idx = idx[order][:max_targets]
        return idx.astype(np.int32)

    def alive_mask(self) -> np.ndarray:
        return self.hp[:self.count] > 0


# ============================================================================
# БАШНЯ (конкретная постройка)
# ============================================================================
class Tower:
    def __init__(self, tower_type: TowerType, x: int, y: int, level: int = 0,
                 tower_id: int = -1, rng: Optional[random.Random] = None):
        self.type = tower_type
        self.x = int(x)
        self.y = int(y)
        self.level = int(level)
        self.tower_id = tower_id

        self.last_attack_time = -999.0
        self.drone_last_attack_time = -999.0
        self.total_damage = 0.0
        self.link_bonus = 0.0
        self.kills = 0

        self._rng = rng or random
        self.crit_chance = CHANCE_CRITICAL_DAMAGE
        self.crit_mult = CRITICAL_DAMAGE_MULTIPLIER

    # ---------------- характеристики ----------------
    def get_damage(self, level: int = -1) -> float:
        lv = self.level if level == -1 else level
        return self.type.get_damage(lv) * (1.0 + self.link_bonus)

    def get_rof(self, level: int = -1) -> float:
        lv = self.level if level == -1 else level
        return max(0.05, self.type.get_rof(lv))

    def get_range(self, level: int = -1) -> float:
        lv = self.level if level == -1 else level
        return self.type.get_range(lv)

    def get_dps(self, level: int = -1) -> float:
        lv = self.level if level == -1 else level
        if self.type.is_income:
            return self.type.get_val(self.type.p1, lv)
        return self.get_damage(lv) / max(0.1, self.get_rof(lv))

    def get_upgrade_cost(self) -> float:
        return self.type.get_upgrade_cost(self.level)

    def get_income(self) -> float:
        return self.type.get_val(self.type.p1, self.level) if self.type.is_income else 0.0

    def can_upgrade(self, max_level: int) -> bool:
        return self.level < max_level

    def upgrade(self, max_level: int) -> bool:
        if self.level < max_level:
            self.level += 1
            return True
        return False

    def roll_crit(self, dmg: float) -> float:
        if self._rng.random() < self.crit_chance:
            return dmg * self.crit_mult
        return dmg

    # ---------------- link buff ----------------
    def apply_link_bonus_to_neighbors(self, all_towers: List["Tower"]):
        if not self.type.is_link:
            return
        link_range = self.get_range()
        bonus = self.type.get_val(self.type.p1, self.level)
        for other in all_towers:
            if other is self or other.type.is_link or other.type.is_income:
                continue
            dist = math.hypot(self.x - other.x, self.y - other.y)
            if dist <= link_range:
                other.link_bonus = max(other.link_bonus, bonus)

    def __repr__(self) -> str:  # pragma: no cover
        return f"Tower({self.type.name}@{self.x},{self.y} lvl{self.level})"


# ============================================================================
# АТАКИ БАШЕН
# ============================================================================
@dataclass
class AttackResult:
    damage: float = 0.0        # реальный урон по HP (для статистики и кредитов)
    kills: int = 0
    leaked_damage_score: float = 0.0


CROSSBOW_CYCLE_MULT = 2.41     # из игры (данные, не баланс RL)
CROSSBOW_ROF_OVERRIDE = 0.283  # из игры
TRAP_EXTRA_CHANCE = 0.65       # из игры
MAX_SHOTS_PER_TICK = 50


def _shots_ready(tower: Tower, current_time: float, rof: float) -> int:
    if tower.last_attack_time < -900:
        tower.last_attack_time = current_time - rof
    elapsed = current_time - tower.last_attack_time
    if elapsed < rof:
        return 0
    shots = int(elapsed / rof)
    tower.last_attack_time += shots * max(rof, 1e-6)
    return min(shots, MAX_SHOTS_PER_TICK)


def resolve_attack(tower: Tower, dt: float, current_time: float,
                   em: EnemyManager) -> float:
    """
    Один «тик» атаки башни. Возвращает нанесённый реальный урон.

    Каждый тип башни обрабатывается ровно ОДИН раз (в старой версии push/slow
    начисляли скор дважды — это был баг, а не баланс).
    """
    tt = tower.type
    if tt.is_income or tt.is_link:
        return 0.0
    if em.count == 0:
        return 0.0

    damage_done = 0.0

    # ---------- дроны: отдельный глобальный таймер ----------
    if tt.is_drone:
        drone_rof = max(0.05, tt.get_val(tt.p5, tower.level))
        if tower.drone_last_attack_time < -900:
            tower.drone_last_attack_time = current_time - drone_rof
        elapsed_d = current_time - tower.drone_last_attack_time
        if elapsed_d >= drone_rof:
            drone_shots = min(int(elapsed_d / drone_rof), MAX_SHOTS_PER_TICK)
            tower.drone_last_attack_time += drone_shots * drone_rof
            order = em.find_targets_in_range(0.0, 0.0, 10 ** 6)  # глобальный радиус
            if order.size > 0:
                drone_dmg = tt.get_val(tt.p4, tower.level) * (1.0 + tower.link_bonus)
                pair = {int(order[0]), int(order[-1])}  # лидер и самый отставший
                for _ in range(drone_shots):
                    for idx in pair:
                        if em.hp[idx] > 0:
                            d = tower.roll_crit(drone_dmg)
                            em.apply_damage(idx, d)
                            damage_done += d

    # ---------- собственная стрельба башни ----------
    rof = tower.get_rof()
    if tt.is_crossbow:
        rof = CROSSBOW_ROF_OVERRIDE

    shots = _shots_ready(tower, current_time, rof)
    if shots == 0:
        tower.total_damage += damage_done
        return damage_done

    targets = em.find_targets_in_range(tower.x, tower.y, tower.get_range())
    if targets.size == 0:
        tower.total_damage += damage_done
        return damage_done

    base_dmg = tower.get_damage()
    ptr = 0

    for _ in range(shots):
        # пропускаем мёртвых
        while ptr < targets.size and em.hp[targets[ptr]] <= 0:
            ptr += 1
        if ptr >= targets.size:
            break
        idx = int(targets[ptr])

        if tt.is_aoe:
            count = int(tt.get_special_1(tower.level)) or 1
            hit = targets[ptr: ptr + count]
            for t_idx in hit:
                t_idx = int(t_idx)
                if em.hp[t_idx] > 0:
                    d = tower.roll_crit(base_dmg)
                    em.apply_damage(t_idx, d)
                    damage_done += d

        elif tt.is_crossbow:
            d = tower.roll_crit(base_dmg * CROSSBOW_CYCLE_MULT)
            em.apply_damage(idx, d)
            damage_done += d

        elif tt.is_slow:
            intensity = tt.get_val(tt.p1, tower.level)
            duration = tt.get_val(tt.p4, tower.level)
            for t_idx in targets:
                t_idx = int(t_idx)
                if em.hp[t_idx] > 0:
                    em.apply_slow(t_idx, intensity, duration, current_time)

        elif tt.is_push:
            em.push_back(idx, tt.get_val(tt.p1, tower.level))
            ptr += 1

        elif tt.is_poison:
            d = tower.roll_crit(base_dmg)
            em.apply_damage(idx, d)
            damage_done += d
            duration = tt.get_val(tt.p4, tower.level)
            tick = max(0.1, tt.get_val(tt.p5, tower.level))
            em.apply_poison(idx, (base_dmg * 0.5) / tick, duration)

        elif tt.is_trap:
            d = tower.roll_crit(base_dmg)
            em.apply_damage(idx, d)
            damage_done += d
            if tower._rng.random() < TRAP_EXTRA_CHANCE:
                extra = tt.get_val(tt.p4, tower.level)
                em.apply_damage(idx, extra)
                damage_done += extra

        elif tt.is_execute:
            thresh = tt.get_val(tt.p4, tower.level) / 100.0
            hp_ratio = em.hp[idx] / max(1.0, float(em.max_hp[idx]))
            if hp_ratio <= thresh:
                kill_dmg = float(em.hp[idx])
                em.hp[idx] = 0.0
                damage_done += kill_dmg
            else:
                d = tower.roll_crit(base_dmg)
                em.apply_damage(idx, d)
                damage_done += d

        else:  # Gun / Billy / прочие одиночные
            d = tower.roll_crit(base_dmg)
            em.apply_damage(idx, d)
            damage_done += d

        if em.hp[idx] <= 0:
            ptr += 1

    tower.total_damage += damage_done
    return damage_done

# ============================================================================
# СЕКЦИЯ: env.py
# ============================================================================
import math
import random
from collections import deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np



# ============================================================================
# КОНФИГ
# ============================================================================
@dataclass
class EnvConfig:
    deck_size: int = 4
    max_tower_level: int = MAX_TOWER_LEVEL
    max_waves: int = 80
    starting_money: float = 500.0
    starting_hp: int = 10
    max_towers_on_map: int = MAX_TOWERS
    max_combat_towers: int = MAX_TOWERS
    max_builds_per_wave: int = MAX_BUILDS_PER_WAVE
    enable_sell: bool = False
    sell_refund_ratio: float = 0.5     # используется ТОЛЬКО при enable_sell=True
    max_decisions_between_waves: int = 20
    # Масштаб ЭВРИСТИЧЕСКОГО шейпинга (бонусы за расстановку/синергии).
    # 1.0 = как раньше, 0.3 = основной сигнал — волны/урон, эвристика приглушена.
    # Баланс игры (статы башен/врагов, усиление волн) НЕ затрагивается.
    shaping_scale: float = 0.3

    def __post_init__(self):
        assert 1 <= self.deck_size <= 8, "deck_size должен быть в диапазоне 1..8"


@dataclass
class RewardComponents:
    dps: float = 0.0
    support: float = 0.0
    economy: float = 0.0
    wave: float = 0.0
    penalty: float = 0.0
    strategic: float = 0.0

    def as_array(self) -> np.ndarray:
        return np.array([self.dps, self.support, self.economy,
                         self.wave, self.penalty, self.strategic], dtype=np.float32)

    def reset(self):
        self.dps = self.support = self.economy = 0.0
        self.wave = self.penalty = self.strategic = 0.0


# ============================================================================
# СРЕДА
# ============================================================================
class TDEnv:
    """Среда TD с явным тройным пространством действий."""

    def __init__(self, map_matrix: np.ndarray, config: Optional[EnvConfig] = None,
                 deck: Optional[List[int]] = None, difficulty: float = 1.0,
                 seed: Optional[int] = None):
        self.config = config or EnvConfig()
        self.map_matrix = np.array(map_matrix, dtype=np.int32)
        self.H, self.W = self.map_matrix.shape
        self.num_positions = self.H * self.W
        self.map_sim = MapSimulator(self.map_matrix)
        self.difficulty = float(difficulty)

        self._rng = random.Random(seed)
        self.np_rng = np.random.default_rng(seed)

        if deck is None:
            deck = list(range(self.config.deck_size))
        self.set_deck(deck)

        self._coverage_cache: Dict[int, np.ndarray] = {}
        self._precompute_position_quality()
        self._map_meta = compute_map_meta(self.map_matrix, self.map_sim.path)
        self._max_tower_cost = max(TOWER_TYPES_DATA[t].cost for t in self.deck)
        self._init_state()

    # ---------------------------------------------------------------- deck/map
    def set_deck(self, deck: List[int]):
        """Колода 1..8 слотов. Размер колоды синхронизируется с config."""
        deck = [int(t) for t in deck]
        assert 1 <= len(deck) <= 8, f"deck_size должен быть 1..8, получено {len(deck)}"
        self.config.deck_size = len(deck)
        for t in deck:
            assert t in TOWER_TYPES_DATA, f"неизвестный id башни {t}"
        self.deck = deck
        self.deck_set = set(deck)
        self._deck_meta = compute_deck_meta(self.deck)
        self._max_tower_cost = max(TOWER_TYPES_DATA[t].cost for t in self.deck)
        if hasattr(self, "towers_by_type"):
            self.towers_by_type = {tid: self.towers_by_type.get(tid, 0) for tid in deck}

    def set_map(self, map_matrix: np.ndarray):
        self.map_matrix = np.array(map_matrix, dtype=np.int32)
        self.H, self.W = self.map_matrix.shape
        self.num_positions = self.H * self.W
        self.map_sim = MapSimulator(self.map_matrix)
        self._coverage_cache = {}
        self._precompute_position_quality()
        self._map_meta = compute_map_meta(self.map_matrix, self.map_sim.path)
        self._init_state()

    def set_max_waves(self, max_waves: int):
        """Меняет лимит волн в эпизоде на ходу (расписание сложности, НЕ баланс)."""
        self.config.max_waves = max(1, int(max_waves))

    def set_difficulty(self, difficulty: float, starting_money: Optional[float] = None):
        self.difficulty = float(difficulty)
        if starting_money is not None:
            self.config.starting_money = float(starting_money)
        self._init_state()

    # ---------------------------------------------------------------- helpers
    def node_to_xy(self, node_idx: int) -> Tuple[int, int]:
        return divmod(int(node_idx), self.W)

    def xy_to_node(self, x: int, y: int) -> int:
        return int(x) * self.W + int(y)

    def _precompute_position_quality(self):
        """Оценка качества клетки для reward shaping (не часть баланса)."""
        self._position_quality = np.zeros((self.H, self.W), dtype=np.float32)
        path = self.map_sim.path
        if not path:
            return
        center_x, center_y = self.H / 2.0, self.W / 2.0
        bends = []
        for i in range(1, len(path) - 1):
            prev_dir = (path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1])
            next_dir = (path[i + 1][0] - path[i][0], path[i + 1][1] - path[i][1])
            if prev_dir != next_dir:
                bends.append(path[i])

        for x in range(self.H):
            for y in range(self.W):
                if self.map_matrix[x, y] != CELL_EMPTY:
                    continue
                cov = self.map_sim.road_coverage(x, y, 4.0)
                center_bonus = max(0.0, 5.0 - math.hypot(x - center_x, y - center_y))
                bend_bonus = 0.0
                for bx, by in bends:
                    d = math.hypot(x - bx, y - by)
                    if d <= 3.0:
                        bend_bonus += 2.0 / max(1.0, d)
                self._position_quality[x, y] = min(
                    1.0, (cov + bend_bonus * 2.0 + center_bonus) / 25.0)

    # ---------------------------------------------------------------- state
    def _init_state(self):
        self.money = float(self.config.starting_money)
        self.base_hp = int(self.config.starting_hp)
        self.towers: List[Tower] = []
        self.tower_map: Dict[Tuple[int, int], Tower] = {}
        self._next_tower_id = 0
        self.enemy_manager = EnemyManager(self.map_sim.path)

        self.current_wave = 0
        self.wave_index = 0
        self.spawn_timer = 0.0
        self.wave_data: List[Dict] = []
        self.wave_active = False
        self.wave_end_timer = 0.0
        self._last_avg_level = 0.0
        self.time = 0.0
        self.dt = DT
        self.step_count = 0
        self.done = False

        self.builds_this_wave = 0
        self.total_kills = 0
        self.total_damage = 0.0
        self.total_upgrades = 0
        self.total_sells = 0
        self.money_earned = 0.0
        self.money_spent = 0.0

        self.towers_by_type = {tid: 0 for tid in self.deck}
        self.action_stats = {"idle": 0, "build": 0, "upgrade": 0, "sell": 0}
        self.consecutive_idles = 0

        self.reward_components = RewardComponents()
        self.last_actions: deque = deque([IDLE] * LAST_ACTIONS_HISTORY,
                                        maxlen=LAST_ACTIONS_HISTORY)
        self._current_wave_max_hp = 500.0

        # кредиты (вклад башен в результат)
        self.step_tower_damage: Dict[int, float] = {}
        self.step_income: Dict[int, float] = {}
        self.tower_lifetime_credits: Dict[int, float] = {}

    def reset(self) -> Dict:
        self._init_state()
        return self._build_info(success=False)

    # ---------------------------------------------------------------- limits
    def _dynamic_total_limit(self) -> int:
        if self.current_wave <= 10:
            return min(25, self.config.max_towers_on_map)
        if self.current_wave <= 20:
            return min(35, self.config.max_towers_on_map)
        return self.config.max_towers_on_map

    def _is_special_tower(self, tid: int) -> bool:
        return TOWER_TYPES_DATA[tid].is_global_placement

    def _tower_at(self, x: int, y: int) -> Optional[Tower]:
        return self.tower_map.get((int(x), int(y)))

    # ---------------------------------------------------------------- masks
    def can_pay(self, amount: float) -> bool:
        return self.money >= amount

    def type_mask(self) -> np.ndarray:
        """[4] bool: какие типы действий допустимы ПРЯМО СЕЙЧАС."""
        mask = np.zeros(4, dtype=bool)
        mask[IDLE] = True
        mask[BUILD] = bool(self._any_build_possible())
        mask[UPGRADE] = bool(self._any_upgrade_possible())
        mask[SELL] = bool(self.config.enable_sell and len(self.towers) > 0)
        return mask

    def _any_build_possible(self) -> bool:
        if self.builds_this_wave >= self.config.max_builds_per_wave:
            return False
        if len(self.towers) >= self._dynamic_total_limit():
            return False
        if self._l0_blocked():
            return False
        for slot in range(len(self.deck)):
            if self._build_slot_mask(slot).any():
                return True
        return False

    def _l0_blocked(self) -> bool:
        """Анти-спам: не даём строить 6+ башен нулевого уровня."""
        if len(self.towers) < 8:
            return False
        l0 = sum(1 for t in self.towers
                 if t.level == 0 and not t.type.is_income)
        return l0 >= 5

    def base_buildable_mask(self) -> np.ndarray:
        """[N] bool: пустые клетки без башен (без учёта денег/покрытия)."""
        mask = (self.map_matrix.flatten() == CELL_EMPTY)
        for (x, y) in self.tower_map:
            mask[x * self.W + y] = False
        return mask

    def _build_slot_mask(self, slot: int) -> np.ndarray:
        """[N] bool: куда можно поставить башню из слота `slot`."""
        base = self.base_buildable_mask()
        N = self.num_positions
        out = np.zeros(N, dtype=bool)
        if slot < 0 or slot >= len(self.deck):
            return out
        tid = self.deck[slot]
        tt = TOWER_TYPES_DATA[tid]

        if self.builds_this_wave >= self.config.max_builds_per_wave:
            return out
        if len(self.towers) >= self._dynamic_total_limit():
            return out
        if self.money < tt.cost:
            return out

        # income-лимиты
        if tt.is_income and self.current_wave < 10 and self.towers_by_type.get(tid, 0) >= 3:
            return out

        # первая башня должна быть боевой (правило игры)
        if len(self.towers) == 0 and tt.is_support:
            return out

        # боевые башни: лимит и покрытие дороги
        if not tt.is_global_placement:
            combat = sum(1 for t in self.towers if not self._is_special_tower(t.type.id))
            if combat >= self.config.max_combat_towers:
                return out
            return base & self._coverage_mask(tt.get_range(0))

        # income / drone — можно ставить где угодно на пустой клетке
        return base

    def _coverage_mask(self, radius: float) -> np.ndarray:
        """[N] bool: клетки, покрывающие хотя бы одну клетку дороги. Кэшируется."""
        key = round(float(radius) * 64.0)   # кэш по пиксельному радиусу
        cached = self._coverage_cache.get(key)
        if cached is not None:
            return cached
        px, py = self.map_sim.path_x, self.map_sim.path_y
        N = self.num_positions
        if px.size == 0:
            out = np.zeros(N, dtype=bool)
        else:
            xs = np.repeat(np.arange(self.H, dtype=np.float32), self.W)
            ys = np.tile(np.arange(self.W, dtype=np.float32), self.H)
            r2 = float(radius) ** 2
            covered = np.zeros(N, dtype=bool)
            for k in range(px.size):
                covered |= (xs - px[k]) ** 2 + (ys - py[k]) ** 2 <= r2
            out = covered
        self._coverage_cache[key] = out
        return out

    def build_mask_matrix(self) -> np.ndarray:
        """[N, deck_size] bool — маска постройки для каждого слота колоды."""
        N = self.num_positions
        out = np.zeros((N, len(self.deck)), dtype=bool)
        if self.builds_this_wave >= self.config.max_builds_per_wave:
            return out
        if len(self.towers) >= self._dynamic_total_limit():
            return out
        for slot in range(len(self.deck)):
            out[:, slot] = self._build_slot_mask(slot)
        return out

    def upgrade_mask(self) -> np.ndarray:
        """[N] bool — где можно улучшить башню."""
        mask = np.zeros(self.num_positions, dtype=bool)
        for (x, y), t in self.tower_map.items():
            if t.level < self.config.max_tower_level and self.money >= t.get_upgrade_cost():
                mask[x * self.W + y] = True
        return mask

    def sell_mask(self) -> np.ndarray:
        """[N] bool — где можно продать башню (только при enable_sell)."""
        mask = np.zeros(self.num_positions, dtype=bool)
        if not self.config.enable_sell:
            return mask
        for (x, y) in self.tower_map:
            mask[x * self.W + y] = True
        return mask

    def node_mask(self, action_type: int, slot: int = 0) -> np.ndarray:
        """Логическая маска узлов под конкретное действие."""
        if action_type == BUILD:
            return self._build_slot_mask(slot)
        if action_type == UPGRADE:
            return self.upgrade_mask()
        if action_type == SELL:
            return self.sell_mask()
        return np.ones(self.num_positions, dtype=bool)

    def _any_upgrade_possible(self) -> bool:
        if self.config.max_tower_level <= 0:
            return False
        return any(t.level < self.config.max_tower_level and self.money >= t.get_upgrade_cost()
                   for t in self.towers)

    # ---------------------------------------------------------------- actions
    def _do_build(self, slot: int, node: int, info: Dict) -> float:
        x, y = self.node_to_xy(node)
        if slot < 0 or slot >= len(self.deck):
            return self._invalid(info)
        tid = self.deck[slot]
        tt = TOWER_TYPES_DATA[tid]
        if not self._build_slot_mask(slot)[node]:
            return self._invalid(info)

        # страховка: первая башня должна быть боевой
        if len(self.towers) == 0 and tt.is_support:
            info["rejected"] = "first_tower_must_be_dps"
            return self._invalid(info, amount=-3.0)

        self.money -= tt.cost
        self.money_spent += tt.cost
        tower = Tower(tt, x, y, level=0, tower_id=self._next_tower_id, rng=self._rng)
        self._next_tower_id += 1
        self.towers.append(tower)
        self.tower_map[(x, y)] = tower
        self.builds_this_wave += 1
        self.towers_by_type[tid] = self.towers_by_type.get(tid, 0) + 1
        self.action_stats["build"] += 1
        info["success"] = True
        info["action_type"] = "build"

        return self._build_reward(tower, x, y)

    def _build_reward(self, tower: Tower, x: int, y: int) -> float:
        tt = tower.type
        r = 0.0
        coverage = self.map_sim.road_coverage(x, y, tt.get_range(0))
        quality = float(self._position_quality[x, y])

        is_support = tt.is_support
        nearby = [t for t in self.towers if t is not tower
                  and not t.type.is_support]
        nearby_dps = [t for t in nearby
                      if math.hypot(t.x - x, t.y - y) <= 4.0]
        nearby_dps_dps = sum(t.get_dps() for t in nearby_dps)

        # первая башня типа
        if self.towers_by_type.get(tt.id, 0) == 1:
            r += 1.0
        # milestones
        if len(self.towers) in (5, 10, 15, 20):
            r += 1.0
        if is_support and nearby_dps:
            coverage_score = min(coverage * 0.1, 1.0)
        elif is_support:
            coverage_score = 0.0
        else:
            coverage_score = min(coverage * 0.1, 1.0)
        r += coverage_score
        r += quality * 0.5

        support_reward = 0.0
        strat = 0.0

        if tt.is_slow or tt.is_push:
            if not nearby_dps:
                support_reward -= 3.0
            elif len(nearby_dps) == 1:
                support_reward += 0.1 + min(nearby_dps_dps * 0.001, 0.5)
            else:
                support_reward += 0.3 + min(nearby_dps_dps * 0.001, 1.0)
            existing_cc = sum(1 for t in self.towers if t.type.is_slow or t.type.is_push)
            if existing_cc > 3:
                support_reward -= 0.5
            if self._count_towers_in_radius(x, y, 3.0, "CC") > 1:
                strat -= 1.0
            else:
                strat += 0.3

        elif tt.is_income:
            has_dps = any(not t.type.is_support for t in self.towers)
            if not has_dps:
                support_reward -= 3.0
            elif self.current_wave < 5:
                support_reward += 0.5
            if self.current_wave < 5:
                strat += 1.0
            elif self.current_wave > 20:
                strat -= 0.5

        elif tt.is_link:
            link_range = tt.get_range(0)
            near = [t for t in self.towers
                    if t is not tower and not t.type.is_support
                    and math.hypot(t.x - x, t.y - y) <= link_range]
            if not near:
                support_reward -= 2.0
            else:
                support_reward += len(near) * 0.2

        # универсальные стратегические бонусы
        if not tt.is_link and self._count_towers_in_radius(x, y, 2.0, "LINK") > 0:
            strat += 0.3
        if tt.is_aoe and self._count_towers_in_radius(x, y, 3.0, "CC") > 0:
            strat += 0.5
        if (tt.is_aoe or tt.is_drone) and quality > 0.7:
            strat += 0.5
        strat = float(np.clip(strat, -1.0, 1.5))

        # первая башня
        if len(self.towers) == 1:
            r += 0.0 if is_support else 5.0

        # если боевых башен >=5, а средний уровень низкий — штраф за расширение
        combat = [t for t in self.towers if not t.type.is_income]
        if len(combat) >= 5:
            avg_lvl = float(np.mean([t.level for t in combat]))
            if avg_lvl < 2.0 and not is_support:
                r -= 0.5

        scale = float(self.config.shaping_scale)
        support_reward *= scale
        strat_used = strat * scale
        r += support_reward
        r += strat_used
        strat = strat_used
        if is_support:
            self.reward_components.support += support_reward
        else:
            self.reward_components.dps += (coverage_score + quality * 0.5)
        self.reward_components.strategic += strat
        return r * 0.5

    def _do_upgrade(self, node: int, info: Dict) -> float:
        x, y = self.node_to_xy(node)
        tower = self._tower_at(x, y)
        if tower is None or tower.level >= self.config.max_tower_level:
            return self._invalid(info)
        cost = tower.get_upgrade_cost()
        if self.money < cost:
            return self._invalid(info)

        old_dps = tower.get_dps()
        self.money -= cost
        self.money_spent += cost
        tower.upgrade(self.config.max_tower_level)
        self.total_upgrades += 1
        self.action_stats["upgrade"] += 1
        info["success"] = True
        info["action_type"] = "upgrade"

        new_dps = tower.get_dps()
        dps_inc = max(0.0, new_dps - old_dps)
        r = float(np.log1p(dps_inc) * 0.2)
        if tower.level >= 5:
            r += tower.level * 0.1
        best_dmg = max((t.total_damage for t in self.towers), default=0.0)
        if tower.total_damage >= best_dmg and best_dmg > 0:
            r += 0.5

        strat = 0.0
        if tower.type.is_aoe and self._position_quality[x, y] > 0.6:
            strat += 0.5
        if tower.type.is_execute and (self.map_sim.get_path_index(x, y) /
                                      max(1, len(self.map_sim.path))) > 0.6:
            strat += 0.5
        strat += 0.3 * self._count_towers_in_radius(x, y, 2.0, "LINK")
        if tower.level - 1 == 0:
            strat += 0.3
        r += min(strat, 1.5) * float(self.config.shaping_scale)
        r *= 0.3

        if tower.level >= 7:
            r += 2.0
        elif tower.level >= 5:
            r += 0.5

        if tower.type.is_support:
            self.reward_components.support += r
        else:
            self.reward_components.dps += r
        self.reward_components.strategic += strat
        return r

    def _do_sell(self, node: int, info: Dict) -> float:
        """SELL доступен только при config.enable_sell=True."""
        if not self.config.enable_sell:
            return self._invalid(info)
        x, y = self.node_to_xy(node)
        tower = self.tower_map.get((x, y))
        if tower is None:
            return self._invalid(info)

        refund = tower.type.cost * float(self.config.sell_refund_ratio)
        del self.tower_map[(x, y)]
        self.towers.remove(tower)
        self.money += refund
        self.money_earned += refund
        self.total_sells += 1
        self.towers_by_type[tower.type.id] = max(
            0, self.towers_by_type.get(tower.type.id, 1) - 1)
        self.action_stats["sell"] += 1
        info["success"] = True
        info["action_type"] = "sell"
        # продажа — почти всегда вынужденная мера: маленький штраф за потерю вложений
        r = -0.2
        self.reward_components.penalty += r
        return r

    def _invalid(self, info: Dict, amount: float = -0.1) -> float:
        info["success"] = False
        info["invalid"] = True
        self.reward_components.penalty += amount
        return amount

    def _count_towers_in_radius(self, x: int, y: int, radius: float, role: str) -> int:
        count = 0
        for t in self.towers:
            if math.hypot(t.x - x, t.y - y) > radius:
                continue
            if role == "ANY":
                count += 1
            elif role == "CC" and (t.type.is_slow or t.type.is_push):
                count += 1
            elif role == "LINK" and t.type.is_link:
                count += 1
            elif role == "AOE" and t.type.is_aoe:
                count += 1
        return count

    # ---------------------------------------------------------------- waves
    def _start_next_wave(self):
        if self.current_wave >= self.config.max_waves:
            return
        self.current_wave += 1
        self.wave_data = WaveGenerator.generate_wave(self.current_wave, self._rng)
        self.wave_index = 0
        self.spawn_timer = 0.0
        self.wave_active = True
        self.builds_this_wave = 0
        self.wave_end_timer = 0.0

        max_base_hp = max(e.base_hp for e in ENEMY_TYPES_DATA.values())
        self._current_wave_max_hp = (max_base_hp *
                                     enemy_hp_multiplier(self.current_wave) *
                                     self.difficulty)

    def _spawn_enemies(self):
        """Спавн с `while`, чтобы не терять врагов при dt=1.0."""
        if not self.wave_active:
            return
        self.spawn_timer -= self.dt
        while self.spawn_timer <= 0 and self.wave_index < len(self.wave_data):
            data = self.wave_data[self.wave_index]
            self.enemy_manager.add_enemy(data["type"], self.current_wave, self.difficulty)
            self.wave_index += 1
            if self.wave_index < len(self.wave_data):
                self.spawn_timer += self.wave_data[self.wave_index]["delay"]
            else:
                self.wave_active = False
                break

    def _wave_reward(self) -> float:
        """
        Награда за пройденную волну (исправлено: раньше при наличии
        income-башни возвращался 0 и терялась вся награда).
        """
        base = 2.0 * (1.0 + self.current_wave / 5.0)
        if self.base_hp >= self.config.starting_hp:
            base += 2.0
        elif self.base_hp >= self.config.starting_hp * 0.5:
            base += 1.0

        total_spent = sum(t.type.cost for t in self.towers)
        if total_spent > 0 and self.total_damage > 0:
            base += min((self.total_damage / total_spent) * 0.01, 1.0)

        # бонус за работающие саппорты
        support_bonus = 0.0
        for tower in self.towers:
            if not (tower.type.is_slow or tower.type.is_push):
                continue
            cc_range = tower.get_range()
            for other in self.towers:
                if other is tower or other.type.is_support:
                    continue
                if math.hypot(tower.x - other.x, tower.y - other.y) <= cc_range + other.get_range():
                    support_bonus += 0.3 * (1.0 + self.current_wave * 0.05)
                    break
        support_bonus = min(support_bonus, 2.0) * float(self.config.shaping_scale)
        base += support_bonus

        # топ-3 по урону
        top_bonus = 0.0
        if self.towers:
            dmg_sorted = sorted(self.towers, key=lambda t: t.total_damage, reverse=True)[:3]
            for i, _ in enumerate(dmg_sorted):
                top_bonus += 0.5 * (3 - i)
            top_bonus *= float(self.config.shaping_scale)

        self.reward_components.support += support_bonus
        self.reward_components.strategic += top_bonus
        self.reward_components.wave += base
        return base + top_bonus

    # ---------------------------------------------------------------- combat
    def _reset_step_tracking(self):
        self.step_tower_damage = {}
        self.step_income = {}
        self.reward_components.reset()

    def _simulate_tick(self) -> float:
        """Один тик: враги, баффы, атаки, доход, смерти, спавн. Возвращает reward."""
        reward = 0.0

        self.enemy_manager.update_all(self.dt, self.time)

        for t in self.towers:
            t.link_bonus = 0.0
        for t in self.towers:
            if t.type.is_link:
                t.apply_link_bonus_to_neighbors(self.towers)

        tick_damage = 0.0
        for idx, tower in enumerate(self.towers):
            dmg = resolve_attack(tower, self.dt, self.time, self.enemy_manager)
            tick_damage += dmg
            if dmg > 0:
                self.step_tower_damage[idx] = self.step_tower_damage.get(idx, 0.0) + dmg

            if tower.type.is_income and (self.time - tower.last_attack_time) >= tower.get_rof():
                income = tower.get_income()
                self.money += income
                self.money_earned += income
                tower.last_attack_time = self.time
                self.step_income[idx] = self.step_income.get(idx, 0.0) + income
                self.reward_components.economy += income * 0.01

        self.total_damage += tick_damage

        earned, kills, leaks = self.enemy_manager.remove_dead_and_finished()
        self.money += earned
        self.money_earned += earned
        self.total_kills += kills
        if leaks:
            self.base_hp -= leaks
            r = -leaks * 5.0
            reward += r
            self.reward_components.penalty += r
        if kills:
            r = float(np.log1p(kills) * 0.05)
            reward += r
            self.reward_components.dps += r

        self._spawn_enemies()
        self.time += self.dt

        return reward

    # ---------------------------------------------------------------- step
    def step(self, action_type: int, deck_slot: int = 0, node_idx: int = 0):
        """
        Один шаг: действие игрока + 1 секунда симуляции.
        Возвращает (reward, done, info).
        """
        assert not self.done, "step() после done — нужен reset()"
        self.step_count += 1
        self._reset_step_tracking()
        info: Dict = {"action_type": "idle", "success": False, "result": ""}

        action_type = int(action_type)
        deck_slot = int(deck_slot)
        node_idx = int(node_idx)

        # --- валидация типа действия ---
        tmask = self.type_mask()
        if action_type < 0 or action_type >= 4 or not tmask[action_type]:
            if action_type == SELL and not self.config.enable_sell:
                info["masked_by_enable_sell"] = True
            reward = self._invalid(info)
            info["fallback_idle"] = True
            action_type = IDLE
        else:
            reward = 0.0

        # --- выполнение ---
        if action_type == IDLE:
            self.action_stats["idle"] += 1
            info["action_type"] = "idle"
            self.consecutive_idles += 1
            reward += self._idle_penalty()
        elif action_type == BUILD:
            reward += self._do_build(deck_slot, node_idx, info)
            if info.get("success"):
                self.consecutive_idles = 0
            else:
                self.consecutive_idles += 1
        elif action_type == UPGRADE:
            reward += self._do_upgrade(node_idx, info)
            if info.get("success"):
                self.consecutive_idles = 0
            else:
                self.consecutive_idles += 1
        elif action_type == SELL:
            reward += self._do_sell(node_idx, info)
            if info.get("success"):
                self.consecutive_idles = 0

        # --- награда за прирост DPS ---
        # (считается внутри _build/_upgrade через компоненты dps)

        # --- симуляция ---
        before_wave = self.current_wave
        reward += self._simulate_tick()

        if not self.wave_active and self.current_wave < self.config.max_waves:
            self.wave_end_timer += self.dt
            if self.wave_end_timer >= WAVE_AUTO_START_DELAY:
                self._start_next_wave()
                if self.current_wave > before_wave:
                    reward += self._wave_reward()

        # --- завершение ---
        if self.base_hp <= 0:
            self.done = True
            r = -5.0
            reward += r
            self.reward_components.penalty += r
            info["result"] = "defeat"
            if len(self.towers) >= 3 and self.total_damage < 50:
                r2 = -5.0
                reward += r2
                self.reward_components.penalty += r2
                info["reason"] = "zero_damage_spam"
        elif self.current_wave >= self.config.max_waves and self.enemy_manager.count == 0:
            self.done = True
            r = 10.0
            reward += r
            self.reward_components.wave += r
            info["result"] = "victory"

        # --- milestone по среднему уровню ---
        combat = [t for t in self.towers if not t.type.is_income]
        if combat:
            avg_level = float(np.mean([t.level for t in combat]))
            prev = getattr(self, "_last_avg_level", 0.0)
            for threshold, bonus in ((3.0, 3.0), (5.0, 5.0), (7.0, 8.0)):
                if avg_level >= threshold > prev:
                    reward += bonus
                    self.reward_components.strategic += bonus
            self._last_avg_level = avg_level

        self.last_actions.append(action_type)
        reward = float(np.clip(reward, -15.0, 15.0))

        info.update(self._build_info(info.get("success", False)))
        return reward, self.done, info

    def _idle_penalty(self) -> float:
        if self.step_count <= 3 and self.money >= 100:
            self.reward_components.penalty -= 5.0
            return -5.0
        can_build = self.type_mask()[BUILD]
        can_upgrade = self.type_mask()[UPGRADE]
        if can_build and can_upgrade:
            p = -0.5 - 0.1 * min(self.consecutive_idles, 5)
        elif can_build or can_upgrade:
            p = -0.2 - 0.05 * min(self.consecutive_idles, 5)
        else:
            return 0.0
        self.reward_components.penalty += p
        return p

    # ---------------------------------------------------------------- credits
    def compute_step_credits(self) -> np.ndarray:
        """
        Вклад каждой башни за текущий шаг (нормализованный [0,1]),
        фиксированной длины MAX_TOWERS по порядку постройки.
        Это таргет для вспомогательной головы credit_head.
        """
        credits: Dict[int, float] = {}
        max_credit = 1e-8

        for i, tower in enumerate(self.towers):
            credit = self.step_tower_damage.get(i, 0.0)

            if tower.type.is_slow or tower.type.is_push:
                cc_range = tower.get_range()
                for j, other in enumerate(self.towers):
                    if j == i or other.type.is_support:
                        continue
                    dist = math.hypot(tower.x - other.x, tower.y - other.y)
                    denom = cc_range + other.get_range()
                    if denom > 0 and dist <= denom:
                        dmg = self.step_tower_damage.get(j, 0.0)
                        if dmg > 0:
                            overlap = max(0.0, 1.0 - dist / denom)
                            credit += dmg * 0.25 * overlap

            if tower.type.is_link:
                link_range = tower.get_range()
                for j, other in enumerate(self.towers):
                    if j == i or other.link_bonus <= 0:
                        continue
                    if math.hypot(tower.x - other.x, tower.y - other.y) > link_range:
                        continue
                    dmg = self.step_tower_damage.get(j, 0.0)
                    if dmg > 0:
                        credit += dmg * (other.link_bonus / (1.0 + other.link_bonus))

            if tower.type.is_income and i in self.step_income:
                wave_progress = self.current_wave / max(self.config.max_waves, 1)
                early_mult = max(0.3, 1.5 - wave_progress)
                credit += self.step_income[i] * early_mult

            credits[i] = credit
            max_credit = max(max_credit, credit)

        out = np.zeros(MAX_TOWERS, dtype=np.float32)
        for i, credit in credits.items():
            if i >= MAX_TOWERS:
                continue
            norm = credit / max_credit if max_credit > 1e-8 else 0.0
            # штраф за бесполезные башни
            if self.step_tower_damage:
                total = max(1e-6, sum(self.step_tower_damage.values()))
                share = self.step_tower_damage.get(i, 0.0) / total
                if share < 0.01:
                    norm *= 0.3
                elif share < 0.05:
                    norm *= 0.7
            out[i] = float(np.clip(norm, 0.0, 1.0))
        return out

    # ---------------------------------------------------------------- info
    def _build_info(self, success: bool) -> Dict:
        combat = [t for t in self.towers if not t.type.is_income]
        tower_stats = {}
        for t in self.towers:
            name = t.type.name
            if name not in tower_stats:
                tower_stats[name] = [0.0, 0]
            tower_stats[name][0] += t.total_damage
            tower_stats[name][1] += 1

        return {
            "success": bool(success),
            "wave": int(self.current_wave),
            "money": float(self.money),
            "hp": int(self.base_hp),
            "towers": len(self.towers),
            "combat_towers": len(combat),
            "enemies": int(self.enemy_manager.count),
            "upgrades": int(self.total_upgrades),
            "sells": int(self.total_sells),
            "total_damage": float(self.total_damage),
            "total_kills": int(self.total_kills),
            "wave_active": bool(self.wave_active),
            "deck": list(self.deck),
            "deck_meta": self._deck_meta.copy(),
            "map_meta": self._map_meta.copy(),
            "reward_components": self.reward_components.as_array(),
            "tower_credit_targets": self.compute_step_credits(),
            "tower_damage_stats": tower_stats,
            "max_tower_level": max((t.level for t in self.towers), default=0),
            "avg_tower_level": float(np.mean([t.level for t in combat])) if combat else 0.0,
            "money_earned": float(self.money_earned),
            "money_spent": float(self.money_spent),
            "step_count": int(self.step_count),
        }

    # ---------------------------------------------------------------- obs
    def get_observation(self) -> np.ndarray:
        """
        Плоское наблюдение (для отладки/визуализации; политика использует граф).
        Formат: 10 каналов карты + глобальные признаки (36) + колода (deck*5).
        """
        obs_map = np.zeros((MAP_CHANNELS, self.H, self.W), dtype=np.float32)
        obs_map[0] = self.map_matrix.astype(np.float32) / 2.0
        for t in self.towers:
            if 0 <= t.x < self.H and 0 <= t.y < self.W:
                obs_map[1, t.x, t.y] = t.level / max(1, self.config.max_tower_level)
                obs_map[2, t.x, t.y] = (t.type.id + 1) / (TOTAL_TOWER_TYPES + 1)
                obs_map[3, t.x, t.y] = np.log1p(t.total_damage) / LOG_DAMAGE_CAP
                obs_map[8, t.x, t.y] = (1.0 if self.money >= t.get_upgrade_cost() else 0.5)
        em = self.enemy_manager
        for i in range(em.count):
            if em.hp[i] <= 0:
                continue
            gx, gy = int(em.pos_x[i]), int(em.pos_y[i])
            if 0 <= gx < self.H and 0 <= gy < self.W:
                obs_map[4, gx, gy] = max(obs_map[4, gx, gy],
                                         min(1.0, np.log1p(em.hp[i]) / LOG_HP_CAP))
        for x in range(self.H):
            for y in range(self.W):
                obs_map[5, x, y] = self._position_quality[x, y]
        obs_map[6] = self.base_buildable_mask().reshape(self.H, self.W).astype(np.float32)
        for t in self.towers:
            if t.type.is_income or t.type.is_link:
                continue
            tr = int(round(t.get_range()))
            dps_norm = min(1.0, np.log1p(t.get_dps()) / LOG_DPS_CAP)
            for nx in range(max(0, t.x - tr), min(self.H, t.x + tr + 1)):
                for ny in range(max(0, t.y - tr), min(self.W, t.y + tr + 1)):
                    if (nx - t.x) ** 2 + (ny - t.y) ** 2 <= tr * tr:
                        obs_map[7, nx, ny] = max(obs_map[7, nx, ny], dps_norm)

        # глобальные
        g = np.zeros(GLOBAL_FEATURES, dtype=np.float32)
        g[0] = min(self.money / max(1.0, self._max_tower_cost * 10), 5.0)
        g[1] = self.current_wave / max(1, self.config.max_waves)
        g[2] = self.base_hp / max(1, self.config.starting_hp)
        g[3] = np.log1p(em.count) / np.log1p(100)
        g[4] = len(self.towers) / max(1, self.config.max_towers_on_map)
        g[5] = np.log1p(self.total_damage) / LOG_DAMAGE_CAP
        g[6] = len(self.towers_by_type) / max(1, self.config.deck_size)
        g[7] = 1.0 if self.wave_active else 0.0
        g[8] = float(np.mean([t.level for t in self.towers])) / max(
            1, self.config.max_tower_level) if self.towers else 0.0
        g[13] = np.log1p(self.total_kills) / LOG_KILLS_CAP
        g[12] = self.builds_this_wave / max(1, self.config.max_builds_per_wave)
        g[23:32] = self._deck_meta
        g[32:36] = self._map_meta

        map_diag = math.hypot(self.H, self.W)
        deck_obs = np.concatenate([
            TOWER_TYPES_DATA[tid].get_properties_vector(
                current_money=max(self.money, 100.0),
                max_enemy_hp=self._current_wave_max_hp,
                map_diagonal=map_diag)
            for tid in self.deck
        ]).astype(np.float32)

        return np.concatenate([obs_map.ravel(), g, deck_obs])

