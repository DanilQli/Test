"""
ДАННЫЕ: баланс, карты, таблицы башен/врагов, интерфейс игры (IGameAdapter).

Собран склейкой файлов: constants, interfaces, maps, game_data
"""
from __future__ import annotations


# ============================================================================
# СЕКЦИЯ: constants.py
# ============================================================================
# ============================================================================
# БАЛАНС (FROZEN)  --  НЕ МЕНЯТЬ
# ============================================================================
STRENGTHENING_ENEMIES: float = 0.10      # линейный рост HP врагов по волнам
STRENGTHENING_ENEMIES_DOP: float = 0.10  # квадратичная добавка к росту HP
STRENGTHENING_MONEY: float = 0.25        # рост награды за убийство по волнам

CHANCE_CRITICAL_DAMAGE: float = 0.07
CRITICAL_DAMAGE_MULTIPLIER: float = 5.0

# Значения, которые проверяет тест заморозки баланса.
FROZEN_BALANCE = {
    "STRENGTHENING_ENEMIES": STRENGTHENING_ENEMIES,
    "STRENGTHENING_ENEMIES_DOP": STRENGTHENING_ENEMIES_DOP,
    "STRENGTHENING_MONEY": STRENGTHENING_MONEY,
    "CHANCE_CRITICAL_DAMAGE": CHANCE_CRITICAL_DAMAGE,
    "CRITICAL_DAMAGE_MULTIPLIER": CRITICAL_DAMAGE_MULTIPLIER,
}
BALANCE_FROZEN: bool = True

# ============================================================================
# МАСШТАБЫ НОРМАЛИЗАЦИИ (логарифмические потолки)
# ============================================================================
LOG_HP_CAP: float = float(__import__("math").log1p(1_000_000.0))   # ~13.82
LOG_DPS_CAP: float = float(__import__("math").log1p(50_000.0))     # ~10.82
LOG_MONEY_CAP: float = float(__import__("math").log1p(100_000.0))  # ~11.51
LOG_KILLS_CAP: float = float(__import__("math").log1p(5_000.0))    # ~8.52
LOG_DAMAGE_CAP: float = 16.118                                     # log1p(10 млн)

# ============================================================================
# СТОИМОСТЬ АПГРЕЙДОВ ПО ТИРАМ (данные игры)
# ============================================================================
COSTS_TIER_1 = [50.0, 75.0, 125.0, 200.0, 325.0, 525.0, 850.0, 1375.0, 2225.0, 3600.0]
COSTS_TIER_2 = [c * 1.5 for c in COSTS_TIER_1]
COSTS_TIER_3 = [c * 2.5 for c in COSTS_TIER_1]

# ============================================================================
# РАЗМЕРНОСТИ НАБЛЮДЕНИЙ / СЕТИ
# ============================================================================
MAP_CHANNELS: int = 10

NODE_FEATURES_DIM: int = 12    # см. tdai/graph.py::MapToGraphConverter
TOWER_PROPS_DIM: int = 5       # [cost, dps, range, role, has_special]

GLOBAL_BASE_FEATURES: int = 23
DECK_META_FEATURES: int = 9
MAP_META_FEATURES: int = 4
GLOBAL_FEATURES: int = GLOBAL_BASE_FEATURES + DECK_META_FEATURES + MAP_META_FEATURES  # 36

# Дека: 1..8 слотов (универсальная архитектура, attention q*k по слотам).
MAX_DECK_SIZE: int = 8
MIN_DECK_SIZE: int = 1

# Действия
N_ACTION_TYPES: int = 4   # 0=IDLE, 1=BUILD, 2=UPGRADE, 3=SELL
IDLE, BUILD, UPGRADE, SELL = 0, 1, 2, 3

LAST_ACTIONS_HISTORY: int = 5
THREAT_MAP_LOOKAHEAD_STEPS: int = 10
MAX_ENEMIES: int = 200
MAX_TARGETS_PER_TOWER: int = 32
MAX_TOWERS: int = 50

# Маска запрещённых действий (SELL при enable_sell=False).
MASKED_LOGIT: float = -1e9

# ============================================================================
# НАГРАДЫ (веса shaping-а; не баланс игры, а сигнал обучения)
# ============================================================================
REWARD_CLIP: float = 15.0

# ============================================================================
# ТАЙМИНГИ СИМУЛЯЦИИ
# ============================================================================
DT: float = 1.0                     # 1 решение = 1 секунда симуляции
WAVE_DURATION: float = 20.0         # длительность волны спавна (как в Godot)
WAVE_AUTO_START_DELAY: float = 3.0  # автостарт следующей волны (как в Godot)
MAX_BUILDS_PER_WAVE: int = 6

# ============================================================================
# СЕКЦИЯ: interfaces.py
# ============================================================================
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Tuple, Optional

import numpy as np


# ============================================================================
# ENUM'ы и датаклассы (универсальные)
# ============================================================================
class TowerRole(Enum):
    DPS = 0.0
    AOE = 0.25
    CONTROL = 0.5
    INCOME = 0.75
    SUPPORT = 1.0


@dataclass
class UniversalTowerStats:
    """Универсальные характеристики ТИПА башни (не конкретной постройки)."""
    uid: int                 # уникальный id типа башни в игре
    cost: float              # стоимость постройки
    damage: float            # урон за выстрел (ур. 0)
    rof: float               # секунд между выстрелами (ур. 0)
    range_val: float         # радиус в КЛЕТКАХ (ур. 0)
    role: TowerRole
    has_special: bool
    max_level: int = 9
    upgrade_costs: List[float] = field(default_factory=list)

    def __post_init__(self):
        if not self.upgrade_costs:
            # Дефолтная прогрессия, если игра не передала свои цены.
            self.upgrade_costs = [50.0 * (1.5 ** i) for i in range(max(1, self.max_level))]

    # --- derived ---
    def get_dps(self) -> float:
        return self.damage / max(0.1, self.rof)

    def get_upgrade_cost(self, current_level: int) -> float:
        if current_level >= self.max_level or current_level >= len(self.upgrade_costs):
            return float("inf")
        return float(self.upgrade_costs[current_level])

    def to_vector(self, max_cost_ref: float = 500.0) -> np.ndarray:
        """5 универсальных признаков башни (TOWER_PROPS_DIM)."""
        return np.array([
            self.cost / max(1.0, max_cost_ref),
            np.log1p(self.get_dps()) / np.log1p(50_000.0),
            min(self.range_val / 10.0, 1.0),
            float(self.role.value),
            1.0 if self.has_special else 0.0,
        ], dtype=np.float32)


@dataclass
class PlacedTowerInfo:
    """Полная информация о РАЗМЕЩЁННОЙ башне."""
    x: int
    y: int
    stats: UniversalTowerStats
    level: int
    total_damage: float
    current_upgrade_cost: float
    can_upgrade: bool
    tower_id: int = -1        # внутренний id постройки (для SELL / трекинга кредитов)


@dataclass
class UniversalEnemyStats:
    hp: float
    max_hp: float
    speed: float                      # в клетках/сек
    position: Tuple[float, float]     # (x, y) в координатах сетки
    progress: float                   # 0..1 прогресс по пути


@dataclass
class ActionFlags:
    """
    Какие действия разрешены в этой игре.

    Правило №5: SELL разрешён ТОЛЬКО флагом enable_sell. Если False —
    соответствующая голова маскируется значением -1e9 и не может быть выбрана.
    """
    enable_sell: bool = False
    enable_upgrade: bool = True
    enable_build: bool = True

    def as_array(self) -> np.ndarray:
        # порядок: IDLE, BUILD, UPGRADE, SELL
        return np.array([
            True,
            self.enable_build,
            self.enable_upgrade,
            self.enable_sell,
        ], dtype=bool)


# Ключи глобального состояния, которые читает энкодер, и их безопасные дефолты.
# Адаптер новой игры может вернуть только часть ключей — остальное возьмётся
# из дефолтов (так работает перенос «без переобучения» на игру с другим набором
# отслеживаемых величин).
GLOBAL_STATE_DEFAULTS: Dict[str, float] = {
    "money": 0.0,
    "wave": 0.0,
    "max_waves": 80.0,
    "hp": 10.0,
    "max_hp": 10.0,
    "wave_active": 0.0,
    "max_tower_level": 9.0,
    "max_tower_cost": 500.0,
    "min_build_cost": 100.0,
    "builds_this_wave": 0.0,
    "max_builds_per_wave": 6.0,
    "current_towers": 0.0,
    "max_towers_on_map": 50.0,
    "total_kills": 0.0,
    "total_damage": 0.0,
    "total_upgrades": 0.0,
    "difficulty": 1.0,
    "time": 0.0,
}


class IGameAdapter(ABC):
    """Интерфейс для ЛЮБОЙ TD-игры (единственная точка интеграции)."""

    # ---------------- обязательные методы ----------------
    @abstractmethod
    def get_map_grid(self) -> np.ndarray:
        """Матрица карты (H, W): 0=пусто (можно строить), 1=дорога, 2=препятствие."""

    @abstractmethod
    def get_path(self) -> List[Tuple[int, int]]:
        """Координаты пути (упорядоченные от входа к базе)."""

    @abstractmethod
    def get_deck_stats(self) -> List[UniversalTowerStats]:
        """Колода: башни, доступные для постройки. ПОРЯДОК = индексы слотов колоды."""

    @abstractmethod
    def get_placed_towers(self) -> List[PlacedTowerInfo]:
        """Размещённые башни."""

    @abstractmethod
    def get_enemies(self) -> List[UniversalEnemyStats]:
        """Живые враги."""

    @abstractmethod
    def get_global_state(self) -> Dict[str, float]:
        """Глобальные переменные (см. GLOBAL_STATE_DEFAULTS)."""

    # ---------------- опциональные (есть дефолт) ----------------
    def get_action_flags(self) -> ActionFlags:
        return ActionFlags()

    def get_last_actions(self) -> List[int]:
        """История последних типов действий (0=idle,1=build,2=upgrade,3=sell)."""
        return []

    def get_action_masks(self) -> Dict[str, np.ndarray]:
        """
        Маски допустимых узлов для каждой головы действия.

        Возвращает dict:
            "build"   : [N, deck_size] bool — куда можно поставить башню из слота
            "upgrade" : [N] bool           — что можно улучшить
            "sell"    : [N] bool           — что можно продать

        Дефолтная (универсальная) реализация: строить можно на пустых клетках,
        улучшать/продавать — только там, где стоит башня. Игра может
        переопределить это своими правилами (покрытие дороги, лимиты и т.п.).
        """
        grid = self.get_map_grid()
        H, W = grid.shape
        N = H * W
        towers = self.get_placed_towers()
        occupied = np.zeros(N, dtype=bool)
        for t in towers:
            occupied[int(t.x) * W + int(t.y)] = True

        empty = (grid.reshape(-1) == 0) & (~occupied)
        deck = self.get_deck_stats()
        build = np.repeat(empty[:, None], max(1, len(deck)), axis=1)
        upgrade = np.zeros(N, dtype=bool)
        for t in towers:
            if t.can_upgrade:
                upgrade[int(t.x) * W + int(t.y)] = True
        sell = occupied.copy()
        if not self.get_action_flags().enable_sell:
            sell[:] = False
        return {"build": build, "upgrade": upgrade, "sell": sell}

    def get_deck_meta(self) -> np.ndarray:
        """9 универсальных мета-признаков колоды."""
        stats = self.get_deck_stats()
        out = np.zeros(9, dtype=np.float32)
        if not stats:
            return out

        def any_of(pred):
            return float(any(pred(s) for s in stats))

        out[0] = any_of(lambda s: s.role != TowerRole.INCOME)          # есть урон
        out[1] = any_of(lambda s: s.role == TowerRole.AOE)             # есть AOE
        out[2] = any_of(lambda s: s.role == TowerRole.CONTROL)         # есть контроль
        out[3] = any_of(lambda s: s.role == TowerRole.INCOME)          # есть экономика
        out[4] = any_of(lambda s: s.has_special)                       # есть спец-эффект
        out[5] = any_of(lambda s: s.role == TowerRole.CONTROL)         # (совместимость)
        out[6] = float(np.mean([s.cost for s in stats])) / 500.0
        out[7] = float(max(s.get_dps() for s in stats)) / 100.0
        out[8] = len({s.role for s in stats}) / 5.0
        return out

    def get_map_meta(self) -> np.ndarray:
        """4 универсальных мета-признака карты: длина пути, извилистость, застройка, открытость."""
        grid = self.get_map_grid()
        path = self.get_path()
        H, W = grid.shape
        out = np.zeros(4, dtype=np.float32)
        out[0] = len(path) / max(1, H * W)
        turns = 0
        for i in range(1, len(path) - 1):
            d1 = (path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1])
            d2 = (path[i + 1][0] - path[i][0], path[i + 1][1] - path[i][1])
            turns += int(d1 != d2)
        out[1] = turns / max(1, len(path))
        adj = 0
        for px, py in path:
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                nx, ny = px + dx, py + dy
                if 0 <= nx < H and 0 <= ny < W and grid[nx, ny] == 0:
                    adj += 1
        out[2] = adj / max(1, len(path) * 4)
        out[3] = float(np.count_nonzero(grid == 0)) / max(1, H * W)
        return out

    def get_deck_ids(self) -> Optional[List[int]]:
        """Реальные uid башен в порядке слотов колоды (если нужны игре)."""
        return [int(t.uid) for t in self.get_deck_stats()]

    # ---------------- утилиты (не переопределять) ----------------
    def get_global_state_filled(self) -> Dict[str, float]:
        """Возвращает get_global_state() с подставленными дефолтами."""
        state = dict(GLOBAL_STATE_DEFAULTS)
        raw = self.get_global_state() or {}
        for k, v in raw.items():
            try:
                state[k] = float(v)
            except (TypeError, ValueError):
                continue
        return state

    def deck_vector(self, max_ref_len: int = 8) -> np.ndarray:
        """
        Матрица фичей колоды (max_ref_len, 5) + attention-маска слотов (max_ref_len,).
        Паддинг нулями, маска = True для реальных слотов (ключи разрешены).
        """
        stats = self.get_deck_stats()
        max_cost = max([t.cost for t in stats], default=500.0)
        vec = np.zeros((max_ref_len, 5), dtype=np.float32)
        mask = np.zeros(max_ref_len, dtype=bool)
        for i, t in enumerate(stats[:max_ref_len]):
            vec[i] = t.to_vector(max_cost_ref=max_cost)
            mask[i] = True
        return vec, mask

# ============================================================================
# СЕКЦИЯ: maps.py
# ============================================================================
import numpy as np

MAPS_TRAIN = {}
MAPS_TEST = {}

# 1. Прямая диагональ (ступеньки)
MAPS_TRAIN["map_01"] = np.array([
    [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1],
], dtype=np.int32)

# 2. Большая "S"
MAPS_TRAIN["map_02"] = np.array([
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2],
], dtype=np.int32)

# 3. "U" (подкова)
MAPS_TRAIN["map_03"] = np.array([
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
], dtype=np.int32)

# 4. Зиг-Заг
MAPS_TRAIN["map_04"] = np.array([
    [1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
], dtype=np.int32)

# 5. Лабиринт с препятствиями
MAPS_TRAIN["map_05"] = np.array([
    [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2],
    [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2],
    [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 2],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 2],
    [0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2],
    [0, 2, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 2],
    [0, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2],
    [0, 2, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 2],
    [0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2],
    [0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
], dtype=np.int32)

# 6. Частая горизонтальная змейка
MAPS_TRAIN["map_06"] = np.array([
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
], dtype=np.int32)

# 11. Двойной коридор (V-змейка, 36 клеток)
MAPS_TRAIN["map_12"] = np.array([
    [0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 2, 0, 1, 0],
    [0, 0, 0, 0, 0, 0, 1, 0, 2, 1, 0, 2, 1, 0],
    [0, 0, 0, 0, 0, 0, 1, 2, 0, 1, 2, 2, 1, 0],
    [0, 0, 0, 0, 0, 0, 1, 0, 2, 1, 2, 0, 1, 0],
    [0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0],
    [0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 0, 0, 1, 0],
    [0, 0, 0, 0, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0],
    [0, 0, 0, 0, 0, 2, 1, 2, 0, 1, 2, 0, 1, 2],
    [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
], dtype=np.int32)

# 12. Тройная S-змейка (45 клеток)
MAPS_TRAIN["map_13"] = np.array([
    [0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0],
    [0, 2, 0, 0, 0, 2, 2, 0, 0, 0, 0, 1, 0, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
    [1, 2, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [2, 0, 2, 2, 2, 0, 2, 2, 0, 0, 0, 0, 0, 0],
], dtype=np.int32)

# 13. Две параллельные V-змейки (52 клетки)
MAPS_TRAIN["map_14"] = np.array([
    [0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0],
    [0, 1, 0, 0, 2, 1, 0, 2, 0, 0, 1, 0, 1, 0],
    [2, 1, 0, 0, 0, 1, 2, 0, 0, 0, 1, 0, 1, 0],
    [0, 1, 0, 0, 0, 1, 0, 0, 0, 2, 1, 0, 1, 2],
    [0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0],
    [2, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0],
    [2, 1, 0, 0, 0, 1, 0, 0, 0, 2, 1, 0, 1, 0],
    [0, 1, 0, 0, 2, 1, 0, 0, 0, 0, 1, 0, 1, 0],
    [0, 1, 2, 0, 0, 1, 0, 0, 0, 2, 1, 2, 1, 0],
    [2, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0],
    [0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2],
], dtype=np.int32)

# 14. Широкая змейка с длинными рядами (58 клеток)
MAPS_TRAIN["map_15"] = np.array([
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 2, 0, 0, 2, 0, 0, 2, 2, 0, 2, 0, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 2, 0, 1, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [1, 0, 0, 0, 0, 0, 0, 2, 0, 0, 2, 0, 0, 2],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [0, 2, 2, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0],
], dtype=np.int32)

# 7. Длинный маршрут с препятствиями
MAPS_TEST["map_07"] = np.array([
    [1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 1, 0, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0],
    [0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
    [0, 2, 2, 2, 2, 2, 2, 0, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
], dtype=np.int32)

# 8. Две башни-аппендикса
MAPS_TEST["map_08"] = np.array([
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 2, 2],
    [0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 2, 2],
    [0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    [0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    [0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
], dtype=np.int32)

# 9. Сжатая пружина
MAPS_TEST["map_09"] = np.array([
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0],
    [1, 0, 0, 2, 2, 2, 0, 0, 0, 0, 1, 1, 1, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0],
    [1, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0],
    [2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
], dtype=np.int32)

# 10. Комнаты (двойная петля)
MAPS_TEST["map_11"] = np.array([
    [2, 2, 2, 1, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2],
    [2, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 2],
    [2, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 2],
    [2, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 2],
    [2, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 2],
    [2, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 2],
    [2, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2],
    [2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2],
    [2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2],
    [2, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 2],
    [2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 2],
    [2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2],
], dtype=np.int32)

# 15. Плотная змейка на 5 рядов (69 клеток)
MAPS_TEST["map_16"] = np.array([
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 2, 0, 0, 2, 1, 0, 0, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 2],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [0, 2, 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 1],
    [0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [0, 0, 2, 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 0],
], dtype=np.int32)

# 16. Плотная V-змейка на 5 дорожек (61 клетка)
MAPS_TEST["map_17"] = np.array([
    [0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0],
    [0, 1, 2, 0, 0, 1, 0, 1, 0, 2, 1, 0, 1, 0],
    [0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 1, 2, 1, 0],
    [0, 1, 0, 0, 2, 1, 0, 1, 0, 0, 1, 0, 1, 2],
    [0, 1, 0, 0, 0, 1, 2, 1, 0, 0, 1, 2, 1, 2],
    [0, 1, 0, 0, 0, 1, 2, 1, 0, 0, 1, 0, 1, 0],
    [0, 1, 2, 0, 0, 1, 2, 1, 0, 0, 1, 0, 1, 0],
    [0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 2, 1, 0],
    [0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 2, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0],
], dtype=np.int32)


# Обратная совместимость
MAPS = MAPS_TRAIN


def get_train_maps() -> dict:
    return MAPS_TRAIN


def get_test_maps() -> dict:
    return MAPS_TEST


def validate_maps() -> None:
    """Проверяет, что все карты корректны: форма, наличие пути, связность."""
    for split, d in (("TRAIN", MAPS_TRAIN), ("TEST", MAPS_TEST)):
        assert len(d) > 0, f"{split}: нет карт"
        for name, m in d.items():
            assert m.ndim == 2, f"{name}: не 2D"
            assert m.dtype == np.int32, f"{name}: dtype={m.dtype}"
            assert np.isin(m, [0, 1, 2]).all(), f"{name}: неизвестные символы карты"
            assert (m == 1).sum() > 0, f"{name}: нет дороги"


validate_maps()

# ============================================================================
# СЕКЦИЯ: game_data.py
# ============================================================================
from dataclasses import dataclass, field
from typing import Dict, List, Tuple

import numpy as np


# ============================================================================
# БАШНИ
# ============================================================================
@dataclass
class TowerType:
    """
    Тип башни. В векторе признаков ГАРАНТИРОВАННО 5 чисел.

    p1..p5 — параметры по уровням (0..9). Смысл зависит от типа башни,
    но для ВСЕХ боевых типов p1=Damage, p2=ROF(сек), p3=Range(пиксели).
    """
    id: int
    name: str
    cost: float
    p1: List[float]
    p2: List[float]
    p3: List[float]
    p4: List[float] = field(default_factory=list)
    p5: List[float] = field(default_factory=list)

    is_aoe: bool = False
    is_slow: bool = False
    is_income: bool = False
    is_poison: bool = False
    is_trap: bool = False
    is_execute: bool = False
    is_push: bool = False
    is_link: bool = False
    is_drone: bool = False
    is_billy: bool = False
    is_crossbow: bool = False

    upgrade_costs: List[float] = field(default_factory=lambda: list(COSTS_TIER_1))

    # ---------------- доступ по уровням ----------------
    def get_val(self, param_list: List[float], level: int) -> float:
        if not param_list:
            return 0.0
        return param_list[min(max(0, level), len(param_list) - 1)]

    def get_damage(self, level: int = 0) -> float:
        return self.get_val(self.p1, level)

    def get_rof(self, level: int = 0) -> float:
        return self.get_val(self.p2, level)

    def get_range(self, level: int = 0) -> float:
        """Радиус в КЛЕТКАХ (пиксели / 64). У income-башен радиуса нет."""
        if self.is_income:
            return 0.0
        return self.get_val(self.p3, level) / 64.0

    def get_dps(self, level: int = 0) -> float:
        if self.is_income:
            return self.get_val(self.p1, level)
        return self.get_damage(level) / max(0.1, self.get_rof(level))

    def get_special_1(self, level: int = 0) -> float:
        return self.get_val(self.p4, level) if self.p4 else 0.0

    def get_special_2(self, level: int = 0) -> float:
        return self.get_val(self.p5, level) if self.p5 else 0.0

    def get_upgrade_cost(self, level: int) -> float:
        if level >= len(self.upgrade_costs) or level >= 9:
            return 99999.0
        return float(self.upgrade_costs[level])

    # ---------------- роли / свойства ----------------
    @property
    def role_value(self) -> float:
        if self.is_income:
            return 0.75
        if self.is_slow or self.is_push or self.is_trap:
            return 0.5
        if self.is_aoe:
            return 0.25
        if self.is_link or self.is_drone:
            return 1.0
        return 0.0

    @property
    def is_support(self) -> bool:
        return self.is_slow or self.is_push or self.is_income or self.is_link

    @property
    def is_global_placement(self) -> bool:
        """Башни, которым не нужна близость к дороге (income / drone)."""
        return self.is_income or self.is_drone

    def get_properties_vector(self, current_money: float, max_enemy_hp: float,
                              map_diagonal: float) -> np.ndarray:
        """5 универсальных признаков для attention-энкодера колоды."""
        cost_norm = float(np.clip(self.cost / max(100.0, current_money), 0.0, 1.0))
        dps_ratio = self.get_dps(0) / max(1.0, max_enemy_hp)
        dps_norm = float(np.log1p(dps_ratio))
        range_norm = float(np.clip(self.get_range(0) / max(1.0, map_diagonal), 0.0, 1.0))
        has_special = float(self.is_poison or self.is_execute or self.is_crossbow or self.is_billy)

        vec = np.array([cost_norm, dps_norm, range_norm, self.role_value, has_special],
                       dtype=np.float32)
        assert vec.shape == (5,), f"get_properties_vector must return (5,), got {vec.shape}"
        return vec


TOWER_TYPES_DATA: Dict[int, TowerType] = {}

# 0: GunTower — p1=Damage, p2=ROF, p3=Range, p4=Reduction bonus
TOWER_TYPES_DATA[0] = TowerType(
    id=0, name="GunTower", cost=100,
    p1=[70.74, 77.81, 85.59, 94.15, 103.57, 113.93, 125.32, 137.85, 151.64, 166.8],
    p2=[1.0, 0.93, 0.86, 0.8, 0.74, 0.69, 0.64, 0.6, 0.55, 0.5],
    p3=[245.0, 248.0, 251.0, 254.0, 257.0, 262.0, 268.0, 275.0, 282.0, 290.0],
    p4=[94.32, 103.75, 114.13, 125.54, 138.09, 151.9, 167.09, 183.8, 202.18, 222.4],
)

# 1: AreaTower (мультицель) — p4=TargetCount
TOWER_TYPES_DATA[1] = TowerType(
    id=1, name="AreaTower", cost=200,
    p1=[156.57, 161.74, 167.08, 172.59, 178.29, 184.17, 190.25, 196.53, 203.02, 209.72],
    p2=[1.05, 1.02, 0.99, 0.96, 0.93, 0.9, 0.82, 0.79, 0.75, 0.7],
    p3=[245.0, 248.0, 251.0, 254.0, 257.0, 262.0, 268.0, 275.0, 282.0, 290.0],
    p4=[1, 1, 2, 2, 3, 3, 4, 4, 5, 5],
    upgrade_costs=list(COSTS_TIER_2),
    is_aoe=True,
)

# 2: CrossbowTower — p4=duration, p5=up speed %
TOWER_TYPES_DATA[2] = TowerType(
    id=2, name="CrossbowTower", cost=100,
    p1=[35.37, 38.91, 42.8, 47.08, 51.79, 56.97, 62.67, 68.94, 75.83, 83.41],
    p2=[1.0, 0.97, 0.94, 0.91, 0.88, 0.85, 0.82, 0.79, 0.75, 0.7],
    p3=[230.0, 234.0, 238.0, 242.0, 246.0, 250.0, 254.0, 258.0, 262.0, 266.0],
    p4=[5.1] * 10,
    p5=[500] * 10,
    is_crossbow=True,
)

# 3: SlowTower — p1=intensity(%), p2=ROF, p3=Range, p4=duration
TOWER_TYPES_DATA[3] = TowerType(
    id=3, name="SlowTower", cost=100,
    p1=[11.8, 13.0, 14.3, 15.7, 17.3, 19.0, 20.9, 23.0, 25.3, 27.8],
    p2=[1.5, 1.47, 1.44, 1.41, 1.38, 1.35, 1.32, 1.29, 1.25, 1.2],
    p3=[340.0, 350.0, 360.0, 370.0, 380.0, 390.0, 400.0, 410.0, 420.0, 430.0],
    p4=[1.09, 1.1, 1.11, 1.12, 1.13, 1.14, 1.15, 1.16, 1.17, 1.18],
    is_slow=True,
)

# 4: MovementTower (push) — p1=дистанция в % пути, p2=ROF, p3=Range
TOWER_TYPES_DATA[4] = TowerType(
    id=4, name="MovementTower", cost=100,
    p1=[8.53, 9.55, 10.7, 11.98, 13.42, 15.03, 16.83, 18.85, 21.11, 23.64],
    p2=[4.0, 3.8, 3.61, 3.43, 3.26, 3.1, 2.94, 2.79, 2.65, 2.52],
    p3=[245.0, 248.0, 251.0, 254.0, 257.0, 262.0, 268.0, 275.0, 282.0, 290.0],
    is_push=True,
)

# 5: MoneyTower — p1=income за тик, p2=ROF
TOWER_TYPES_DATA[5] = TowerType(
    id=5, name="MoneyTower", cost=100,
    p1=[7.76, 8.54, 9.39, 10.33, 11.36, 12.5, 13.75, 15.13, 16.64, 18.3],
    p2=[3.0, 2.85, 2.71, 2.57, 2.44, 2.32, 2.2, 2.09, 1.99, 1.89],
    p3=[0.0] * 10,
    is_income=True,
)

# 6: PoisonTower — p4=duration, p5=tick
TOWER_TYPES_DATA[6] = TowerType(
    id=6, name="PoisonTower", cost=100,
    p1=[46.54, 52.12, 58.37, 65.37, 73.21, 82.0, 91.84, 102.86, 115.2, 129.02],
    p2=[1.0, 0.97, 0.94, 0.91, 0.88, 0.85, 0.82, 0.79, 0.75, 0.7],
    p3=[245.0, 248.0, 251.0, 254.0, 257.0, 262.0, 268.0, 275.0, 282.0, 290.0],
    p4=[4.0] * 10,
    p5=[0.92, 0.87, 0.83, 0.79, 0.75, 0.71, 0.67, 0.64, 0.61, 0.58],
    is_poison=True,
)

# 7: TrapTower (Minotaur) — p4=trap damage
TOWER_TYPES_DATA[7] = TowerType(
    id=7, name="TrapTower", cost=100,
    p1=[117.9, 135.59, 155.93, 179.32, 206.22, 237.15, 272.72, 313.63, 360.67, 414.77],
    p2=[3.18, 3.1, 3.02, 2.94, 2.87, 2.8, 2.73, 2.66, 2.59, 2.53],
    p3=[245.0, 248.0, 251.0, 254.0, 257.0, 262.0, 268.0, 275.0, 282.0, 290.0],
    p4=[511.61, 567.89, 630.36, 699.7, 776.67, 862.1, 956.93, 1062.19, 1179.03, 1308.72],
    is_trap=True,
)

# 8: HangmanTower (execute) — p4=health % порог
TOWER_TYPES_DATA[8] = TowerType(
    id=8, name="HangmanTower", cost=200,
    p1=[220.62, 236.06, 252.58, 270.26, 289.18, 309.42, 331.08, 354.26, 379.06, 405.59],
    p2=[1.0, 0.97, 0.94, 0.91, 0.88, 0.85, 0.82, 0.79, 0.75, 0.7],
    p3=[245.0, 248.0, 251.0, 254.0, 257.0, 262.0, 268.0, 275.0, 282.0, 290.0],
    p4=[11.74, 12.56, 13.44, 14.38, 15.39, 16.47, 17.62, 18.85, 20.17, 21.58],
    upgrade_costs=list(COSTS_TIER_2),
    is_execute=True,
)

# 9: BillyTower
TOWER_TYPES_DATA[9] = TowerType(
    id=9, name="BillyTower", cost=100,
    p1=[127.9, 148.36, 172.1, 199.64, 231.58, 268.63, 311.61, 361.47, 419.31, 486.4],
    p2=[1.0, 0.97, 0.94, 0.91, 0.88, 0.85, 0.82, 0.79, 0.75, 0.7],
    p3=[245.0, 248.0, 251.0, 254.0, 257.0, 262.0, 268.0, 275.0, 282.0, 290.0],
    is_billy=True,
)

# 10: DroneHiveTower — p1/p2/p3 сама башня, p4/p5 дроны (глобальный радиус)
TOWER_TYPES_DATA[10] = TowerType(
    id=10, name="DroneHiveTower", cost=400,
    p1=[23.58, 27.12, 31.19, 35.87, 41.25, 47.44, 54.56, 62.74, 72.15, 82.97],
    p2=[1.0, 0.97, 0.94, 0.91, 0.88, 0.85, 0.82, 0.79, 0.75, 0.7],
    p3=[245.0, 248.0, 251.0, 254.0, 257.0, 262.0, 268.0, 275.0, 282.0, 290.0],
    p4=[127.9, 148.36, 172.1, 199.64, 231.58, 268.63, 311.61, 361.47, 419.31, 486.4],
    p5=[0.6, 0.58, 0.56, 0.54, 0.52, 0.5, 0.48, 0.46, 0.44, 0.42],
    upgrade_costs=list(COSTS_TIER_3),
    is_drone=True,
    is_aoe=True,
)

# 11: LinkTower (бафф соседей)
TOWER_TYPES_DATA[11] = TowerType(
    id=11, name="LinkTower", cost=100,
    p1=[0.05, 0.06, 0.07, 0.08, 0.09, 0.10, 0.11, 0.12, 0.13, 0.15],
    p2=[1.0, 0.97, 0.94, 0.91, 0.88, 0.85, 0.82, 0.79, 0.75, 0.7],
    p3=[128.0] * 10,
    is_link=True,
)

TOTAL_TOWER_TYPES = len(TOWER_TYPES_DATA)
MAX_TOWER_LEVEL = 9


# ============================================================================
# ВРАГИ
# ============================================================================
@dataclass
class EnemyType:
    id: int
    name: str
    base_hp: float
    speed: float          # пиксели/сек
    reward: float
    is_boss: bool = False

    @property
    def speed_cells(self) -> float:
        return self.speed / 64.0


ENEMY_TYPES_DATA: Dict[int, EnemyType] = {
    0: EnemyType(0, "Basic", 85, 155, 10.5),
    1: EnemyType(1, "Fast", 90, 145, 11),
    2: EnemyType(2, "Strong", 90, 160, 11.5),
    3: EnemyType(3, "Tank", 130, 190, 12),
    4: EnemyType(4, "Runner", 135, 120, 13),
    5: EnemyType(5, "Elite", 135, 200, 13),
    6: EnemyType(6, "Swarm", 200, 210, 13),
    7: EnemyType(7, "Animal", 400, 150, 15),
    8: EnemyType(8, "Boss", 1100, 140, 20, is_boss=True),
}
BOSS_ENEMY_ID = 8
REGULAR_ENEMY_IDS = list(range(0, 8))


# ============================================================================
# МЕТА-ПРИЗНАКИ КОЛОДЫ (9) и КАРТЫ (4) — универсальные (без обобщённого дохода)
# ============================================================================
def compute_deck_meta(deck: List[int]) -> np.ndarray:
    """9 мета-признаков колоды для глобального вектора."""
    if not deck:
        return np.zeros(DECK_META_FEATURES, dtype=np.float32)

    types = [TOWER_TYPES_DATA[t] for t in deck]
    has_damage = float(any(not t.is_income for t in types))
    has_aoe = float(any(t.is_aoe for t in types))
    has_slow = float(any(t.is_slow or t.is_push for t in types))
    has_income = float(any(t.is_income for t in types))
    has_special = float(any(t.is_poison or t.is_execute or t.is_crossbow for t in types))
    has_trap = float(any(t.is_trap for t in types))

    costs = [t.cost for t in types]
    avg_cost = float(np.mean(costs)) / 500.0

    dps_vals = [t.get_dps(0) for t in types]
    max_dps = float(max(dps_vals)) / 100.0

    roles = set()
    for t in types:
        if t.is_income:
            roles.add("income")
        elif t.is_slow or t.is_push:
            roles.add("cc")
        elif t.is_aoe:
            roles.add("aoe")
        elif t.is_link or t.is_drone:
            roles.add("support")
        else:
            roles.add("dps")
    diversity = len(roles) / 5.0

    return np.array([has_damage, has_aoe, has_slow, has_income, has_special,
                     has_trap, avg_cost, max_dps, diversity], dtype=np.float32)


def compute_map_meta(map_matrix: np.ndarray, path: List[Tuple[int, int]]) -> np.ndarray:
    """4 мета-признака карты: длина пути, извилистость, близость застройки, открытость."""
    H, W = map_matrix.shape
    path_length_norm = len(path) / (H * W) if path else 0.0

    num_turns = 0
    if len(path) >= 3:
        for i in range(1, len(path) - 1):
            prev_dir = (path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1])
            next_dir = (path[i + 1][0] - path[i][0], path[i + 1][1] - path[i][1])
            if prev_dir != next_dir:
                num_turns += 1
    num_turns_norm = num_turns / max(1, len(path))

    adj_build = 0
    for px, py in path:
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nx, ny = px + dx, py + dy
            if 0 <= nx < H and 0 <= ny < W and map_matrix[nx, ny] == 0:
                adj_build += 1
    adj_build_norm = adj_build / max(1, len(path) * 4)

    buildable = int(np.sum(map_matrix == 0))
    openness = buildable / (H * W)

    return np.array([path_length_norm, num_turns_norm, adj_build_norm, openness],
                    dtype=np.float32)

