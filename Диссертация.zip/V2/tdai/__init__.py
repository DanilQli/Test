"""
tdai — Tower Defense AI. Компактная раскладка: 4 модуля + этот файл.

    tdai/data.py   данные игры: баланс (заморожен), карты, башни, враги, IGameAdapter
    tdai/sim.py    симулятор (карта/враги/башни/волны) + среда TDEnv (маски, награды)
    tdai/agent.py  адаптер -> граф -> батчи -> сеть (GNN + GTrXL + attention)
    tdai/train.py  буфер/GAE + PPO + векторные среды + метрики PNG + тренер

Старые пути (tdai.env, tdai.nets, tdai.trainer, ...) оставлены алиасами,
чтобы прежние импорты не ломались.
"""
__version__ = "3.0.0"

import importlib as _importlib
import sys as _sys

from . import data, sim, agent, train  # noqa: F401
from .data import (  # noqa: F401
    IGameAdapter, ActionFlags, TowerRole, UniversalTowerStats, PlacedTowerInfo,
    UniversalEnemyStats, GLOBAL_STATE_DEFAULTS, MAX_DECK_SIZE, N_ACTION_TYPES,
    IDLE, BUILD, UPGRADE, SELL, MAPS, MAPS_TRAIN, MAPS_TEST,
    TOWER_TYPES_DATA, ENEMY_TYPES_DATA, MAX_TOWER_LEVEL,
)
from .sim import TDEnv, EnvConfig  # noqa: F401
from .agent import (  # noqa: F401
    TDGameAdapter, MapToGraphConverter, PolicyConfig, UniversalTDPolicy,
)
from .train import (  # noqa: F401
    SequencePPOBuffer, BufferStateError, Segment, PPOConfig, sequence_ppo_update,
    TrainConfig, Trainer, Curriculum, DummyVecEnv, SubprocVecEnv, GraphEnv,
    make_env_fn,
)

_ALIASES = {
    "constants": "data", "interfaces": "data", "maps": "data", "game_data": "data",
    "env": "sim",
    "adapter": "agent", "graph": "agent", "batching": "agent", "nets": "agent",
    "buffer": "train", "ppo": "train", "vecenv": "train", "metrics": "train",
    "trainer": "train",
}
for _old, _new in _ALIASES.items():
    _sys.modules.setdefault(f"{__name__}.{_old}", _importlib.import_module(f".{_new}",
                                                                           __name__))
del _old, _new, _sys, _importlib
