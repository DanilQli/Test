"""
АГЕНТ: адаптер -> граф -> батчи -> сеть (GNN + GTrXL + attention).

Собран склейкой файлов: adapter, graph, batching, nets
"""
from __future__ import annotations

from .data import ActionFlags, BUILD, GLOBAL_BASE_FEATURES, GLOBAL_FEATURES, IDLE, IGameAdapter, LOG_DAMAGE_CAP, LOG_DPS_CAP, LOG_HP_CAP, LOG_KILLS_CAP, MASKED_LOGIT, MAX_DECK_SIZE, MAX_TOWERS, NODE_FEATURES_DIM, N_ACTION_TYPES, PlacedTowerInfo, SELL, TOWER_PROPS_DIM, TOWER_TYPES_DATA, TowerRole, UPGRADE, UniversalEnemyStats, UniversalTowerStats, compute_deck_meta, compute_map_meta

# ============================================================================
# СЕКЦИЯ: adapter.py
# ============================================================================
from typing import Dict, List, Optional

import numpy as np



class TDGameAdapter(IGameAdapter):
    """Адаптер тренажёрной среды TDEnv."""

    def __init__(self, env):
        self.env = env
        self._stats_cache: Dict[int, UniversalTowerStats] = {}

    # ---------------- карта ----------------
    def get_map_grid(self) -> np.ndarray:
        return self.env.map_matrix

    def get_path(self):
        return self.env.map_sim.path

    # ---------------- башни ----------------
    def _to_stats(self, tid: int) -> UniversalTowerStats:
        cached = self._stats_cache.get(tid)
        if cached is not None:
            return cached

        tt = TOWER_TYPES_DATA[tid]
        if tt.is_income:
            role = TowerRole.INCOME
        elif tt.is_slow or tt.is_push or tt.is_trap:
            role = TowerRole.CONTROL
        elif tt.is_link or tt.is_drone:
            role = TowerRole.SUPPORT
        elif tt.is_aoe:
            role = TowerRole.AOE
        else:
            role = TowerRole.DPS

        stats = UniversalTowerStats(
            uid=int(tt.id),
            cost=float(tt.cost),
            damage=float(tt.get_damage(0)),
            rof=float(max(0.05, tt.get_rof(0))),
            range_val=float(tt.get_range(0)),
            role=role,
            has_special=bool(tt.is_poison or tt.is_execute or tt.is_crossbow or tt.is_billy),
            max_level=int(len(tt.upgrade_costs)),
            upgrade_costs=[float(c) for c in tt.upgrade_costs],
        )
        self._stats_cache[tid] = stats
        return stats

    def get_deck_stats(self) -> List[UniversalTowerStats]:
        return [self._to_stats(tid) for tid in self.env.deck]

    def get_placed_towers(self) -> List[PlacedTowerInfo]:
        out = []
        max_level = self.env.config.max_tower_level
        for t in self.env.towers:
            out.append(PlacedTowerInfo(
                x=int(t.x),
                y=int(t.y),
                stats=self._to_stats(t.type.id),
                level=int(t.level),
                total_damage=float(t.total_damage),
                current_upgrade_cost=float(t.get_upgrade_cost()),
                can_upgrade=bool(t.level < max_level),
                tower_id=int(t.tower_id),
            ))
        return out

    def get_enemies(self) -> List[UniversalEnemyStats]:
        em = self.env.enemy_manager
        n = em.count
        out = []
        path_len = max(1, em.path_length)
        for i in range(n):
            if em.hp[i] <= 0:
                continue
            out.append(UniversalEnemyStats(
                hp=float(em.hp[i]),
                max_hp=float(em.max_hp[i]),
                speed=float(em.speed[i]),
                position=(float(em.pos_x[i]), float(em.pos_y[i])),
                progress=float((em.cell_index[i] + em.progress[i]) / path_len),
            ))
        return out

    # ---------------- глобальное состояние ----------------
    def get_global_state(self) -> Dict[str, float]:
        env = self.env
        costs = [TOWER_TYPES_DATA[t].cost for t in env.deck] or [500.0]
        ranges = [TOWER_TYPES_DATA[t].get_range(0) for t in env.deck
                  if not TOWER_TYPES_DATA[t].is_income] or [3.0]
        return {
            "money": float(env.money),
            "wave": float(env.current_wave),
            "max_waves": float(env.config.max_waves),
            "hp": float(env.base_hp),
            "max_hp": float(env.config.starting_hp),
            "wave_active": 1.0 if env.wave_active else 0.0,
            "max_tower_level": float(env.config.max_tower_level),
            "max_tower_cost": float(max(costs)),
            "min_build_cost": float(min(costs)),
            "min_tower_range": float(min(ranges)),
            "builds_this_wave": float(env.builds_this_wave),
            "max_builds_per_wave": float(env.config.max_builds_per_wave),
            "current_towers": float(len(env.towers)),
            "max_towers_on_map": float(env.config.max_towers_on_map),
            "total_kills": float(env.total_kills),
            "total_damage": float(env.total_damage),
            "total_upgrades": float(env.total_upgrades),
            "difficulty": float(env.difficulty),
            "time": float(env.time),
        }

    def get_action_flags(self) -> ActionFlags:
        return ActionFlags(enable_sell=bool(self.env.config.enable_sell),
                           enable_upgrade=True,
                           enable_build=True)

    def get_last_actions(self) -> List[int]:
        return list(self.env.last_actions)

    def get_action_masks(self) -> Dict[str, np.ndarray]:
        env = self.env
        build = env.build_mask_matrix()          # [N, deck_size]
        return {
            "build": build,
            "upgrade": env.upgrade_mask(),
            "sell": env.sell_mask(),
        }

    def get_deck_meta(self) -> np.ndarray:
        return compute_deck_meta(self.env.deck)

    def get_map_meta(self) -> np.ndarray:
        return compute_map_meta(self.env.map_matrix, self.env.map_sim.path)

    def get_deck_ids(self) -> Optional[List[int]]:
        return list(self.env.deck)

    def invalidate(self):
        self._stats_cache.clear()

# ============================================================================
# СЕКЦИЯ: graph.py
# ============================================================================
from typing import Dict, List, Optional, Tuple

import numpy as np


CELL_EMPTY = 0
CELL_ROAD = 1
CELL_OBSTACLE = 2

INTERACTION_RADIUS = 3.5   # средний радиус поражения башен (клетки)


class MapToGraphConverter:
    """Преобразует состояние игры (через адаптер) в numpy-граф."""

    NODE_FEATURES_DIM = NODE_FEATURES_DIM
    GLOBAL_FEATURES_DIM = GLOBAL_FEATURES

    def __init__(self):
        self._edge_cache: Dict[Tuple, np.ndarray] = {}
        self._path_cache: Dict[Tuple, np.ndarray] = {}

    # ------------------------------------------------------------------ edges
    def _build_edges(self, H: int, W: int, path: List[Tuple[int, int]]) -> np.ndarray:
        key = (H, W, tuple(map(tuple, path)) if path else ())
        cached = self._edge_cache.get(key)
        if cached is not None:
            return cached

        src: List[int] = []
        dst: List[int] = []

        # 1) сетка (4-соседство, двунаправленное)
        for i in range(H):
            for j in range(W):
                node = i * W + j
                if i + 1 < H:
                    src.append(node); dst.append(node + W)
                    src.append(node + W); dst.append(node)
                if j + 1 < W:
                    src.append(node); dst.append(node + 1)
                    src.append(node + 1); dst.append(node)

        # 2) взаимодействие дорога <-> клетки постройки
        if path:
            path_nodes = [(px, py, px * W + py) for px, py in path]
            path_set = set(map(tuple, path))
            r2 = INTERACTION_RADIUS ** 2
            for i in range(H):
                for j in range(W):
                    if (i, j) in path_set:
                        continue
                    build_node = i * W + j
                    for px, py, pnode in path_nodes:
                        if (i - px) ** 2 + (j - py) ** 2 <= r2:
                            src.append(pnode); dst.append(build_node)
                            src.append(build_node); dst.append(pnode)

        edge_index = np.array([src, dst], dtype=np.int64)
        if edge_index.size == 0:
            edge_index = np.zeros((2, 0), dtype=np.int64)
        self._edge_cache[key] = edge_index
        return edge_index

    def _path_indices(self, path: List[Tuple[int, int]], W: int) -> np.ndarray:
        key = (tuple(map(tuple, path)) if path else (), W)
        cached = self._path_cache.get(key)
        if cached is not None:
            return cached
        arr = (np.array([x * W + y for x, y in path], dtype=np.int64)
               if path else np.zeros(0, dtype=np.int64))
        self._path_cache[key] = arr
        return arr

    # ------------------------------------------------------------------ nodes
    def _node_features(self, grid: np.ndarray, towers, enemies,
                       path: List[Tuple[int, int]],
                       max_tower_level: int) -> Tuple[np.ndarray, np.ndarray]:
        H, W = grid.shape
        N = H * W
        x = np.zeros((N, NODE_FEATURES_DIM), dtype=np.float32)
        flat = grid.reshape(-1)

        # [0] дорога, [1] препятствие
        x[flat == CELL_ROAD, 0] = 1.0
        x[flat == CELL_OBSTACLE, 1] = 1.0

        # [2..6] башни
        tower_types = np.full(N, -1, dtype=np.int32)
        for t in towers:
            idx = int(t.x) * W + int(t.y)
            if not (0 <= idx < N):
                continue
            tower_types[idx] = int(t.stats.uid)
            x[idx, 2] = 1.0
            x[idx, 3] = t.level / max(1, max_tower_level)
            x[idx, 4] = min(1.0, np.log1p(t.stats.get_dps()) / LOG_DPS_CAP)
            x[idx, 5] = min(1.0, t.stats.range_val / 10.0)
            x[idx, 6] = float(t.stats.role.value)

        # [7..8] враги
        if enemies:
            ex = np.array([int(round(e.position[0])) for e in enemies], dtype=np.int64)
            ey = np.array([int(round(e.position[1])) for e in enemies], dtype=np.int64)
            ehp = np.array([e.hp for e in enemies], dtype=np.float32)
            ex = np.clip(ex, 0, H - 1)
            ey = np.clip(ey, 0, W - 1)
            eidx = ex * W + ey
            counts = np.bincount(eidx, minlength=N).astype(np.float32)
            x[:, 7] = np.minimum(counts / 10.0, 1.0)
            hp_sum = np.zeros(N, dtype=np.float32)
            np.add.at(hp_sum, eidx, ehp)
            x[:, 8] = np.minimum(np.log1p(hp_sum) / LOG_HP_CAP, 1.0)

        # [9..10] координаты
        rows = np.repeat(np.arange(H, dtype=np.float32) / max(1, H - 1), W)
        cols = np.tile(np.arange(W, dtype=np.float32) / max(1, W - 1), H)
        x[:, 9] = rows
        x[:, 10] = cols

        # [11] прогресс по пути (только клетки дороги)
        if path:
            pidx = self._path_indices(path, W)
            pidx = pidx[(pidx >= 0) & (pidx < N)]
            if pidx.size:
                x[pidx, 11] = np.linspace(0.0, 1.0, pidx.size).astype(np.float32)

        return x, tower_types

    # ------------------------------------------------------------------ globals
    def _global_features(self, adapter: IGameAdapter, state: Dict[str, float],
                         towers, enemies, deck_size: int,
                         path: List[Tuple[int, int]],
                         H: int, W: int) -> np.ndarray:
        g = np.zeros(GLOBAL_FEATURES, dtype=np.float32)
        max_level = max(1.0, float(state.get("max_tower_level", 9.0)))
        max_cost = max(1.0, float(state.get("max_tower_cost", 500.0)))
        max_waves = max(1.0, float(state.get("max_waves", 80.0)))
        max_towers = max(1.0, float(state.get("max_towers_on_map", 50.0)))

        levels = [t.level for t in towers]
        combat = [t for t in towers if t.stats.role.value != 0.75]  # не INCOME
        avg_level = float(np.mean(levels)) if levels else 0.0
        min_level = float(min(levels)) if levels else 0.0
        spread = ((max(levels) - min(levels)) / max_level) if levels else 0.0

        g[0] = min(float(state.get("money", 0.0)) / (max_cost * 10.0), 5.0)
        g[1] = float(state.get("wave", 0.0)) / max_waves
        g[2] = float(state.get("hp", 0.0)) / max(1.0, float(state.get("max_hp", 10.0)))
        g[3] = float(np.log1p(len(enemies)) / np.log1p(100.0))
        g[4] = len(towers) / max_towers
        g[5] = min(1.0, float(np.log1p(float(state.get("total_damage", 0.0))) /
                              LOG_DAMAGE_CAP))
        g[6] = len({t.stats.uid for t in towers}) / max(1, deck_size)
        g[7] = float(state.get("wave_active", 0.0))
        g[8] = avg_level / max_level
        g[9] = min_level / max_level
        g[10] = spread
        g[11] = float(np.log1p(len([t for t in towers if t.stats.role.value == 0.75])) /
                      np.log1p(10.0))
        g[12] = float(state.get("builds_this_wave", 0.0)) / max(
            1.0, float(state.get("max_builds_per_wave", 6.0)))
        g[13] = min(1.0, float(np.log1p(float(state.get("total_kills", 0.0))) / LOG_KILLS_CAP))
        g[14] = len(combat) / max_towers
        g[15] = max_waves / 100.0
        g[16] = len(path) / max(1, H * W)
        g[17] = (float(state.get("total_upgrades", 0.0)) /
                 max(1, len(towers)) / max_level)

        last = list(adapter.get_last_actions())[-5:]
        for i in range(5):
            v = last[i] / 3.0 if i < len(last) else 0.0
            g[GLOBAL_BASE_FEATURES - 5 + i] = float(v)

        deck_meta = np.asarray(adapter.get_deck_meta(), dtype=np.float32).ravel()
        map_meta = np.asarray(adapter.get_map_meta(), dtype=np.float32).ravel()
        g[GLOBAL_BASE_FEATURES:GLOBAL_BASE_FEATURES + 9] = deck_meta[:9]
        g[GLOBAL_BASE_FEATURES + 9:GLOBAL_BASE_FEATURES + 13] = map_meta[:4]
        return g

    # ------------------------------------------------------------------ public
    def convert(self, adapter: IGameAdapter) -> Dict[str, np.ndarray]:
        grid = np.asarray(adapter.get_map_grid(), dtype=np.int32)
        H, W = grid.shape
        N = H * W
        path = list(adapter.get_path())
        towers = adapter.get_placed_towers()
        enemies = adapter.get_enemies()
        state = adapter.get_global_state_filled()
        flags = adapter.get_action_flags()

        edge_index = self._build_edges(H, W, path)
        x, tower_types = self._node_features(
            grid, towers, enemies, path,
            int(state.get("max_tower_level", 9.0)))

        masks = adapter.get_action_masks()
        build_masks = np.asarray(masks["build"], dtype=bool)
        if build_masks.ndim == 1:
            build_masks = build_masks[:, None]
        if build_masks.shape[0] != N:
            build_masks = build_masks.reshape(N, -1)
        upgrade_mask = np.asarray(masks["upgrade"], dtype=bool).reshape(-1)
        sell_mask = np.asarray(masks["sell"], dtype=bool).reshape(-1)
        if not flags.enable_sell:
            sell_mask = np.zeros_like(sell_mask)

        global_features = self._global_features(
            adapter, state, towers, enemies, build_masks.shape[1], path, H, W)

        deck_vec, deck_mask = adapter.deck_vector(MAX_DECK_SIZE)

        return {
            "x": x.astype(np.float32),
            "edge_index": edge_index,
            "build_masks": build_masks,
            "upgrade_mask": upgrade_mask.astype(bool),
            "sell_mask": sell_mask.astype(bool),
            "global_features": global_features,
            "path_indices": self._path_indices(path, W),
            "tower_types_on_nodes": tower_types.astype(np.int32),
            "action_flags": flags.as_array(),
            "deck_vec": deck_vec.astype(np.float32),
            "deck_mask": deck_mask.astype(bool),
            "num_nodes": N,
            "H": H,
            "W": W,
        }

# ============================================================================
# СЕКЦИЯ: batching.py
# ============================================================================
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch



def _pad_deck_masks(build_masks: np.ndarray) -> np.ndarray:
    """[N, deck] -> [N, MAX_DECK_SIZE] (нулями справа)."""
    N, deck = build_masks.shape
    if deck == MAX_DECK_SIZE:
        return build_masks.astype(bool)
    out = np.zeros((N, MAX_DECK_SIZE), dtype=bool)
    keep = min(deck, MAX_DECK_SIZE)
    out[:, :keep] = build_masks[:, :keep]
    return out


def build_graph_batch(graphs: Sequence[Dict[str, np.ndarray]],
                      device: torch.device) -> Dict[str, torch.Tensor]:
    """Собирает батч графов (один временной шаг, B сред)."""
    n = len(graphs)
    assert n > 0

    node_counts = [g["x"].shape[0] for g in graphs]
    edge_counts = [g["edge_index"].shape[1] for g in graphs]
    path_counts = [g["path_indices"].shape[0] for g in graphs]
    total_nodes = int(sum(node_counts))
    total_edges = int(sum(edge_counts))
    total_path = int(sum(path_counts))
    feat_dim = graphs[0]["x"].shape[1]

    x = np.empty((total_nodes, feat_dim), dtype=np.float32)
    edge_index = np.empty((2, total_edges), dtype=np.int64)
    batch = np.empty(total_nodes, dtype=np.int64)
    build_masks = np.empty((total_nodes, MAX_DECK_SIZE), dtype=bool)
    upgrade_mask = np.empty(total_nodes, dtype=bool)
    sell_mask = np.empty(total_nodes, dtype=bool)
    tower_types = np.empty(total_nodes, dtype=np.int32)
    path_indices = np.empty(total_path, dtype=np.int64)
    path_ptr = np.zeros(n + 1, dtype=np.int64)
    global_features = np.empty((n, graphs[0]["global_features"].shape[0]), dtype=np.float32)
    deck_vec = np.empty((n, MAX_DECK_SIZE, graphs[0]["deck_vec"].shape[1]), dtype=np.float32)
    deck_mask = np.empty((n, MAX_DECK_SIZE), dtype=bool)
    action_flags = np.empty((n, N_ACTION_TYPES), dtype=bool)

    np_off = ep_off = pp_off = 0
    for i, g in enumerate(graphs):
        nn = node_counts[i]
        ne = edge_counts[i]
        npth = path_counts[i]

        x[np_off:np_off + nn] = g["x"]
        edge_index[:, ep_off:ep_off + ne] = g["edge_index"] + np_off
        batch[np_off:np_off + nn] = i
        build_masks[np_off:np_off + nn] = _pad_deck_masks(g["build_masks"])
        upgrade_mask[np_off:np_off + nn] = g["upgrade_mask"]
        sell_mask[np_off:np_off + nn] = g["sell_mask"]
        tower_types[np_off:np_off + nn] = g["tower_types_on_nodes"]

        path_ptr[i] = pp_off
        if npth:
            path_indices[pp_off:pp_off + npth] = g["path_indices"] + np_off
            pp_off += npth

        global_features[i] = g["global_features"]
        deck_vec[i] = g["deck_vec"]
        deck_mask[i] = g["deck_mask"]
        action_flags[i] = g["action_flags"]

        np_off += nn
        ep_off += ne
    path_ptr[n] = pp_off

    path_batch = np.repeat(np.arange(n, dtype=np.int64),
                           np.diff(path_ptr))

    def t(arr, dtype=torch.float32):
        return torch.as_tensor(arr, device=device).to(dtype)

    return {
        "x": t(x),
        "edge_index": t(edge_index, torch.long),
        "batch": t(batch, torch.long),
        "build_masks": t(build_masks, torch.bool),
        "upgrade_mask": t(upgrade_mask, torch.bool),
        "sell_mask": t(sell_mask, torch.bool),
        "tower_types_on_nodes": t(tower_types, torch.long),
        "path_indices": t(path_indices, torch.long),
        "path_batch": t(path_batch, torch.long),
        "path_ptr": t(path_ptr, torch.long),
        "global_features": t(global_features),
        "deck_vec": t(deck_vec),
        "deck_mask": t(deck_mask, torch.bool),
        "action_flags": t(action_flags, torch.bool),
        "num_graphs": n,
    }


def stack_memories(segment_memories: List[Optional[List[torch.Tensor]]],
                   hidden_dim: int, device: torch.device
                   ) -> Tuple[Optional[List[torch.Tensor]], Optional[torch.Tensor]]:
    """
    Паддинг стартовой памяти GTrXL для батча сегментов.

    segment_memories[b] — список по слоям тензоров [1, L_b, H] (или None).
    Возвращает (список [n_layers] тензоров [B, Lmax, H], маска [B, Lmax]).
    Паддинг слева (старые позиции), маска отмечает реальные позиции.
    """
    if not segment_memories:
        return None, None
    sample = next((m for m in segment_memories if m), None)
    if sample is None:
        return None, None

    n_layers = len(sample)
    B = len(segment_memories)
    lengths = np.zeros(B, dtype=np.int64)
    for b, mem in enumerate(segment_memories):
        if not mem:
            continue
        h = mem[0]
        # память хранится как [1, L, H] (или [L, H]) — берём именно длину L
        lengths[b] = 0 if (h is None or h.numel() == 0) else int(h.shape[-2])
    L = int(lengths.max())
    if L == 0:
        return None, None

    mask = torch.zeros(B, L, dtype=torch.bool, device=device)
    for b, ln in enumerate(lengths):
        if ln > 0:
            mask[b, L - ln:] = True

    layers = []
    for l in range(n_layers):
        buf = torch.zeros(B, L, hidden_dim, device=device)
        for b, mem in enumerate(segment_memories):
            if not mem or mem[l] is None or mem[l].numel() == 0:
                continue
            h = mem[l]
            if h.dim() == 3:
                h = h.squeeze(0)
            h = h[-L:]
            buf[b, L - h.size(0):] = h.to(device)
        layers.append(buf)
    return layers, mask


def build_sequence_batch(segments, segment_length: int, device: torch.device,
                         hidden_dim: int) -> Dict:
    """
    Готовит всё для evaluate_sequence: список батчей по времени + действия +
    память + маски длины.
    """
    B = len(segments)
    T = segment_length

    graphs_seq = []
    for t in range(T):
        step_graphs = [seg.graphs[t] if t < len(seg.graphs) else seg.graphs[-1]
                       for seg in segments]
        graphs_seq.append(build_graph_batch(step_graphs, device))

    deck_vec = torch.as_tensor(
        np.stack([seg.deck_vec for seg in segments]), device=device).float()
    deck_mask = torch.as_tensor(
        np.stack([seg.deck_mask for seg in segments]), device=device).bool()

    def to_t(key, dtype):
        return torch.as_tensor(np.stack([getattr(s, key) for s in segments]),
                               device=device).to(dtype)

    memory, memory_mask = stack_memories(
        [seg.hidden_init for seg in segments], hidden_dim, device)

    return {
        "graphs_seq": graphs_seq,
        "deck_vec": deck_vec,
        "deck_mask": deck_mask,
        "action_types": to_t("action_types", torch.long),
        "slots": to_t("slots", torch.long),
        "nodes": to_t("nodes", torch.long),
        "old_log_probs": to_t("log_probs", torch.float32),
        "old_lp_type": to_t("log_probs_type", torch.float32),
        "old_lp_slot": to_t("log_probs_slot", torch.float32),
        "old_lp_node": to_t("log_probs_node", torch.float32),
        "old_values": to_t("values", torch.float32),
        "returns": to_t("returns", torch.float32),
        "advantages": to_t("advantages", torch.float32),
        "dones": to_t("dones", torch.bool),
        "lengths": torch.as_tensor(np.array([s.length for s in segments], dtype=np.int64),
                                   device=device),
        "aux_survival": to_t("aux_survival", torch.float32),
        "aux_money": to_t("aux_money", torch.float32),
        "aux_kills": to_t("aux_kills", torch.float32),
        "credit_targets": to_t("credit_targets", torch.float32),
        "hidden_init": memory,
        "hidden_mask": memory_mask,
    }

# ============================================================================
# СЕКЦИЯ: nets.py
# ============================================================================
import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


# ============================================================================
# Scatter-утилиты
# ============================================================================
def scatter_softmax(src: torch.Tensor, index: torch.Tensor, num_nodes: int) -> torch.Tensor:
    """Softmax по группам для [E, ...] тензоров (index — индекс группы)."""
    if src.numel() == 0:
        return src
    shape = list(src.shape)
    shape[0] = num_nodes
    src_max = torch.full(shape, float("-inf"), device=src.device, dtype=src.dtype)
    idx = index.view(-1, *([1] * (src.dim() - 1))).expand_as(src)
    src_max = src_max.scatter_reduce(0, idx, src, reduce="amax", include_self=True)
    src_max = src_max.gather(0, idx)
    src_max = torch.where(torch.isfinite(src_max), src_max, torch.zeros_like(src_max))
    out = (src - src_max).exp()
    denom = torch.zeros(shape, device=src.device, dtype=src.dtype)
    denom = denom.index_add(0, index, out)
    denom = denom.gather(0, idx)
    return out / (denom + 1e-16)


def segment_softmax(logits: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    """Softmax по последней размерности с маской (mask: True = разрешено)."""
    neg = torch.full_like(logits, MASKED_LOGIT)
    logits = torch.where(mask, logits, neg)
    return torch.softmax(logits, dim=-1)


# ============================================================================
# GNN слои
# ============================================================================
class GraphSAGEConv(nn.Module):
    """mean-aggregation + self-loop + LayerNorm + GELU."""

    def __init__(self, in_dim: int, out_dim: int, dropout: float = 0.0):
        super().__init__()
        self.lin_self = nn.Linear(in_dim, out_dim)
        self.lin_neigh = nn.Linear(in_dim, out_dim, bias=False)
        self.norm = nn.LayerNorm(out_dim)
        self.dropout = dropout

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        N = x.size(0)
        if edge_index.numel() == 0:
            return F.gelu(self.norm(self.lin_self(x)))

        src, dst = edge_index[0], edge_index[1]
        # self-loop без дублирования: агрегируем соседей отдельно
        agg = torch.zeros_like(x).index_add(0, dst, x[src])
        deg = torch.zeros(N, device=x.device, dtype=x.dtype).index_add(
            0, dst, torch.ones(dst.size(0), device=x.device, dtype=x.dtype))
        agg = agg / deg.clamp_min(1.0).unsqueeze(-1)

        out = self.lin_self(x) + self.lin_neigh(agg)
        out = self.norm(out)
        out = F.dropout(out, p=self.dropout, training=self.training)
        return F.gelu(out)


class GATv2Conv(nn.Module):
    """GATv2: attention = a^T LeakyReLU(W1 x_i + W2 x_j), softmax по dst."""

    def __init__(self, in_dim: int, out_dim: int, heads: int = 4,
                 dropout: float = 0.0):
        super().__init__()
        assert out_dim % heads == 0
        self.heads = heads
        self.d_head = out_dim // heads
        self.lin_src = nn.Linear(in_dim, out_dim, bias=False)
        self.lin_dst = nn.Linear(in_dim, out_dim, bias=False)
        self.att = nn.Parameter(torch.zeros(heads, self.d_head))
        self.bias = nn.Parameter(torch.zeros(out_dim))
        self.norm = nn.LayerNorm(out_dim)
        self.dropout = dropout
        nn.init.xavier_uniform_(self.lin_src.weight)
        nn.init.xavier_uniform_(self.lin_dst.weight)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        N = x.size(0)
        if edge_index.numel() == 0:
            return F.gelu(self.norm(self.lin_src(x) + self.bias))
        src, dst = edge_index[0], edge_index[1]
        xs = self.lin_src(x).view(N, self.heads, self.d_head)
        xd = self.lin_dst(x).view(N, self.heads, self.d_head)

        e = F.leaky_relu(xs[src] + xd[dst], 0.2)
        alpha = (e * self.att.unsqueeze(0)).sum(-1)            # [E, H]
        alpha = scatter_softmax(alpha, dst, N)
        alpha = F.dropout(alpha, p=self.dropout, training=self.training)

        msg = xs[src] * alpha.unsqueeze(-1)
        out = torch.zeros(N, self.heads, self.d_head, device=x.device, dtype=x.dtype)
        out = out.index_add(0, dst, msg).reshape(N, self.heads * self.d_head)
        out = out + self.bias
        return F.gelu(self.norm(out))


class MapGNN(nn.Module):
    """
    Энкодер карты: статические признаки (дорога/препятствие/координаты)
    кодируются отдельно от динамических (башни/враги), затем GNN-слои,
    затем 3 пулинга (mean/max/sum) -> graph embedding.
    """

    STATIC_DIM = 3     # road, obstacle, (row,col) считаются динамикой? -> см. ниже

    def __init__(self, node_features_dim: int, hidden_dim: int, output_dim: int,
                 num_layers: int = 4, gnn_type: str = "sage", heads: int = 4,
                 dropout: float = 0.1):
        super().__init__()
        # статика: [0]road [1]obstacle [9]row [10]col [11]path_progress
        self.static_idx = [0, 1, 9, 10, 11]
        self.dynamic_idx = [i for i in range(node_features_dim) if i not in self.static_idx]

        self.static_enc = nn.Linear(len(self.static_idx), hidden_dim // 2)
        self.dynamic_enc = nn.Linear(len(self.dynamic_idx), hidden_dim // 2)
        self.combiner = nn.Sequential(nn.LayerNorm(hidden_dim), nn.GELU(),
                                      nn.Dropout(dropout))

        self.layers = nn.ModuleList()
        self.norms = nn.ModuleList()
        for _ in range(num_layers):
            if gnn_type == "gat":
                self.layers.append(GATv2Conv(hidden_dim, hidden_dim, heads=heads,
                                             dropout=dropout))
            else:
                self.layers.append(GraphSAGEConv(hidden_dim, hidden_dim, dropout=dropout))
            self.norms.append(nn.LayerNorm(hidden_dim))

        self.output_proj = nn.Sequential(
            nn.Linear(hidden_dim * 3, output_dim),
            nn.LayerNorm(output_dim),
            nn.GELU(),
        )

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor,
                batch: torch.Tensor, num_graphs: int) -> Tuple[torch.Tensor, torch.Tensor]:
        h_static = self.static_enc(x[:, self.static_idx])
        h_dyn = self.dynamic_enc(x[:, self.dynamic_idx])
        h = self.combiner(torch.cat([h_static, h_dyn], dim=-1))

        for layer, norm in zip(self.layers, self.norms):
            h_res = h
            h = layer(h, edge_index)
            h = norm(h)
            h = F.gelu(h + h_res)

        # пулинги
        mean_pool = torch.zeros(num_graphs, h.size(-1), device=h.device, dtype=h.dtype)
        mean_pool = mean_pool.index_add(0, batch, h)
        counts = torch.zeros(num_graphs, device=h.device, dtype=h.dtype).index_add(
            0, batch, torch.ones_like(batch, dtype=h.dtype))
        mean_pool = mean_pool / counts.clamp_min(1.0).unsqueeze(-1)

        max_pool = torch.full((num_graphs, h.size(-1)), torch.finfo(h.dtype).min,
                              device=h.device, dtype=h.dtype)
        max_pool = max_pool.scatter_reduce(0, batch.unsqueeze(-1).expand_as(h), h,
                                           reduce="amax", include_self=True)
        max_pool = torch.where(torch.isfinite(max_pool), max_pool,
                               torch.zeros_like(max_pool))

        # третий пулинг — сумма (масштабированная), а не повторный mean:
        # mean/max/sum вместе дают сети сигнал об «объёме» карты,
        # но sum/sqrt(n) не взрывается при росте числа узлов.
        sum_pool = torch.zeros(num_graphs, h.size(-1), device=h.device, dtype=h.dtype)
        sum_pool = sum_pool.index_add(0, batch, h)
        sum_pool = sum_pool / counts.clamp_min(1.0).sqrt().unsqueeze(-1)

        graph_emb = self.output_proj(torch.cat([mean_pool, max_pool, sum_pool], dim=-1))
        return graph_emb, h


class PathAwareGNN(nn.Module):
    """GNN по узлам дороги: даёт глобальный вектор «состояния пути» на граф."""

    def __init__(self, hidden_dim: int, output_dim: int, num_layers: int = 2,
                 dropout: float = 0.0):
        super().__init__()
        self.layers = nn.ModuleList([
            GraphSAGEConv(hidden_dim, hidden_dim, dropout) for _ in range(num_layers)
        ])
        self.norms = nn.ModuleList([nn.LayerNorm(hidden_dim) for _ in range(num_layers)])
        self.output_proj = nn.Sequential(
            nn.Linear(hidden_dim, output_dim), nn.LayerNorm(output_dim), nn.GELU())
        self.empty_emb = nn.Parameter(torch.zeros(output_dim))

    def forward(self, node_emb: torch.Tensor, path_indices: torch.Tensor,
                path_batch: torch.Tensor, num_graphs: int) -> torch.Tensor:
        if path_indices.numel() == 0:
            return self.empty_emb.unsqueeze(0).expand(num_graphs, -1)

        x = node_emb[path_indices]
        # последовательные рёбра внутри каждого графа
        same = path_batch[:-1] == path_batch[1:]
        valid = torch.nonzero(same, as_tuple=False).view(-1)
        if valid.numel() > 0:
            edge_index = torch.stack([
                torch.cat([valid, valid + 1]),
                torch.cat([valid + 1, valid]),
            ], dim=0)
        else:
            edge_index = torch.zeros(2, 0, dtype=torch.long, device=node_emb.device)

        for layer, norm in zip(self.layers, self.norms):
            res = x
            x = F.gelu(norm(layer(x, edge_index)) + res)

        pooled = torch.zeros(num_graphs, x.size(-1), device=x.device, dtype=x.dtype)
        pooled = pooled.index_add(0, path_batch, x)
        counts = torch.zeros(num_graphs, device=x.device, dtype=x.dtype).index_add(
            0, path_batch, torch.ones_like(path_batch, dtype=x.dtype))
        pooled = pooled / counts.clamp_min(1.0).unsqueeze(-1)

        has_path = (counts > 0).unsqueeze(-1)
        out = self.output_proj(pooled)
        return torch.where(has_path, out, self.empty_emb.unsqueeze(0).expand_as(out))


# ============================================================================
# GTrXL (память + гейтинг + относительные позиции)
# ============================================================================
class GatingMechanism(nn.Module):
    def __init__(self, d_model: int):
        super().__init__()
        self.gate = nn.Linear(d_model * 2, d_model)
        nn.init.zeros_(self.gate.weight)
        nn.init.zeros_(self.gate.bias)

    def forward(self, residual: torch.Tensor, new_value: torch.Tensor) -> torch.Tensor:
        g = torch.sigmoid(self.gate(torch.cat([residual, new_value], dim=-1)))
        return residual + g * new_value


class MemoryAttention(nn.Module):
    """Multi-head attention с относительным позиционным кодированием и маской памяти."""

    def __init__(self, d_model: int, n_heads: int, dropout: float = 0.1,
                 max_len: int = 512):
        super().__init__()
        assert d_model % n_heads == 0
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_head = d_model // n_heads
        self.scale = self.d_head ** -0.5
        self.max_len = max_len

        self.qkv = nn.Linear(d_model, 3 * d_model, bias=False)
        self.o_proj = nn.Linear(d_model, d_model)
        self.rel_pos = nn.Parameter(torch.randn(2 * max_len + 1, self.d_head) * 0.02)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor, memory: Optional[torch.Tensor] = None,
                memory_mask: Optional[torch.Tensor] = None
                ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        x: [B, T, D]
        memory: [B, L, D] (прошлые состояния) или None
        memory_mask: [B, L] bool, True = позиция валидна

        Возвращает (out, new_memory, new_memory_mask).
        """
        B, T, D = x.shape
        if memory is not None and memory.numel() > 0 and memory.size(1) > 0:
            cat = torch.cat([memory, x], dim=1)
            if memory_mask is None:
                memory_mask = torch.ones(B, memory.size(1), dtype=torch.bool,
                                         device=x.device)
            full_mask = torch.cat([
                memory_mask,
                torch.ones(B, T, dtype=torch.bool, device=x.device)
            ], dim=1)
            mem_len = memory.size(1)
        else:
            cat = x
            full_mask = torch.ones(B, T, dtype=torch.bool, device=x.device)
            mem_len = 0

        L = cat.size(1)
        qkv_x = self.qkv(x)
        q = qkv_x[..., :D]
        qkv_cat = self.qkv(cat)
        k = qkv_cat[..., D:2 * D]
        v = qkv_cat[..., 2 * D:]

        q = q.view(B, T, self.n_heads, self.d_head).transpose(1, 2)     # [B,H,T,dh]
        k = k.view(B, L, self.n_heads, self.d_head).transpose(1, 2)
        v = v.view(B, L, self.n_heads, self.d_head).transpose(1, 2)

        attn = torch.matmul(q, k.transpose(-2, -1)) * self.scale         # [B,H,T,L]

        # относительные позиции
        positions = torch.arange(L, device=x.device)
        q_pos = torch.arange(T, device=x.device) + mem_len
        rel = (positions.unsqueeze(0) - q_pos.unsqueeze(1)).clamp(-self.max_len, self.max_len)
        rel = rel + self.max_len
        rel_emb = self.rel_pos[rel]                                      # [T, L, dh]
        attn = attn + torch.einsum("bhtd,tld->bhtl", q, rel_emb)

        # маска памяти
        attn = attn.masked_fill(~full_mask.unsqueeze(1).unsqueeze(2), MASKED_LOGIT)
        attn = torch.softmax(attn, dim=-1)
        attn = self.dropout(attn)
        out = torch.matmul(attn, v)

        out = out.transpose(1, 2).contiguous().view(B, T, D)
        out = self.o_proj(out)

        if mem_len > 0:
            new_memory = cat[:, -self.max_len:, :]
            new_mask = full_mask[:, -self.max_len:]
        else:
            new_memory = cat[:, -self.max_len:, :]
            new_mask = full_mask[:, -self.max_len:]
        return out, new_memory, new_mask


class GTrXLLayer(nn.Module):
    def __init__(self, d_model: int, n_heads: int, d_ff: int, dropout: float):
        super().__init__()
        self.attn = MemoryAttention(d_model, n_heads, dropout)
        self.ff = nn.Sequential(
            nn.Linear(d_model, d_ff), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(d_ff, d_model), nn.Dropout(dropout))
        self.gate_attn = GatingMechanism(d_model)
        self.gate_ff = GatingMechanism(d_model)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)

    def forward(self, x, memory=None, memory_mask=None):
        attn_out, new_mem, new_mask = self.attn(self.norm1(x), memory, memory_mask)
        x = self.gate_attn(x, attn_out)
        x = self.gate_ff(x, self.ff(self.norm2(x)))
        return x, new_mem, new_mask


class GatedTransformerXL(nn.Module):
    """Память + гейтинг. mem_len ограничивает историю."""

    def __init__(self, d_model: int, n_heads: int = 8, n_layers: int = 4,
                 d_ff: Optional[int] = None, dropout: float = 0.1, mem_len: int = 256):
        super().__init__()
        self.d_model = d_model
        self.mem_len = mem_len
        d_ff = d_ff or d_model * 4
        self.layers = nn.ModuleList([
            GTrXLLayer(d_model, n_heads, d_ff, dropout) for _ in range(n_layers)])
        self.final_norm = nn.LayerNorm(d_model)

    def forward(self, x: torch.Tensor, memory: Optional[List[torch.Tensor]] = None,
                memory_mask: Optional[torch.Tensor] = None):
        """
        x: [B, T, D]
        memory: List[[B, L, D]] длины n_layers (или None)
        memory_mask: [B, L] bool
        """
        if memory is None:
            memory = [None] * len(self.layers)
        new_memory: List[torch.Tensor] = []
        masks = []
        for layer, mem in zip(self.layers, memory):
            x, m, mk = layer(x, mem, memory_mask)
            new_memory.append(m)
            masks.append(mk)
        return self.final_norm(x), new_memory, masks[0]

    # ---------------- удобные утилиты памяти ----------------
    def init_memory(self, batch_size: int, device: torch.device):
        return [torch.zeros(batch_size, 0, self.d_model, device=device)
                for _ in self.layers]

    def empty_mask(self, batch_size: int, device: torch.device):
        return torch.zeros(batch_size, 0, dtype=torch.bool, device=device)


# ============================================================================
# Deck attention (q*k по слотам колоды) и Spatial attention (q*k по клеткам)
# ============================================================================
class DeckAttention(nn.Module):
    """
    Само-внимание по слотам колоды + attention-пулинг.

    Работает для любого числа слотов 1..MAX_DECK_SIZE благодаря маске.
    """

    def __init__(self, tower_features_dim: int, hidden_dim: int, n_heads: int = 4,
                 dropout: float = 0.1):
        super().__init__()
        self.slot_dim = hidden_dim // 4
        self.in_proj = nn.Sequential(
            nn.Linear(tower_features_dim, hidden_dim // 2), nn.GELU(),
            nn.Linear(hidden_dim // 2, self.slot_dim))
        self.n_heads = n_heads
        self.q = nn.Linear(self.slot_dim, self.slot_dim)
        self.k = nn.Linear(self.slot_dim, self.slot_dim)
        self.v = nn.Linear(self.slot_dim, self.slot_dim)
        self.ln = nn.LayerNorm(self.slot_dim)
        self.pool_score = nn.Linear(self.slot_dim, 1)
        self.out_proj = nn.Sequential(nn.Linear(self.slot_dim, hidden_dim),
                                      nn.LayerNorm(hidden_dim), nn.GELU())
        self.dropout = nn.Dropout(dropout)

    def forward(self, deck_vec: torch.Tensor, deck_mask: torch.Tensor):
        """
        deck_vec: [B, S, F] (S <= MAX_DECK_SIZE, паддинг нулями)
        deck_mask: [B, S] bool (True = реальный слот)
        Возвращает (slot_emb [B,S,slot_dim], pooled [B, hidden])
        """
        h = self.in_proj(deck_vec)                      # [B,S,slot_dim]
        B, S, _ = h.shape
        dh = self.slot_dim // self.n_heads
        q = self.q(h).view(B, S, self.n_heads, dh).transpose(1, 2)
        k = self.k(h).view(B, S, self.n_heads, dh).transpose(1, 2)
        v = self.v(h).view(B, S, self.n_heads, dh).transpose(1, 2)

        attn = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(dh)   # [B,H,S,S]
        mask = deck_mask.unsqueeze(1).unsqueeze(2) & deck_mask.unsqueeze(1).unsqueeze(-1)
        attn = attn.masked_fill(~mask, MASKED_LOGIT)
        attn = self.dropout(torch.softmax(attn, dim=-1))
        out = torch.matmul(attn, v).transpose(1, 2).reshape(B, S, self.slot_dim)
        slot_emb = self.ln(h + out)

        # attention-пулинг в один вектор колоды
        scores = self.pool_score(slot_emb).squeeze(-1)                 # [B,S]
        scores = scores.masked_fill(~deck_mask, MASKED_LOGIT)
        w = torch.softmax(scores, dim=-1)
        pooled = (slot_emb * w.unsqueeze(-1)).sum(dim=1)
        # если слотов нет (не должно случаться) — нулевой вектор
        pooled = torch.where(deck_mask.any(dim=1, keepdim=True), pooled,
                             torch.zeros_like(pooled))
        return slot_emb, self.out_proj(pooled)


class SpatialNodeAttention(nn.Module):
    """
    q*k: query из контекста+действия, keys — эмбеддинги клеток.
    Возвращает логиты [B, max_nodes] (паддинг = MASKED_LOGIT).
    """

    def __init__(self, hidden_dim: int, action_emb_dim: int, slot_emb_dim: int):
        super().__init__()
        self.q_proj = nn.Linear(hidden_dim, hidden_dim)
        self.k_proj = nn.Linear(hidden_dim, hidden_dim)
        self.score = nn.Sequential(
            nn.Linear(hidden_dim + action_emb_dim + slot_emb_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, 1))

    def forward(self, query: torch.Tensor, node_emb: torch.Tensor,
                batch: torch.Tensor, num_graphs: int,
                action_ctx: torch.Tensor, slot_ctx: torch.Tensor):
        Q = self.q_proj(query)                          # [B, H]
        K = self.k_proj(node_emb)                       # [N, H]
        base = Q[batch] + K                             # [N, H]
        combined = torch.cat([base, action_ctx[batch], slot_ctx[batch]], dim=-1)
        logits = self.score(combined).squeeze(-1)       # [N]

        # группируем в [B, max_nodes]
        counts = torch.bincount(batch, minlength=num_graphs)
        max_nodes = int(counts.max().item()) if counts.numel() else 0
        out = torch.full((num_graphs, max_nodes), MASKED_LOGIT,
                         device=node_emb.device, dtype=node_emb.dtype)
        if max_nodes > 0:
            order = torch.argsort(batch, stable=True)
            sorted_logits = logits[order]
            offsets = torch.cumsum(counts, dim=0) - counts
            sorted_batch = batch[order]
            pos = torch.arange(sorted_logits.size(0), device=node_emb.device) - offsets[sorted_batch]
            out[sorted_batch, pos] = sorted_logits
        return out


# ============================================================================
# Value / Aux heads
# ============================================================================
class PopArtIQNValueHead(nn.Module):
    """V(s) с PopArt-нормализацией + IQN квантили (для распределения)."""

    def __init__(self, input_dim: int, hidden_dim: int = 256, n_quantiles: int = 16,
                 beta: float = 0.005):
        super().__init__()
        self.n_quantiles = n_quantiles
        self.beta = beta

        self.trunk = nn.Sequential(
            nn.Linear(input_dim, hidden_dim * 2), nn.LayerNorm(hidden_dim * 2), nn.GELU(),
            nn.Linear(hidden_dim * 2, hidden_dim * 2), nn.GELU())
        self.out = nn.Sequential(nn.Linear(hidden_dim * 2, hidden_dim), nn.GELU())
        self.value_out = nn.Linear(hidden_dim, 1)

        self.embedding_dim = 64
        self.register_buffer("pi_mult",
                             torch.arange(1, self.embedding_dim + 1).float() * math.pi)
        self.tau_fc = nn.Sequential(nn.Linear(self.embedding_dim, hidden_dim // 2), nn.GELU())
        self.state_fc = nn.Sequential(nn.Linear(input_dim, hidden_dim // 2),
                                      nn.LayerNorm(hidden_dim // 2), nn.GELU())
        self.quantile_out = nn.Linear(hidden_dim // 2, 1)

        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=math.sqrt(2))
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        nn.init.orthogonal_(self.value_out.weight, gain=0.01)
        nn.init.orthogonal_(self.quantile_out.weight, gain=0.01)

        self.register_buffer("mu", torch.zeros(1))
        self.register_buffer("sigma", torch.ones(1))
        self.register_buffer("count", torch.tensor(0.0))

    # ---------------- forward ----------------
    def forward(self, features: torch.Tensor, taus: Optional[torch.Tensor] = None
                ) -> Tuple[torch.Tensor, torch.Tensor]:
        B = features.size(0)
        v_norm = self.get_normalized_value(features)
        mean_value = self.sigma * v_norm + self.mu

        if taus is None:
            taus = torch.rand(B, self.n_quantiles, device=features.device)
        q_norm = self.get_normalized_quantiles(features, taus)
        quantile_values = self.sigma * q_norm + self.mu
        return quantile_values, mean_value

    def get_normalized_value(self, features: torch.Tensor) -> torch.Tensor:
        return self.value_out(self.out(self.trunk(features))).squeeze(-1)

    def get_normalized_quantiles(self, features: torch.Tensor,
                                 taus: torch.Tensor) -> torch.Tensor:
        cos = torch.cos(taus.unsqueeze(-1) * self.pi_mult)
        tau_emb = self.tau_fc(cos)
        state_emb = self.state_fc(features).unsqueeze(1).expand(-1, taus.size(1), -1)
        return self.quantile_out(state_emb * tau_emb).squeeze(-1)

    # ---------------- PopArt ----------------
    @torch.no_grad()
    def update_statistics(self, returns: torch.Tensor):
        flat = returns.detach().reshape(-1)
        if flat.numel() == 0:
            return
        old_mu, old_sigma = self.mu.clone(), self.sigma.clone()

        batch_mu = flat.mean()
        batch_sigma = (flat.var(unbiased=False) + 1e-8).sqrt()

        self.count += 1
        beta = min(self.beta, 1.0 / max(10.0, float(self.count.item())))
        new_mu = (1.0 - beta) * self.mu + beta * batch_mu
        new_sigma = torch.clamp((1.0 - beta) * self.sigma + beta * batch_sigma,
                                min=0.1, max=50.0)

        # коэффициент приведения выходов головы к новой нормировке
        ratio = (old_sigma / new_sigma)
        self.value_out.weight.data.mul_(ratio)
        self.value_out.bias.data.copy_(
            (old_sigma * self.value_out.bias.data + old_mu - new_mu) / new_sigma)
        self.quantile_out.weight.data.mul_(ratio)
        self.quantile_out.bias.data.copy_(
            (old_sigma * self.quantile_out.bias.data + old_mu - new_mu) / new_sigma)

        self.mu.copy_(new_mu)
        self.sigma.copy_(new_sigma)

    def normalize_targets(self, returns: torch.Tensor) -> torch.Tensor:
        return (returns - self.mu) / self.sigma

    def get_stats(self) -> Dict[str, float]:
        return {"popart_mu": float(self.mu.item()),
                "popart_sigma": float(self.sigma.item())}


class AuxHeads(nn.Module):
    """Вспомогательные головы: выживание, деньги, убийства, кредиты башен."""

    def __init__(self, hidden_dim: int, max_towers: int = MAX_TOWERS):
        super().__init__()
        self.max_towers = max_towers
        self.survival = nn.Sequential(nn.Linear(hidden_dim, 64), nn.GELU(),
                                      nn.Linear(64, 1))                 # логит
        self.money = nn.Sequential(nn.Linear(hidden_dim, 64), nn.GELU(),
                                   nn.Linear(64, 1), nn.Sigmoid())
        self.kills = nn.Sequential(nn.Linear(hidden_dim, 64), nn.GELU(),
                                   nn.Linear(64, 1), nn.Sigmoid())
        self.credit = nn.Sequential(nn.Linear(hidden_dim, hidden_dim // 2), nn.GELU(),
                                    nn.Linear(hidden_dim // 2, max_towers), nn.Sigmoid())

    def forward(self, features: torch.Tensor):
        return (self.survival(features), self.money(features), self.kills(features))

    def predict_credits(self, features: torch.Tensor) -> torch.Tensor:
        return self.credit(features)


# ============================================================================
# ПОЛИТИКА
# ============================================================================
@dataclass
class PolicyConfig:
    hidden_dim: int = 256
    gnn_layers: int = 4
    gnn_type: str = "sage"
    transformer_layers: int = 4
    n_heads: int = 8
    n_quantiles: int = 16
    # ВАЖНО: dropout > 0 нарушает точное совпадение log-prob между сбором опыта
    # и пересчётом при обучении (шум в PPO-ratio). Поэтому по умолчанию 0.0.
    dropout: float = 0.0
    mem_len: int = 256
    node_features_dim: int = NODE_FEATURES_DIM
    global_features_dim: int = GLOBAL_FEATURES
    tower_features_dim: int = TOWER_PROPS_DIM
    max_deck_size: int = MAX_DECK_SIZE


class UniversalTDPolicy(nn.Module):
    """
    Универсальная политика TD.

    Действие = (type, slot, node) с авторегрессивной зависимостью:
        type -> slot (условно на type) -> node (условно на type и slot).
    Логиты всех голов маскируются валидными действиями; SELL маскируется
    -1e9 при enable_sell=False (правило №5).

    Один и тот же `_heads()` используется и при сборе опыта, и при обучении,
    поэтому log-prob в буфере и в пересчёте всегда совпадают (это была главная
    ошибка исходной версии).
    """

    def __init__(self, config: Optional[PolicyConfig] = None):
        super().__init__()
        self.cfg = config or PolicyConfig()
        c = self.cfg
        H = c.hidden_dim

        self.map_gnn = MapGNN(c.node_features_dim, H, H, num_layers=c.gnn_layers,
                              gnn_type=c.gnn_type, heads=4, dropout=c.dropout)
        self.path_gnn = PathAwareGNN(H, H, num_layers=2, dropout=c.dropout)
        self.path_to_node = nn.Linear(H, H)

        self.global_enc = nn.Sequential(nn.Linear(c.global_features_dim, H // 2),
                                        nn.LayerNorm(H // 2), nn.GELU())
        self.deck_attn = DeckAttention(c.tower_features_dim, H, n_heads=4,
                                       dropout=c.dropout)
        slot_dim = H // 4

        fusion_dim = H + H + H // 2 + H
        self.fusion = nn.Sequential(nn.Linear(fusion_dim, H), nn.LayerNorm(H), nn.GELU())

        self.transformer = GatedTransformerXL(
            d_model=H, n_heads=c.n_heads, n_layers=c.transformer_layers,
            d_ff=H * 4, dropout=c.dropout, mem_len=c.mem_len)

        # головы
        self.type_head = nn.Sequential(nn.Linear(H, H // 2), nn.GELU(),
                                       nn.Linear(H // 2, N_ACTION_TYPES))
        self.type_embed = nn.Linear(N_ACTION_TYPES, H // 4)
        self.slot_head = nn.Sequential(nn.Linear(H + H // 4, H // 2), nn.GELU(),
                                       nn.Linear(H // 2, c.max_deck_size))
        self.slot_embed = nn.Linear(c.max_deck_size, H // 4)
        self.node_query_gen = nn.Sequential(
            nn.Linear(H + H // 4 + slot_dim, H), nn.LayerNorm(H), nn.GELU())
        self.node_attn = SpatialNodeAttention(H, H // 4, slot_dim)

        self.value_head = PopArtIQNValueHead(H, H, c.n_quantiles)
        self.aux_heads = AuxHeads(H)

        # учим веса лоссов (Kendall et al.)
        self.loss_weights = nn.Parameter(torch.zeros(4))
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=math.sqrt(2))
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        last = self.type_head[-1]
        nn.init.xavier_uniform_(last.weight, gain=0.1)
        if last.bias is not None:
            last.bias.data[UPGRADE] = 0.2

    # ------------------------------------------------------------------ masks
    @staticmethod
    def _node_valid_mask(graphs: Dict[str, torch.Tensor], action_types: torch.Tensor,
                         slots: torch.Tensor) -> torch.Tensor:
        """
        Возвращает [N] bool: валиден ли узел для действия (type, slot) своего графа.

        Векторизовано: выбор нужной маски по типу действия делается gather-ом.
        """
        batch = graphs["batch"]                       # [N] -> индекс графа узла
        build_masks = graphs["build_masks"]           # [N, deck]
        deck = build_masks.size(1)
        slot_clamped = slots.clamp(0, max(0, deck - 1))
        # ВАЖНО: плоский индекс = (номер узла) * deck + номер слота.
        # Раньше здесь стоял batch * deck + slot — из-за этого все узлы
        # читали строку 0 (первый узел карты), и маска узлов была мусором.
        node_ids = torch.arange(build_masks.size(0), device=build_masks.device)
        flat_idx = node_ids * deck + slot_clamped[batch]
        build_sel = build_masks.reshape(-1)[flat_idx]

        upgrade = graphs["upgrade_mask"]               # [N]
        sell = graphs["sell_mask"]                     # [N]
        ones = torch.ones_like(upgrade)

        stacked = torch.stack([ones, build_sel, upgrade, sell], dim=0)   # [4, N]
        act = action_types.long().clamp(0, 3)
        return stacked.gather(0, (act[batch]).unsqueeze(0)).squeeze(0)

    @staticmethod
    def _type_mask(graphs: Dict[str, torch.Tensor], num_graphs: int) -> torch.Tensor:
        """[B, 4] bool: допустимость типов действий."""
        batch = graphs["batch"]
        build_masks = graphs["build_masks"]
        upgrade = graphs["upgrade_mask"]
        sell = graphs["sell_mask"]
        flags = graphs["action_flags"]                 # [B, 4] bool

        N = build_masks.size(0)
        ones = torch.ones(N, device=build_masks.device, dtype=torch.float32)
        build_any = torch.zeros(num_graphs, device=build_masks.device)
        build_any = build_any.index_add(0, batch, build_masks.any(dim=1).float())
        upgrade_any = torch.zeros(num_graphs, device=build_masks.device)
        upgrade_any = upgrade_any.index_add(0, batch, upgrade.float())
        sell_any = torch.zeros(num_graphs, device=build_masks.device)
        sell_any = sell_any.index_add(0, batch, sell.float())

        valid = torch.stack([ones.new_ones(num_graphs),                       # IDLE
                             (build_any > 0).float(),
                             (upgrade_any > 0).float(),
                             (sell_any > 0).float()], dim=1)
        valid = (valid > 0) & flags.bool()
        valid[:, IDLE] = True
        return valid

    @staticmethod
    def _slot_mask(graphs: Dict[str, torch.Tensor], num_graphs: int) -> torch.Tensor:
        """[B, deck] bool: в какой слот колоды вообще можно что-то построить."""
        batch = graphs["batch"]
        build_masks = graphs["build_masks"]            # [N, deck]
        deck = build_masks.size(1)
        acc = torch.zeros(num_graphs, deck, device=build_masks.device)
        acc = acc.index_add(0, batch, build_masks.float())
        return acc > 0.5

    # ------------------------------------------------------------------ encode
    def encode(self, graphs: Dict[str, torch.Tensor],
               deck_vec: torch.Tensor, deck_mask: torch.Tensor,
               memory: Optional[List[torch.Tensor]] = None,
               memory_mask: Optional[torch.Tensor] = None):
        """
        Один временной шаг для батча графов.

        Возвращает dict: context [B,H], node_emb [N,H], slot_emb [B,S,slot],
        deck_pooled [B,H], new_memory, new_memory_mask, graph_emb.
        """
        batch = graphs["batch"]
        num_graphs = deck_vec.size(0)

        graph_emb, node_emb = self.map_gnn(graphs["x"], graphs["edge_index"],
                                           batch, num_graphs)
        path_emb = self.path_gnn(node_emb, graphs["path_indices"],
                                 graphs["path_batch"], num_graphs)
        node_emb = node_emb + self.path_to_node(path_emb[batch])

        global_emb = self.global_enc(graphs["global_features"])
        slot_emb, deck_pooled = self.deck_attn(deck_vec, deck_mask)

        fused = self.fusion(torch.cat([graph_emb, path_emb, global_emb, deck_pooled],
                                     dim=-1)).unsqueeze(1)          # [B,1,H]
        temporal, new_memory, new_mask = self.transformer(fused, memory, memory_mask)
        context = temporal.squeeze(1)

        return {
            "context": context,
            "node_emb": node_emb,
            "slot_emb": slot_emb,
            "deck_pooled": deck_pooled,
            "graph_emb": graph_emb,
            "new_memory": new_memory,
            "new_memory_mask": new_mask,
        }

    # ------------------------------------------------------------------ heads
    # Головы считаются СТРОГО по стадиям (type -> slot -> node), без внутреннего
    # сэмплирования. Так log-prob при сборе опыта и при обучении совпадают
    # бит-в-бит: обе стороны вызывают одни и те же три функции с одними и теми
    # же аргументами.
    def _type_logits(self, enc: Dict[str, torch.Tensor],
                     graphs: Dict[str, torch.Tensor], num_graphs: int) -> torch.Tensor:
        type_logits = self.type_head(enc["context"])
        valid = self._type_mask(graphs, num_graphs)
        return type_logits.masked_fill(~valid, MASKED_LOGIT)

    def _type_context(self, action_type: torch.Tensor) -> torch.Tensor:
        return self.type_embed(
            F.one_hot(action_type.long(), num_classes=N_ACTION_TYPES).float())

    def _slot_logits(self, enc: Dict[str, torch.Tensor],
                     graphs: Dict[str, torch.Tensor], num_graphs: int,
                     action_type: torch.Tensor) -> torch.Tensor:
        type_ctx = self._type_context(action_type)
        slot_logits = self.slot_head(torch.cat([enc["context"], type_ctx], dim=-1))
        slot_valid = self._slot_mask(graphs, num_graphs)
        has_build = self._type_mask(graphs, num_graphs)[:, BUILD].unsqueeze(1)
        return slot_logits.masked_fill(~(slot_valid & has_build), MASKED_LOGIT)

    def _slot_condition(self, action_type: torch.Tensor,
                        slots: torch.Tensor, deck_slots: int) -> torch.Tensor:
        """Слот имеет смысл только для BUILD; иначе условие = слот 0."""
        cond = torch.where(action_type.long() == BUILD, slots.long(),
                           torch.zeros_like(slots.long()))
        return cond.clamp(0, max(0, deck_slots - 1))

    def _node_logits(self, enc: Dict[str, torch.Tensor],
                     graphs: Dict[str, torch.Tensor], num_graphs: int,
                     action_type: torch.Tensor, slot_cond: torch.Tensor) -> torch.Tensor:
        """Пространственное q*k внимание: запрос (context,type,слот) против узлов."""
        type_ctx = self._type_context(action_type)
        slot_dim = enc["slot_emb"].size(-1)
        slot_vec = enc["slot_emb"].gather(
            1, slot_cond.view(-1, 1, 1).expand(-1, 1, slot_dim)).squeeze(1)
        query = self.node_query_gen(torch.cat([enc["context"], type_ctx, slot_vec], dim=-1))
        node_logits = self.node_attn(query, enc["node_emb"], graphs["batch"],
                                     num_graphs, type_ctx, slot_vec)
        node_valid_flat = self._node_valid_mask(graphs, action_type, slot_cond)
        packed = self._pack_node_mask(node_valid_flat, graphs["batch"], num_graphs,
                                      node_logits.size(1))
        return node_logits.masked_fill(~packed, MASKED_LOGIT)

    @staticmethod
    def _pack_node_mask(valid_flat: torch.Tensor, batch: torch.Tensor,
                        num_graphs: int, max_nodes: int) -> torch.Tensor:
        """[N] bool -> [B, max_nodes] bool (векторизовано, без python-циклов)."""
        device = valid_flat.device
        out = torch.zeros(num_graphs, max_nodes, dtype=torch.bool, device=device)
        if valid_flat.numel() == 0 or max_nodes == 0:
            return out
        counts = torch.bincount(batch, minlength=num_graphs)
        order = torch.argsort(batch, stable=True)
        sorted_batch = batch[order]
        offsets = torch.cumsum(counts, dim=0) - counts
        pos = torch.arange(valid_flat.size(0), device=device) - offsets[sorted_batch]
        ok = valid_flat[order] & (pos < max_nodes)
        out[sorted_batch[ok], pos[ok]] = True
        return out

    @staticmethod
    def _head_logprobs(type_logits: torch.Tensor, slot_logits: torch.Tensor,
                       node_logits: torch.Tensor, action_types: torch.Tensor,
                       slots: torch.Tensor, nodes: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        ЕДИНАЯ формула log-prob для сбора и обучения.

        Слот входит в сумму только для BUILD, узел — для всех действий кроме IDLE.
        Целевые индексы всегда валидны, поэтому CE не даёт inf/nan.
        """
        action_types = action_types.long()
        lp_type = -F.cross_entropy(type_logits, action_types, reduction="none")

        is_build = action_types == BUILD
        slot_target = slots.long().clamp(0, max(0, slot_logits.size(1) - 1))
        lp_slot_all = -F.cross_entropy(slot_logits, slot_target, reduction="none")
        lp_slot = torch.where(is_build, lp_slot_all, torch.zeros_like(lp_slot_all))

        is_node = action_types != IDLE
        node_target = nodes.long().clamp(0, max(0, node_logits.size(1) - 1))
        lp_node_all = -F.cross_entropy(node_logits, node_target, reduction="none")
        lp_node = torch.where(is_node, lp_node_all, torch.zeros_like(lp_node_all))

        return {"total": lp_type + lp_slot + lp_node,
                "type": lp_type, "slot": lp_slot, "node": lp_node}

    # ------------------------------------------------------------------ act
    @torch.no_grad()
    def act_batch(self, graphs: Dict[str, torch.Tensor], deck_vec: torch.Tensor,
                  deck_mask: torch.Tensor, memories: Optional[List[List[torch.Tensor]]],
                  memory_masks: Optional[torch.Tensor] = None,
                  deterministic: bool = False):
        """Инференс для батча сред. memories — list примeрно из num_envs списков по слоям."""
        B = deck_vec.size(0)
        device = deck_vec.device

        mem_list, mem_mask = self._stack_memories(memories, B, device, memory_masks)
        enc = self.encode(graphs, deck_vec, deck_mask, mem_list, mem_mask)

        # 1) тип действия
        type_logits = self._type_logits(enc, graphs, B)
        dist_type = torch.distributions.Categorical(logits=type_logits)
        action_type = (type_logits.argmax(-1) if deterministic else dist_type.sample())

        # 2) слот колоды (только осмыслен для BUILD)
        slot_logits = self._slot_logits(enc, graphs, B, action_type)
        slot_raw = (slot_logits.argmax(-1) if deterministic
                    else torch.distributions.Categorical(logits=slot_logits).sample())
        slot = self._slot_condition(action_type, slot_raw, slot_logits.size(1))

        # 3) узел карты
        node_logits = self._node_logits(enc, graphs, B, action_type, slot)
        node = (node_logits.argmax(-1) if deterministic
                else torch.distributions.Categorical(logits=node_logits).sample())

        lp = self._head_logprobs(type_logits, slot_logits, node_logits,
                                 action_type, slot, node)
        ent_type, ent_slot, ent_node, entropy = self._entropies(
            type_logits, slot_logits, node_logits, action_type)

        taus = torch.rand(B, self.cfg.n_quantiles, device=device)
        quantile_values, values = self.value_head(enc["context"], taus)

        aux_s, aux_m, aux_k = self.aux_heads(enc["context"])
        credit = self.aux_heads.predict_credits(enc["context"])

        return {
            "action_type": action_type,
            "slot": slot,
            "node": node,
            "log_prob": lp["total"],
            "log_prob_type": lp["type"],
            "log_prob_slot": lp["slot"],
            "log_prob_node": lp["node"],
            "value": values,
            "quantile_values": quantile_values,
            "taus": taus,
            "entropy": entropy,
            "entropy_type": ent_type,
            "entropy_slot": ent_slot,
            "entropy_node": ent_node,
            "aux_survival": aux_s.squeeze(-1),
            "aux_money": aux_m.squeeze(-1),
            "aux_kills": aux_k.squeeze(-1),
            "credit_preds": credit,
            "new_memory": enc["new_memory"],
            "new_memory_mask": enc["new_memory_mask"],
        }

    @staticmethod
    def _entropies(type_logits: torch.Tensor, slot_logits: torch.Tensor,
                   node_logits: torch.Tensor, action_types: torch.Tensor):
        """Энтропии голов; неосмысленные головы обнуляются (без nan)."""
        ent_type = torch.distributions.Categorical(logits=type_logits).entropy()
        is_build = (action_types.long() == BUILD)
        is_node = (action_types.long() != IDLE)
        ent_slot = torch.distributions.Categorical(logits=slot_logits).entropy()
        ent_node = torch.distributions.Categorical(logits=node_logits).entropy()
        zero = torch.zeros_like(ent_slot)
        ent_slot = torch.where(is_build, ent_slot, zero)
        zero_n = torch.zeros_like(ent_node)
        ent_node = torch.where(is_node, ent_node, zero_n)
        total = ent_type + 0.5 * ent_slot + 0.5 * ent_node
        return ent_type, ent_slot, ent_node, total

    def _stack_memories(self, memories, B: int, device, memory_masks=None):
        """
        Собирает память из per-env списков в батч [B, L, D] с left-padding
        и маской валидности [B, L] (True = реальная позиция, False = паддинг).
        """
        n_layers = len(self.transformer.layers)
        if memories is None:
            return None, None

        per_layer: List[List[torch.Tensor]] = [[] for _ in range(n_layers)]
        for env in range(B):
            mem = memories[env] if env < len(memories) else None
            for l in range(n_layers):
                h = mem[l] if (mem is not None and l < len(mem)) else None
                if h is None or h.numel() == 0:
                    h = torch.zeros(0, self.cfg.hidden_dim, device=device)
                if h.dim() == 3:
                    h = h.squeeze(0)
                h = h.detach()
                if h.size(0) > self.transformer.mem_len:
                    h = h[-self.transformer.mem_len:]
                per_layer[l].append(h)

        max_len = max((h.size(0) for layer in per_layer for h in layer), default=0)
        if max_len == 0:
            return None, None

        batched: List[torch.Tensor] = []
        mask = torch.ones(B, max_len, dtype=torch.bool, device=device)
        for l in range(n_layers):
            padded = []
            for b, h in enumerate(per_layer[l]):
                n = h.size(0)
                if n < max_len:
                    pad = torch.zeros(max_len - n, h.size(1), device=device, dtype=h.dtype)
                    h = torch.cat([pad, h], dim=0)
                padded.append(h)
                if n == 0:
                    mask[b] = False
                else:
                    mask[b, :max_len - n] = False
            batched.append(torch.stack(padded, dim=0))
        return batched, mask

    # ------------------------------------------------------------------ train
    def evaluate_sequence(self, graphs_seq: List[Dict[str, torch.Tensor]],
                          deck_vec: torch.Tensor, deck_mask: torch.Tensor,
                          action_types: torch.Tensor, slots: torch.Tensor,
                          nodes: torch.Tensor, hidden_init: Optional[List[torch.Tensor]],
                          hidden_mask: Optional[torch.Tensor], dones: torch.Tensor,
                          lengths: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Пересчёт log-prob/value для последовательности из T шагов (B сегментов).

        Память подаётся на входе сегмента (hidden_init) и сбрасывается в нули
        на шагах с done — ровно как при сборе опыта.
        """
        B, T = action_types.shape
        device = deck_vec.device

        memory = hidden_init
        memory_mask = hidden_mask
        outs = {k: [] for k in ("log_prob", "log_prob_type", "log_prob_slot",
                                "log_prob_node", "value", "entropy", "quantile",
                                "taus", "aux_survival", "aux_money", "aux_kills",
                                "credit", "entropy_type", "entropy_slot",
                                "entropy_node")}

        for t in range(T):
            enc = self.encode(graphs_seq[t], deck_vec, deck_mask, memory, memory_mask)
            act_t = action_types[:, t].long()

            # те же три стадии, что и при сборе опыта (слот/узел обусловлены
            # уже выбранными действиями из буфера)
            type_logits = self._type_logits(enc, graphs_seq[t], B)
            slot_logits = self._slot_logits(enc, graphs_seq[t], B, act_t)
            slot_cond = self._slot_condition(act_t, slots[:, t], slot_logits.size(1))
            node_logits = self._node_logits(enc, graphs_seq[t], B, act_t, slot_cond)

            lp = self._head_logprobs(type_logits, slot_logits, node_logits,
                                     act_t, slots[:, t], nodes[:, t])
            ent_type, ent_slot, ent_node, entropy = self._entropies(
                type_logits, slot_logits, node_logits, act_t)

            taus = torch.rand(B, self.cfg.n_quantiles, device=device)
            qv, values = self.value_head(enc["context"], taus)

            aux_s, aux_m, aux_k = self.aux_heads(enc["context"])
            credit = self.aux_heads.predict_credits(enc["context"])
            outs["aux_survival"].append(aux_s.squeeze(-1))
            outs["aux_money"].append(aux_m.squeeze(-1))
            outs["aux_kills"].append(aux_k.squeeze(-1))
            outs["credit"].append(credit)
            outs["entropy_type"].append(ent_type)
            outs["entropy_slot"].append(ent_slot)
            outs["entropy_node"].append(ent_node)

            outs["log_prob"].append(lp["total"])
            outs["log_prob_type"].append(lp["type"])
            outs["log_prob_slot"].append(lp["slot"])
            outs["log_prob_node"].append(lp["node"])
            outs["value"].append(values)
            outs["entropy"].append(entropy)
            outs["quantile"].append(qv)
            outs["taus"].append(taus)

            memory = enc["new_memory"]
            memory_mask = enc["new_memory_mask"]
            # HIDDEN RESET на done: следующий шаг начинается с пустой памяти
            if t < T - 1:
                done = dones[:, t].view(B, 1, 1).float()
                memory = [m * (1.0 - done) for m in memory]
                memory_mask = memory_mask & (~dones[:, t]).unsqueeze(1)

        result = {
            "log_probs": torch.stack(outs["log_prob"], dim=1),
            "lp_type": torch.stack(outs["log_prob_type"], dim=1),
            "lp_slot": torch.stack(outs["log_prob_slot"], dim=1),
            "lp_node": torch.stack(outs["log_prob_node"], dim=1),
            "values": torch.stack(outs["value"], dim=1),
            "entropy": torch.stack(outs["entropy"], dim=1),
            "quantile_values": torch.stack(outs["quantile"], dim=1),
            "taus": torch.stack(outs["taus"], dim=1),
            "aux_survival": torch.stack(outs["aux_survival"], dim=1),
            "aux_money": torch.stack(outs["aux_money"], dim=1),
            "aux_kills": torch.stack(outs["aux_kills"], dim=1),
            "credit_preds": torch.stack(outs["credit"], dim=1),
            "entropy_type": torch.stack(outs["entropy_type"], dim=1),
            "entropy_slot": torch.stack(outs["entropy_slot"], dim=1),
            "entropy_node": torch.stack(outs["entropy_node"], dim=1),
        }
        valid = torch.zeros(B, T, dtype=torch.bool, device=device)
        for b in range(B):
            valid[b, :int(lengths[b].item())] = True
        result["valid_mask"] = valid
        return result

    # ------------------------------------------------------------------ aux
    def slice_memory(self, new_memories, new_memory_mask, idx: int,
                     device: Optional[torch.device] = None) -> List[torch.Tensor]:
        """Вырезает память одной среды из батча (по маске отбрасывает паддинг)."""
        device = device or next(self.parameters()).device
        if new_memories is None:
            return self.init_memory(1, device)
        out = []
        for layer in new_memories:
            if layer is None or layer.numel() == 0:
                out.append(torch.zeros(1, 0, self.cfg.hidden_dim, device=device))
                continue
            h = layer[idx: idx + 1].detach()
            if new_memory_mask is not None:
                mask = new_memory_mask[idx]
                if mask.numel() > 0:
                    h = h[:, mask, :]
            out.append(h.contiguous())
        return out

    def init_memory(self, batch_size: int, device: torch.device):
        return self.transformer.init_memory(batch_size, device)

    def compute_total_loss(self, l_pi, l_val, l_aux, l_quant):
        w = self.loss_weights
        loss = ((l_pi * torch.exp(-w[0]) + w[0]) +
                (l_val * torch.exp(-w[1]) + w[1]) * 0.5 +
                (l_aux * torch.exp(-w[2]) + w[2]) * 0.5 +
                (l_quant * torch.exp(-w[3]) + w[3]) * 0.5)
        return loss

