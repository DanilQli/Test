"""
ОБУЧЕНИЕ: буфер (GAE), PPO, векторные среды, метрики, тренер.

Собран склейкой файлов: buffer, ppo, vecenv, metrics, trainer
"""
from __future__ import annotations

from .data import (
    BUILD, IDLE, LOG_KILLS_CAP, LOG_MONEY_CAP, MAPS_TEST, MAPS_TRAIN,
    MAX_DECK_SIZE, MAX_TOWERS, SELL, TOWER_TYPES_DATA, UPGRADE,
)
from .sim import EnvConfig, TDEnv
from .agent import (
    MapToGraphConverter, PolicyConfig, TDGameAdapter, UniversalTDPolicy,
    build_graph_batch, build_sequence_batch,
)

# ============================================================================
# СЕКЦИЯ: buffer.py
# ============================================================================
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch



class BufferStateError(RuntimeError):
    """Нарушен порядок операций с буфером."""


def _fit_vector(vec, size: int) -> np.ndarray:
    """Приводит вектор любой длины к фиксированному размеру (обрезка/нули)."""
    out = np.zeros(size, dtype=np.float32)
    if vec is None:
        return out
    arr = np.asarray(vec, dtype=np.float32).reshape(-1)
    n = min(size, arr.size)
    if n > 0:
        out[:n] = arr[:n]
    return out


@dataclass
class Segment:
    """Один сегмент длиной T (последний может быть добит паддингом)."""
    env_idx: int = 0
    length: int = 0
    graphs: List[Dict[str, np.ndarray]] = field(default_factory=list)
    deck_vec: np.ndarray = None
    deck_mask: np.ndarray = None

    action_types: np.ndarray = None
    slots: np.ndarray = None
    nodes: np.ndarray = None

    rewards: np.ndarray = None
    values: np.ndarray = None
    log_probs: np.ndarray = None
    log_probs_type: np.ndarray = None
    log_probs_slot: np.ndarray = None
    log_probs_node: np.ndarray = None
    dones: np.ndarray = None

    aux_survival: np.ndarray = None
    aux_money: np.ndarray = None
    aux_kills: np.ndarray = None
    credit_targets: np.ndarray = None
    reward_components: np.ndarray = None

    hidden_init: Optional[List[torch.Tensor]] = None
    episode_ids: np.ndarray = None
    start_step: int = 0      # абсолютный номер первого шага сегмента в среде

    returns: np.ndarray = None
    advantages: np.ndarray = None


class SequencePPOBuffer:
    """Буфер сегментов с корректной GAE и строгим порядком финализации."""

    def __init__(self, segment_length: int = 64, gamma: float = 0.995,
                 lam: float = 0.97, max_credit_towers: int = MAX_TOWERS,
                 survival_lookahead: int = 20, obs_fp16: bool = False):
        self.obs_fp16 = bool(obs_fp16)
        self.segment_length = int(segment_length)
        self.gamma = float(gamma)
        self.lam = float(lam)
        self.max_credit_towers = int(max_credit_towers)
        self.survival_lookahead = int(survival_lookahead)

        self.segments: List[Segment] = []
        self._env: Dict[int, Dict] = {}
        self._pending_hidden: Dict[int, Optional[List[torch.Tensor]]] = {}
        self._episode_counter = 0
        self._state = "collecting"
        self._env_step_counter: Dict[int, int] = {}      # collecting -> reset_done -> gae_done -> finalized

    # ------------------------------------------------------------------ setup
    def init_env_buffer(self, env_idx: int, hidden_init: Optional[List[torch.Tensor]] = None):
        self._env[env_idx] = {
            "graphs": [],
            "deck_vec": None,
            "deck_mask": None,
            "action_types": [],
            "slots": [],
            "nodes": [],
            "rewards": [],
            "values": [],
            "log_probs": [],
            "log_probs_type": [],
            "log_probs_slot": [],
            "log_probs_node": [],
            "dones": [],
            "aux_survival": [],
            "aux_money": [],
            "aux_kills": [],
            "credit_targets": [],
            "reward_components": [],
            "episode_ids": [],
            "current_episode": self._episode_counter,
            "hidden_init": self._detach(hidden_init),
        }
        self._pending_hidden[env_idx] = self._detach(hidden_init)
        self._episode_counter += 1

    def _shrink(self, graph: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        """fp16 для признаков узлов: меньше память буфера, точность та же для GNN."""
        if not self.obs_fp16:
            return graph
        x = graph.get("x")
        if x is None or x.dtype == np.float16:
            return graph
        g = dict(graph)
        g["x"] = x.astype(np.float16)
        return g

    def _next_episode(self) -> int:
        self._episode_counter += 1
        return self._episode_counter

    @staticmethod
    def _detach(hidden: Optional[List[torch.Tensor]]):
        if hidden is None:
            return None
        return [h.detach().cpu().clone() if (h is not None and h.numel() > 0) else None
                for h in hidden]

    def set_pending_hidden(self, env_idx: int, hidden: Optional[List[torch.Tensor]]):
        """
        Память GTrXL на момент НАЧАЛА следующего сегмента этой среды.
        Вызывается сразу после того, как сегмент был закрыт.
        """
        self._pending_hidden[env_idx] = self._detach(hidden)

    # ------------------------------------------------------------------ store
    def store_step(self, env_idx: int, graph: Dict[str, np.ndarray],
                   action_type: int, slot: int, node: int, reward: float,
                   value: float, log_prob: float, done: bool,
                   log_prob_type: float = 0.0, log_prob_slot: float = 0.0,
                   log_prob_node: float = 0.0, aux_survival: float = 1.0,
                   aux_money: float = 0.0, aux_kills: float = 0.0,
                   credit_targets: Optional[np.ndarray] = None,
                   reward_components: Optional[np.ndarray] = None) -> bool:
        """Возвращает True, если сегмент был закрыт (нужно обновить pending hidden)."""
        if self._state != "collecting":
            raise BufferStateError(f"store_step после финализации (state={self._state})")
        if env_idx not in self._env:
            raise BufferStateError(f"env {env_idx} не инициализирован (init_env_buffer)")

        buf = self._env[env_idx]
        if buf["deck_vec"] is None:
            buf["deck_vec"] = graph["deck_vec"].copy()
            buf["deck_mask"] = graph["deck_mask"].copy()

        buf["graphs"].append(self._shrink(graph))
        buf["action_types"].append(int(action_type))
        buf["slots"].append(int(slot))
        buf["nodes"].append(int(node))
        buf["rewards"].append(float(reward))
        buf["values"].append(float(value))
        buf["log_probs"].append(float(log_prob))
        buf["log_probs_type"].append(float(log_prob_type))
        buf["log_probs_slot"].append(float(log_prob_slot))
        buf["log_probs_node"].append(float(log_prob_node))
        buf["dones"].append(bool(done))
        buf["aux_survival"].append(float(aux_survival))
        buf["aux_money"].append(float(aux_money))
        buf["aux_kills"].append(float(aux_kills))
        buf["episode_ids"].append(int(buf["current_episode"]))

        buf["credit_targets"].append(
            _fit_vector(credit_targets, self.max_credit_towers))
        buf["reward_components"].append(_fit_vector(reward_components, 6))

        if done:
            buf["current_episode"] = self._next_episode()

        if len(buf["graphs"]) >= self.segment_length:
            self._flush(env_idx, padded=False)
            return True
        return False

    def _flush(self, env_idx: int, padded: bool, last_value: float = 0.0):
        """Закрывает накопленные шаги среды в Segment (с паддингом при нужде)."""
        buf = self._env[env_idx]
        actual_len = len(buf["graphs"])
        if actual_len == 0:
            return
        T = self.segment_length

        graphs = list(buf["graphs"])
        rewards = list(buf["rewards"])
        values = list(buf["values"])
        log_probs = list(buf["log_probs"])
        log_probs_type = list(buf["log_probs_type"])
        log_probs_slot = list(buf["log_probs_slot"])
        log_probs_node = list(buf["log_probs_node"])
        dones = list(buf["dones"])
        action_types = list(buf["action_types"])
        slots = list(buf["slots"])
        nodes = list(buf["nodes"])
        aux_survival = list(buf["aux_survival"])
        aux_money = list(buf["aux_money"])
        aux_kills = list(buf["aux_kills"])
        credits = list(buf["credit_targets"])
        comps = list(buf["reward_components"])
        ep_ids = list(buf["episode_ids"])

        if padded and actual_len < T:
            pad = T - actual_len
            graphs.extend([graphs[-1]] * pad)
            rewards.extend([0.0] * pad)
            values.extend([last_value] * pad)
            log_probs.extend([0.0] * pad)
            log_probs_type.extend([0.0] * pad)
            log_probs_slot.extend([0.0] * pad)
            log_probs_node.extend([0.0] * pad)
            dones.extend([True] * pad)
            action_types.extend([0] * pad)
            slots.extend([0] * pad)
            nodes.extend([0] * pad)
            aux_survival.extend([1.0] * pad)
            aux_money.extend([0.0] * pad)
            aux_kills.extend([0.0] * pad)
            credits.extend([np.zeros(self.max_credit_towers, dtype=np.float32)] * pad)
            comps.extend([np.zeros(6, dtype=np.float32)] * pad)
            ep_ids.extend([-1] * pad)

        start_step = self._env_step_counter.get(env_idx, 0)
        self._env_step_counter[env_idx] = start_step + actual_len
        segment = Segment(
            env_idx=env_idx,
            length=actual_len,
            start_step=start_step,
            graphs=graphs,
            deck_vec=buf["deck_vec"],
            deck_mask=buf["deck_mask"],
            action_types=np.array(action_types, dtype=np.int64),
            slots=np.array(slots, dtype=np.int64),
            nodes=np.array(nodes, dtype=np.int64),
            rewards=np.array(rewards, dtype=np.float32),
            values=np.array(values, dtype=np.float32),
            log_probs=np.array(log_probs, dtype=np.float32),
            log_probs_type=np.array(log_probs_type, dtype=np.float32),
            log_probs_slot=np.array(log_probs_slot, dtype=np.float32),
            log_probs_node=np.array(log_probs_node, dtype=np.float32),
            dones=np.array(dones, dtype=bool),
            aux_survival=np.array(aux_survival, dtype=np.float32),
            aux_money=np.array(aux_money, dtype=np.float32),
            aux_kills=np.array(aux_kills, dtype=np.float32),
            credit_targets=np.stack(credits).astype(np.float32),
            reward_components=np.stack(comps).astype(np.float32),
            hidden_init=self._pending_hidden.get(env_idx),
            episode_ids=np.array(ep_ids, dtype=np.int64),
        )
        self.segments.append(segment)

        for key in ("graphs", "rewards", "values", "log_probs", "log_probs_type",
                    "log_probs_slot", "log_probs_node", "dones", "action_types",
                    "slots", "nodes", "aux_survival", "aux_money", "aux_kills",
                    "credit_targets", "reward_components", "episode_ids"):
            buf[key] = []

    # ------------------------------------------------------------------ finalize
    def _hidden_reset(self, last_values: Dict[int, float]):
        """ШАГ 1: закрыть хвосты и сбросить стартовую память новых сегментов."""
        if self._state != "collecting":
            raise BufferStateError(f"hidden reset в состоянии {self._state}")
        for env_idx in list(self._env.keys()):
            last_value = float(last_values.get(env_idx, 0.0))
            if len(self._env[env_idx]["graphs"]) > 0:
                self._flush(env_idx, padded=True, last_value=last_value)
            # новый сегмент начинается «с чистого листа» по памяти
            self._pending_hidden[env_idx] = None
        self._recompute_survival_targets()
        self._state = "reset_done"

    def _recompute_survival_targets(self):
        """
        Таргет головы выживания: 0 для окна lookahead перед смертью.
        Сырые значения (0 в шаге смерти) приходят из среды через aux_survival.
        """
        by_env: Dict[int, List[int]] = {}
        for i, seg in enumerate(self.segments):
            by_env.setdefault(seg.env_idx, []).append(i)

        for env_idx, idxs in by_env.items():
            flat_death = np.concatenate([self.segments[i].aux_survival[:self.segments[i].length]
                                         for i in idxs])
            targets = np.ones_like(flat_death)
            for death_idx in np.where(flat_death <= 0.0)[0]:
                start = max(0, int(death_idx) - self.survival_lookahead)
                targets[start:int(death_idx) + 1] = 0.0

            cursor = 0
            for i in idxs:
                seg = self.segments[i]
                seg.aux_survival[:seg.length] = targets[cursor:cursor + seg.length]
                seg.aux_survival[seg.length:] = 1.0
                cursor += seg.length

    def _compute_gae(self, last_values: Dict[int, float]):
        """ШАГ 2: generalized advantage estimation по сегментам каждой среды."""
        if self._state != "reset_done":
            raise BufferStateError(
                "GAE должен вызываться ПОСЛЕ hidden reset (порядок: "
                "hidden reset -> GAE -> finalize_all)")

        by_env: Dict[int, List[int]] = {}
        for i, seg in enumerate(self.segments):
            by_env.setdefault(seg.env_idx, []).append(i)

        for env_idx, idxs in by_env.items():
            for k, seg_i in enumerate(idxs):
                seg = self.segments[seg_i]
                # bootstrap со следующего сегмента (если есть)
                if k + 1 < len(idxs):
                    nxt = self.segments[idxs[k + 1]]
                    next_value_after_end = float(nxt.values[0])
                else:
                    next_value_after_end = float(last_values.get(env_idx, 0.0))

                adv = np.zeros(self.segment_length, dtype=np.float32)
                ret = np.zeros(self.segment_length, dtype=np.float32)
                gae = 0.0
                for t in reversed(range(seg.length)):
                    if t == seg.length - 1:
                        if seg.dones[t]:
                            nv, non_terminal = 0.0, 0.0
                        else:
                            nv, non_terminal = next_value_after_end, 1.0
                    else:
                        nv = float(seg.values[t + 1])
                        non_terminal = 0.0 if seg.dones[t] else 1.0

                    delta = seg.rewards[t] + self.gamma * nv * non_terminal - seg.values[t]
                    gae = delta + self.gamma * self.lam * non_terminal * gae
                    adv[t] = gae
                    ret[t] = gae + seg.values[t]

                seg.advantages = adv
                seg.returns = ret
                # паддинг: нулевые значения, чтобы не влияли на лоссы
                if seg.length < self.segment_length:
                    seg.advantages[seg.length:] = 0.0
                    seg.returns[seg.length:] = seg.values[seg.length:]

        self._state = "gae_done"

    def _finalize(self):
        """ШАГ 3: проверка целостности и фиксация буфера."""
        if self._state != "gae_done":
            raise BufferStateError(
                "finalize_all должен идти ПОСЛЕ GAE (порядок: "
                "hidden reset -> GAE -> finalize_all)")
        for seg in self.segments:
            assert seg.returns is not None and seg.advantages is not None
            assert len(seg.returns) == self.segment_length == len(seg.advantages)
            assert np.all(np.isfinite(seg.returns)), "NaN/inf в returns"
            assert np.all(np.isfinite(seg.advantages)), "NaN/inf в advantages"
            assert 0 < seg.length <= self.segment_length
        self._state = "finalized"

    def finalize_all(self, last_values: Dict[int, float]):
        """Единая точка входа: hidden reset -> GAE -> finalize."""
        self._hidden_reset(last_values)
        self._compute_gae(last_values)
        self._finalize()

    # ------------------------------------------------------------------ reading
    def get_all_segments(self) -> List[Segment]:
        if self._state != "finalized":
            raise BufferStateError(
                f"get_all_segments до finalize_all (state={self._state})")
        return self.segments

    def total_steps(self) -> int:
        return int(sum(seg.length for seg in self.segments))

    @property
    def state(self) -> str:
        return self._state

    def __len__(self) -> int:
        return len(self.segments)

    # ------------------------------------------------------------------ stats
    def episode_return_distribution(self) -> Dict[str, float]:
        """Возвраты по эпизодам (для логов)."""
        sums: Dict[Tuple[int, int], float] = {}
        for seg in self.segments:
            for t in range(seg.length):
                key = (seg.env_idx, int(seg.episode_ids[t]))
                sums[key] = sums.get(key, 0.0) + float(seg.rewards[t])
        vals = np.array(list(sums.values()), dtype=np.float32)
        if vals.size == 0:
            return {"ep_returns_mean": 0.0, "ep_returns_min": 0.0, "ep_returns_max": 0.0}
        return {"ep_returns_mean": float(vals.mean()),
                "ep_returns_min": float(vals.min()),
                "ep_returns_max": float(vals.max())}

# ============================================================================
# СЕКЦИЯ: ppo.py
# ============================================================================
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F



@dataclass
class PPOConfig:
    clip_eps: float = 0.2
    value_coef: float = 0.2
    aux_coef: float = 0.1
    quantile_coef: float = 1.0
    credit_coef: float = 0.05
    entropy_coef: float = 0.01          # legacy: общий коэффициент (не используется)
    # отдельные коэффициенты энтропии по головам: у node 100+ вариантов,
    # у type — 3, один общий коэффициент не может быть оптимален для обеих
    entropy_type: float = 0.005
    entropy_slot: float = 0.005
    entropy_node: float = 0.02
    max_grad_norm: float = 0.5
    train_iters: int = 2
    minibatch_segments: int = 8
    head_weights: Tuple[float, float, float] = (0.3, 0.4, 1.2)
    normalize_advantages: bool = True
    normalize_credit_mae: bool = True


def masked_mean(x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    m = mask.float()
    return (x * m).sum() / m.sum().clamp_min(1.0)


def normalize_advantages(segments: List[Segment]) -> None:
    """Нормализация advantages по ВАЛИДНЫМ шагам (паддинг не участвует)."""
    chunks = [seg.advantages[:seg.length] for seg in segments]
    if not chunks:
        return
    flat = np.concatenate(chunks)
    if flat.size < 2:
        return
    mean, std = float(flat.mean()), float(flat.std() + 1e-8)
    for seg in segments:
        seg.advantages = (seg.advantages - mean) / std
        seg.advantages[seg.length:] = 0.0


def _balance_order(segments: List[Segment]) -> List[int]:
    """Чередование лёгких/тяжёлых сегментов — ровная нагрузка на память GPU."""
    weights = []
    for seg in segments:
        sample = seg.graphs[:min(4, len(seg.graphs))]
        weights.append(float(np.mean([g["edge_index"].shape[1] for g in sample])))
    order = list(np.argsort(weights))
    light, heavy = order[: len(order) // 2], order[len(order) // 2:]
    np.random.shuffle(light)
    np.random.shuffle(heavy)
    out: List[int] = []
    li = hi = 0
    while len(out) < len(order):
        if li < len(light):
            out.append(light[li]); li += 1
        if hi < len(heavy):
            out.append(heavy[hi]); hi += 1
    return out


def sequence_ppo_update(policy, optimizer, segments: List[Segment],
                        segment_length: int, device: torch.device,
                        config: Optional[PPOConfig] = None,
                        scaler=None, log_fn=None,
                        progress_cb=None, entropy_scale: float = 1.0,
                        lr_scheduler=None, amp_dtype=None) -> Dict[str, float]:
    """Один проход обучения по всем сегментам эпохи. Возвращает статистику."""
    cfg = config or PPOConfig()
    log = log_fn or (lambda msg: None)

    if not segments:
        return {"error": "no_segments"}

    if cfg.normalize_advantages:
        normalize_advantages(segments)

    n = len(segments)
    max_iters = cfg.train_iters * int(np.ceil(n / max(1, cfg.minibatch_segments)))

    keys = ("loss_pi", "loss_v", "loss_aux", "loss_aux_survival", "loss_aux_money",
            "loss_aux_kills", "loss_credit", "loss_quantile", "entropy",
            "entropy_type", "entropy_slot", "entropy_node", "approx_kl",
            "clipfrac", "clipfrac_type", "clipfrac_slot", "clipfrac_node",
            "quantile_spread", "popart_mu", "popart_sigma", "survival_acc",
            "money_mae", "kills_mae")
    stats = {k: 0.0 for k in keys}
    updates = 0
    t0 = time.time()

    policy.train()
    for _it in range(cfg.train_iters):
        order = _balance_order(segments)
        for start in range(0, n, cfg.minibatch_segments):
            mb = [segments[i] for i in order[start:start + cfg.minibatch_segments]]
            if not mb:
                continue

            batch = build_sequence_batch(mb, segment_length, device,
                                        policy.cfg.hidden_dim)
            use_amp = (amp_dtype is not None) and device.type == "cuda"
            amp_ctx = (torch.autocast(device_type=device.type, dtype=amp_dtype,
                                      enabled=True) if use_amp
                       else torch.autocast(device_type="cpu", enabled=False))

            with amp_ctx:
                out = policy.evaluate_sequence(
                    graphs_seq=batch["graphs_seq"],
                    deck_vec=batch["deck_vec"], deck_mask=batch["deck_mask"],
                    action_types=batch["action_types"], slots=batch["slots"],
                    nodes=batch["nodes"], hidden_init=batch["hidden_init"],
                    hidden_mask=batch["hidden_mask"], dones=batch["dones"],
                    lengths=batch["lengths"])

                valid = out["valid_mask"]
                adv = batch["advantages"]
                returns = batch["returns"]

                # ---------------- policy (clipped, per-head) ----------------
                def head_loss(new_lp, old_lp, weight):
                    log_ratio = torch.clamp(new_lp - old_lp, -20.0, 20.0)
                    ratio = torch.exp(log_ratio).clamp(0.01, 100.0)
                    surr1 = ratio * adv
                    surr2 = torch.clamp(ratio, 1.0 - cfg.clip_eps,
                                        1.0 + cfg.clip_eps) * adv
                    loss = -torch.min(surr1, surr2)
                    clipped = ((ratio < 1.0 - cfg.clip_eps) |
                               (ratio > 1.0 + cfg.clip_eps)).float()
                    return loss * weight, clipped

                w_type, w_slot, w_node = cfg.head_weights
                l_type, cf_type = head_loss(out["lp_type"], batch["old_lp_type"], w_type)
                l_slot, cf_slot = head_loss(out["lp_slot"], batch["old_lp_slot"], w_slot)
                l_node, cf_node = head_loss(out["lp_node"], batch["old_lp_node"], w_node)

                loss_pi = masked_mean(l_type + l_slot + l_node, valid)

                with torch.no_grad():
                    log_ratio_total = torch.clamp(out["log_probs"] -
                                                  batch["old_log_probs"], -20.0, 20.0)
                    ratio_total = torch.exp(log_ratio_total)
                    approx_kl = masked_mean((ratio_total - 1.0) - log_ratio_total, valid)
                    clipfrac = masked_mean(
                        ((ratio_total < 1.0 - cfg.clip_eps) |
                         (ratio_total > 1.0 + cfg.clip_eps)).float(), valid)
                    clipfrac_type = masked_mean(cf_type, valid)
                    clipfrac_slot = masked_mean(cf_slot, valid)
                    clipfrac_node = masked_mean(cf_node, valid)

                # ---------------- value (PopArt) ----------------
                vh = policy.value_head
                mu, sigma = vh.mu.detach(), vh.sigma.detach()
                ret_norm = (returns - mu) / sigma
                pred_norm = (out["values"] - mu) / sigma
                v1 = F.huber_loss(pred_norm, ret_norm.detach(), reduction="none",
                                  delta=1.0)
                v_clip = torch.clamp(pred_norm, ret_norm - cfg.clip_eps,
                                     ret_norm + cfg.clip_eps)
                v2 = F.huber_loss(v_clip, ret_norm.detach(), reduction="none", delta=1.0)
                loss_v = masked_mean(torch.max(v1, v2), valid)

                # ---------------- IQN ----------------
                loss_quant = torch.zeros((), device=device)
                q_spread = torch.zeros((), device=device)
                qv = out["quantile_values"]
                taus = out["taus"]
                q_norm = (qv - mu) / sigma
                B, T, Nq = q_norm.shape
                q_flat = q_norm.reshape(-1, Nq)
                ret_flat = ret_norm.reshape(-1)
                tau_flat = taus.reshape(-1, Nq)
                mask_flat = valid.reshape(-1)
                if bool(mask_flat.any()):
                    target = ret_flat[mask_flat].detach().unsqueeze(1).expand_as(
                        q_flat[mask_flat])
                    td = target - q_flat[mask_flat]
                    kappa = 1.0
                    huber = torch.where(td.abs() <= kappa, 0.5 * td ** 2,
                                        kappa * (td.abs() - 0.5 * kappa))
                    q_w = torch.abs(tau_flat[mask_flat] - (td < 0).float())
                    loss_quant = (q_w * huber).mean()
                    q_spread = masked_mean(qv.max(-1)[0] - qv.min(-1)[0], valid)

                # ---------------- aux ----------------
                aux_s = out["aux_survival"]
                aux_m = out["aux_money"]
                aux_k = out["aux_kills"]

                loss_s = masked_mean(
                    F.binary_cross_entropy_with_logits(
                        aux_s, batch["aux_survival"], reduction="none"), valid)
                loss_m = masked_mean(
                    F.mse_loss(aux_m, batch["aux_money"], reduction="none"), valid)
                loss_k = masked_mean(
                    F.mse_loss(aux_k, batch["aux_kills"], reduction="none"), valid)
                loss_aux = 0.2 * loss_s + 0.4 * loss_m + 0.4 * loss_k

                with torch.no_grad():
                    surv_acc = masked_mean(
                        ((aux_s > 0.0) == (batch["aux_survival"] > 0.5)).float(), valid)
                    money_mae = masked_mean((aux_m - batch["aux_money"]).abs(), valid)
                    kills_mae = masked_mean((aux_k - batch["aux_kills"]).abs(), valid)

                # ---------------- credit ----------------
                credit_targets = batch["credit_targets"]
                has_signal = (credit_targets.sum(-1) > 0.01).float()
                credit_mask = valid.float() * has_signal
                if float(credit_mask.sum()) > 0:
                    credit_err = F.mse_loss(out["credit_preds"], credit_targets,
                                            reduction="none").mean(-1)
                    loss_credit = (credit_err * credit_mask).sum() / credit_mask.sum()
                else:
                    loss_credit = torch.zeros((), device=device)

                # ---------------- entropy ----------------
                entropy = masked_mean(out["entropy"], valid)
                entropy_type = masked_mean(out["entropy_type"], valid)
                entropy_slot = masked_mean(out["entropy_slot"], valid)
                entropy_node = masked_mean(out["entropy_node"], valid)

                ent_bonus = (cfg.entropy_type * entropy_type +
                             cfg.entropy_slot * entropy_slot +
                             cfg.entropy_node * entropy_node)
                total = (loss_pi +
                         cfg.value_coef * loss_v +
                         cfg.quantile_coef * loss_quant +
                         cfg.aux_coef * loss_aux +
                         cfg.credit_coef * loss_credit -
                         float(entropy_scale) * ent_bonus)

            if not torch.isfinite(total):
                continue

            optimizer.zero_grad(set_to_none=True)
            if use_amp:
                scaler.scale(total).backward()
                scaler.unscale_(optimizer)
                nn.utils.clip_grad_norm_(policy.parameters(), cfg.max_grad_norm)
                scaler.step(optimizer)
                scaler.update()
            else:
                total.backward()
                nn.utils.clip_grad_norm_(policy.parameters(), cfg.max_grad_norm)
                optimizer.step()

            with torch.no_grad():
                vr = returns[valid]
                if vr.numel() > 0:
                    vh.update_statistics(vr)

            if lr_scheduler is not None:
                try:
                    lr_scheduler()
                except Exception:
                    pass

            updates += 1
            vals = {
                "loss_pi": loss_pi, "loss_v": loss_v, "loss_aux": loss_aux,
                "loss_aux_survival": loss_s, "loss_aux_money": loss_m,
                "loss_aux_kills": loss_k, "loss_credit": loss_credit,
                "loss_quantile": loss_quant, "entropy": entropy,
                "entropy_type": entropy_type, "entropy_slot": entropy_slot,
                "entropy_node": entropy_node, "approx_kl": approx_kl,
                "clipfrac": clipfrac, "clipfrac_type": clipfrac_type,
                "clipfrac_slot": clipfrac_slot, "clipfrac_node": clipfrac_node,
                "quantile_spread": q_spread, "popart_mu": float(vh.mu),
                "popart_sigma": float(vh.sigma), "survival_acc": surv_acc,
                "money_mae": money_mae, "kills_mae": kills_mae,
            }
            for k, v in vals.items():
                stats[k] += float(v.detach()) if torch.is_tensor(v) else float(v)

            vals_f = {k: (float(v.detach()) if torch.is_tensor(v) else float(v))
                      for k, v in vals.items()}
            if progress_cb is not None:
                progress_cb(updates, max_iters, vals_f, time.time() - t0)
            if updates % 5 == 0 or updates == max_iters:
                log(f"[PPO] {updates}/{max_iters} | L_pi {vals_f['loss_pi']:.4f} | "
                    f"L_v {vals_f['loss_v']:.4f} | "
                    f"L_q {vals_f['loss_quantile']:.4f} | "
                    f"Ent {vals_f['entropy']:.3f} | "
                    f"KL {vals_f['approx_kl']:.4f} | {time.time() - t0:.0f}s")

    k = max(1, updates)
    for key in stats:
        stats[key] /= k
    stats["n_updates"] = float(updates)
    stats["n_segments"] = float(n)
    stats["time"] = time.time() - t0
    return stats

# ============================================================================
# СЕКЦИЯ: vecenv.py
# ============================================================================
import multiprocessing as mp
import traceback
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np



# ============================================================================
# Обёртка: среда + адаптер + конвертер -> граф
# ============================================================================
class GraphEnv:
    """TDEnv -> (граф, reward, done, info)."""

    def __init__(self, env: TDEnv, converter: Optional[MapToGraphConverter] = None,
                 macro_idle: bool = False, macro_idle_max: int = 60):
        self.env = env
        self.adapter = TDGameAdapter(env)
        self.converter = converter or MapToGraphConverter()
        self.macro_idle = bool(macro_idle)
        self.macro_idle_max = max(1, int(macro_idle_max))

    # ---------------- core ----------------
    def _graph(self) -> Dict[str, np.ndarray]:
        return self.converter.convert(self.adapter)

    def reset(self) -> Dict[str, np.ndarray]:
        self.adapter.invalidate()
        self.env.reset()
        return self._graph()

    def step(self, action_type: int, slot: int, node: int):
        reward, done, info = self.env.step(action_type, slot, node)

        # --- макро-IDLE ------------------------------------------------
        # Если агент выбрал «ничего не делать» и других легальных действий нет,
        # крутим тики внутри среды, не вызывая сеть. Один шаг буфера = пачка
        # бесполезных тиков (меньше шума в кредит-ассигнменте, меньше шагов).
        if self.macro_idle and not done and int(action_type) == IDLE:
            for _ in range(self.macro_idle_max):
                tm = np.asarray(self.env.type_mask())
                if tm.dtype == np.bool_:
                    # type_mask возвращает bool: True = действие доступно
                    busy = any(bool(tm[j]) for j in range(len(tm)) if j != IDLE)
                else:                        # на случай логитов (-1e9 = запрет)
                    busy = any(float(tm[j]) > -1e8
                               for j in range(len(tm)) if j != IDLE)
                if busy:
                    break
                r2, d2, info2 = self.env.step(IDLE, 0, 0)
                reward += r2
                info = info2
                if d2:
                    done = True
                    break

        graph = self._graph()
        if done:
            # сохраняем info завершённого эпизода, затем ресетим
            final_info = dict(info)
            final_info["episode_result"] = info.get("result", "")
            self.env.reset()
            graph = self._graph()
            return graph, reward, True, final_info
        return graph, reward, False, info

    # ---------------- forwarded ----------------
    @property
    def deck(self) -> List[int]:
        return list(self.env.deck)

    def set_deck(self, deck: Sequence[int]):
        self.env.set_deck(list(deck))
        self.adapter.invalidate()

    def set_map(self, map_matrix: np.ndarray):
        self.env.set_map(map_matrix)
        self.adapter.invalidate()

    def set_max_waves(self, max_waves: int):
        self.env.set_max_waves(int(max_waves))

    def set_difficulty(self, difficulty: float, starting_money: Optional[float] = None):
        self.env.set_difficulty(difficulty, starting_money)


# ============================================================================
# DummyVecEnv (один процесс; для тестов и отладки)
# ============================================================================
class DummyVecEnv:
    def __init__(self, env_fns: List[Callable[[], GraphEnv]]):
        self.envs = [fn() for fn in env_fns]
        self.n_envs = len(self.envs)

    def reset(self):
        graphs = [e.reset() for e in self.envs]
        return graphs

    def step(self, action_types, slots, nodes):
        graphs, rewards, dones, infos = [], [], [], []
        for i, e in enumerate(self.envs):
            g, r, d, info = e.step(int(action_types[i]), int(slots[i]), int(nodes[i]))
            graphs.append(g)
            rewards.append(r)
            dones.append(d)
            infos.append(info)
        return (graphs, np.array(rewards, dtype=np.float32),
                np.array(dones, dtype=bool), infos)

    def reset_one(self, env_idx: int):
        return self.envs[env_idx].reset()

    def set_deck(self, env_idx: int, deck):
        self.envs[env_idx].set_deck(deck)

    def set_map(self, env_idx: int, map_matrix):
        self.envs[env_idx].set_map(map_matrix)

    def set_max_waves_all(self, max_waves: int):
        for e in self.envs:
            e.set_max_waves(int(max_waves))

    def set_difficulty_all(self, difficulty: float, starting_money: float):
        for e in self.envs:
            e.set_difficulty(difficulty, starting_money)

    def close(self):
        self.envs = []


# ============================================================================
# SubprocVecEnv
# ============================================================================
def _worker(remote, parent_remote, env_fn):
    parent_remote.close()
    env: Optional[GraphEnv] = None
    try:
        env = env_fn()
        while True:
            cmd, data = remote.recv()
            if cmd == "step":
                at, sl, nd = data
                graph, reward, done, info = env.step(at, sl, nd)
                remote.send((graph, reward, done, info))
            elif cmd == "reset":
                remote.send(env.reset())
            elif cmd == "set_deck":
                env.set_deck(data)
                remote.send(True)
            elif cmd == "set_map":
                env.set_map(data)
                remote.send(True)
            elif cmd == "set_max_waves":
                env.set_max_waves(int(data))
                remote.send(True)
            elif cmd == "set_difficulty":
                env.set_difficulty(data["difficulty"], data["start_money"])
                remote.send(True)
            elif cmd == "close":
                remote.close()
                break
            else:
                raise ValueError(f"unknown cmd {cmd}")
    except EOFError:
        pass
    except Exception:
        print("[worker] failed:", traceback.format_exc(), flush=True)
        try:
            remote.close()
        except Exception:
            pass


class SubprocVecEnv:
    """Параллельные среды в отдельных процессах (spawn)."""

    def __init__(self, env_fns: List[Callable[[], GraphEnv]], start_method: str = "spawn"):
        self.n_envs = len(env_fns)
        ctx = mp.get_context(start_method)
        self.remotes, self.work_remotes = zip(*[ctx.Pipe() for _ in range(self.n_envs)])
        self.processes = []
        for work_remote, remote, env_fn in zip(self.work_remotes, self.remotes, env_fns):
            p = ctx.Process(target=_worker, args=(work_remote, remote, env_fn), daemon=True)
            p.start()
            self.processes.append(p)
            work_remote.close()
        self._closed = False

    # ---------------- api ----------------
    def reset(self) -> List[Dict[str, np.ndarray]]:
        for r in self.remotes:
            r.send(("reset", None))
        return [r.recv() for r in self.remotes]

    def step(self, action_types, slots, nodes):
        for i, r in enumerate(self.remotes):
            r.send(("step", (int(action_types[i]), int(slots[i]), int(nodes[i]))))
        results = [r.recv() for r in self.remotes]
        graphs = [res[0] for res in results]
        rewards = np.array([res[1] for res in results], dtype=np.float32)
        dones = np.array([res[2] for res in results], dtype=bool)
        infos = [res[3] for res in results]
        return graphs, rewards, dones, infos

    def reset_one(self, env_idx: int):
        r = self.remotes[env_idx]
        r.send(("reset", None))
        return r.recv()

    def set_deck(self, env_idx: int, deck):
        r = self.remotes[env_idx]
        r.send(("set_deck", list(deck)))
        r.recv()

    def set_map(self, env_idx: int, map_matrix: np.ndarray):
        r = self.remotes[env_idx]
        r.send(("set_map", np.array(map_matrix)))
        r.recv()

    def set_max_waves_all(self, max_waves: int):
        for r in self.remotes:
            r.send(("set_max_waves", int(max_waves)))
        for r in self.remotes:
            r.recv()

    def set_difficulty_all(self, difficulty: float, starting_money: float):
        for r in self.remotes:
            r.send(("set_difficulty", {"difficulty": difficulty,
                                       "start_money": starting_money}))
        for r in self.remotes:
            r.recv()

    def close(self):
        if self._closed:
            return
        for r in self.remotes:
            try:
                r.send(("close", None))
            except Exception:
                pass
        for p in self.processes:
            p.join(timeout=5)
            if p.is_alive():
                p.terminate()
        self._closed = True


# ============================================================================
# Фабрики
# ============================================================================
class EnvFactory:
    """
    Picklable-фабрика среды.

    Важно: обычный замыкание-`_make` нельзя передать в spawn-процесс
    (pickle не умеет локальные объекты), поэтому фабрика — класс верхнего уровня.
    """

    def __init__(self, map_matrix: np.ndarray, deck: Sequence[int],
                 config: Optional[EnvConfig] = None, difficulty: float = 1.0,
                 seed: Optional[int] = None, macro_idle: bool = False,
                 macro_idle_max: int = 60):
        self.map_matrix = np.array(map_matrix, dtype=np.int32)
        self.deck = list(deck)
        self.config = config if config is not None else EnvConfig()
        self.difficulty = float(difficulty)
        self.seed = seed
        self.macro_idle = bool(macro_idle)
        self.macro_idle_max = int(macro_idle_max)

    def __call__(self) -> "GraphEnv":
        env = TDEnv(np.array(self.map_matrix, copy=True), self.config,
                    deck=list(self.deck), difficulty=self.difficulty, seed=self.seed)
        return GraphEnv(env, MapToGraphConverter(), macro_idle=self.macro_idle,
                        macro_idle_max=self.macro_idle_max)


def make_env_fn(map_matrix: np.ndarray, deck: Sequence[int],
                config: Optional[EnvConfig] = None, difficulty: float = 1.0,
                seed: Optional[int] = None, macro_idle: bool = False,
                macro_idle_max: int = 60) -> EnvFactory:
    """Возвращает picklable-фабрику среды (годится для SubprocVecEnv)."""
    return EnvFactory(map_matrix, deck, config, difficulty, seed,
                      macro_idle=macro_idle, macro_idle_max=macro_idle_max)

def evaluate_greedy(policy, maps: Dict[str, np.ndarray],
                    decks: Sequence[Sequence[int]], device,
                    games_per_map: int = 1, max_waves: int = 80,
                    seed: int = 777, enable_sell: bool = False,
                    max_steps: int = 4000) -> Dict[str, object]:
    """
    Жадная (argmax) оценка политики на ФИКСИРОВАННЫХ картах и сидах.

    Нужна, чтобы видеть обобщение: MAPS_TEST в обучении не участвуют.
    Сэмплирование отключено (deterministic=True), сиды фиксированы —
    метрика сравнима между эпохами.
    """
    if not maps or not decks:
        return {}
    import random as _random
    per_map: Dict[str, List[int]] = {}
    all_waves: List[int] = []
    policy.eval()
    with torch.no_grad():
        for mi, (name, mat) in enumerate(maps.items()):
            for gi in range(max(1, int(games_per_map))):
                env_seed = int(seed) + mi * 1000 + gi
                deck = list(decks[env_seed % len(decks)])
                cfg = EnvConfig(deck_size=len(deck), max_waves=int(max_waves),
                                enable_sell=bool(enable_sell))
                env = TDEnv(np.array(mat, copy=True), cfg, deck=deck,
                            seed=env_seed)
                genv = GraphEnv(env, macro_idle=True)
                graph = genv.reset()
                mem = [policy.init_memory(1, device)]
                done = False
                steps = 0
                info: Dict = {}
                while not done and steps < max_steps:
                    batch = build_graph_batch([graph], device)
                    out = policy.act_batch(batch, batch["deck_vec"],
                                           batch["deck_mask"], mem,
                                           deterministic=True)
                    graph, _r, done, info = genv.step(
                        int(out["action_type"][0]), int(out["slot"][0]),
                        int(out["node"][0]))
                    mem = [policy.slice_memory(out["new_memory"],
                                               out["new_memory_mask"], 0, device)]
                    steps += 1
                waves = int(info.get("wave", 0))
                per_map.setdefault(name, []).append(waves)
                all_waves.append(waves)
    if not all_waves:
        return {}
    return {
        "waves": float(np.mean(all_waves)),
        "waves_max": float(np.max(all_waves)),
        "games": float(len(all_waves)),
        "per_map": {k: float(np.mean(v)) for k, v in per_map.items()},
    }


# ============================================================================
# СЕКЦИЯ: metrics.py
# ============================================================================
import os
from typing import Dict, List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def _safe(history: Dict[str, List[float]], key: str, n: int,
          default: float = 0.0) -> List[float]:
    data = list(history.get(key, []))
    if len(data) < n:
        data = data + [default] * (n - len(data))
    return data[:n]


def _to_float(values: List) -> List[float]:
    out = []
    for v in values:
        try:
            out.append(float(v))
        except (TypeError, ValueError):
            out.append(0.0)
    return out


def plot_progress(history: Dict, epoch: int, out_dir: str = "plots") -> Optional[str]:
    """Рисует дашборд 4x4. Возвращает путь к файлу (или None, если нет данных)."""
    n = len(history.get("waves", []))
    if n == 0:
        return None
    os.makedirs(out_dir, exist_ok=True)

    fig, axes = plt.subplots(4, 4, figsize=(34, 24))
    x = np.arange(1, n + 1)

    # ---------------- 1. Waves + Reward ----------------
    ax = axes[0, 0]
    ax.plot(x, _safe(history, "waves", n), color="blue", lw=2, label="Avg Waves")
    ax.set_xlabel("Epoch"); ax.set_ylabel("Waves", color="blue", fontweight="bold")
    ax.tick_params(axis="y", labelcolor="blue")
    ax2 = ax.twinx()
    ax2.plot(x, _safe(history, "rewards", n), color="green", lw=1.6, alpha=0.8,
             label="Avg Reward")
    ax2.set_ylabel("Reward", color="green", fontweight="bold")
    ax2.tick_params(axis="y", labelcolor="green")
    ax.set_title("Survival & Reward", fontweight="bold")
    ax.grid(alpha=0.2)
    best = np.maximum.accumulate(_safe(history, "waves", n))
    ax.plot(x, best, color="navy", ls="--", lw=1, alpha=0.6, label="best")
    test = _safe(history, "test_waves", n, 0.0)
    if np.any(test):
        ax.plot(x, test, color="magenta", ls="-.", lw=1.8,
                label="TEST (greedy)")
    ax.legend(fontsize=8, loc="lower right")

    # ---------------- 2. Damage + Kills ----------------
    ax = axes[0, 1]
    ax.plot(x, _safe(history, "avg_damage", n), color="crimson", lw=2)
    ax.set_xlabel("Epoch"); ax.set_ylabel("Avg Damage", color="crimson", fontweight="bold")
    ax.tick_params(axis="y", labelcolor="crimson")
    ax2 = ax.twinx()
    ax2.plot(x, _safe(history, "avg_kills", n), color="darkgreen", lw=1.6)
    ax2.set_ylabel("Avg Kills", color="darkgreen", fontweight="bold")
    ax2.tick_params(axis="y", labelcolor="darkgreen")
    ax.set_title("Combat: Damage & Kills", fontweight="bold"); ax.grid(alpha=0.2)

    # ---------------- 3. Towers + Level ----------------
    ax = axes[0, 2]
    ax.plot(x, _safe(history, "towers", n), color="darkorange", lw=2)
    ax.set_xlabel("Epoch"); ax.set_ylabel("Towers", color="darkorange", fontweight="bold")
    ax.tick_params(axis="y", labelcolor="darkorange")
    ax2 = ax.twinx()
    ax2.plot(x, _safe(history, "avg_tower_level", n), color="purple", lw=1.6)
    ax2.set_ylabel("Avg Level", color="purple", fontweight="bold")
    ax2.tick_params(axis="y", labelcolor="purple")
    ax.set_title("Construction", fontweight="bold"); ax.grid(alpha=0.2)

    # ---------------- 4. PopArt ----------------
    ax = axes[0, 3]
    mu = _safe(history, "popart_mu", n)
    sigma = _safe(history, "popart_sigma", n)
    ax.plot(x, mu, color="navy", lw=2)
    ax.set_xlabel("Epoch"); ax.set_ylabel("mu", color="navy", fontweight="bold")
    ax.tick_params(axis="y", labelcolor="navy")
    ax2 = ax.twinx()
    ax2.plot(x, sigma, color="darkcyan", lw=1.6)
    ax2.set_ylabel("sigma", color="darkcyan", fontweight="bold")
    ax2.tick_params(axis="y", labelcolor="darkcyan")
    ax.set_title("PopArt: value scale", fontweight="bold"); ax.grid(alpha=0.2)

    # ---------------- 5. Losses pi/v ----------------
    ax = axes[1, 0]
    ax.plot(x, _safe(history, "loss_pi", n), color="red", lw=2)
    ax.set_xlabel("Epoch"); ax.set_ylabel("Policy loss", color="red", fontweight="bold")
    ax.tick_params(axis="y", labelcolor="red")
    ax2 = ax.twinx()
    ax2.plot(x, _safe(history, "loss_v", n), color="orange", lw=1.6)
    ax2.set_ylabel("Value loss", color="orange", fontweight="bold")
    ax2.set_yscale("symlog")
    ax2.tick_params(axis="y", labelcolor="orange")
    ax.set_title("Policy & Value loss", fontweight="bold"); ax.grid(alpha=0.2)

    # ---------------- 6. Credit loss + LR ----------------
    ax = axes[1, 1]
    ax.plot(x, _safe(history, "loss_credit", n), color="dodgerblue", lw=2)
    ax.set_xlabel("Epoch"); ax.set_ylabel("Credit loss", color="dodgerblue",
                                          fontweight="bold")
    ax.tick_params(axis="y", labelcolor="dodgerblue")
    ax2 = ax.twinx()
    lr = _safe(history, "current_lr", n, 1e-4)
    ax2.plot(x, lr, color="black", lw=1.4, ls=":")
    ax2.set_ylabel("LR", color="black", fontweight="bold"); ax2.set_yscale("log")
    ax.set_title("Credit loss & LR", fontweight="bold"); ax.grid(alpha=0.2)

    # ---------------- 7. Quantiles ----------------
    ax = axes[1, 2]
    ax.plot(x, _safe(history, "loss_quantile", n), color="magenta", lw=2)
    ax.set_xlabel("Epoch"); ax.set_ylabel("Quantile loss", color="magenta",
                                          fontweight="bold")
    ax.tick_params(axis="y", labelcolor="magenta")
    ax2 = ax.twinx()
    ax2.plot(x, _safe(history, "quantile_spread", n), color="darkviolet", lw=1.5,
             ls="--")
    ax2.set_ylabel("IQN spread", color="darkviolet", fontweight="bold")
    ax2.tick_params(axis="y", labelcolor="darkviolet")
    ax.set_title("IQN", fontweight="bold"); ax.grid(alpha=0.2)

    # ---------------- 8. Aux quality ----------------
    ax = axes[1, 3]
    raw_acc = _safe(history, "survival_acc", n, 0.0)
    # значения в истории — доли [0,1]; на графике проценты
    acc = [v * 100.0 if v <= 1.0 else v for v in raw_acc]
    ax.plot(x, acc, color="teal", lw=2, label="survival acc, %")
    ax.set_xlabel("Epoch"); ax.set_ylabel("Survival acc, %", color="teal",
                                         fontweight="bold")
    ax.tick_params(axis="y", labelcolor="teal")
    lo = min(acc) if acc else 0.0
    ax.set_ylim(max(0.0, lo - 5.0), 100.0)
    ax2 = ax.twinx()
    ax2.plot(x, _safe(history, "money_mae", n), color="goldenrod", lw=1.5,
             ls="--", label="money MAE")
    ax2.plot(x, _safe(history, "kills_mae", n), color="purple", lw=1.5,
             ls=":", label="kills MAE")
    ax2.set_ylabel("MAE", color="goldenrod", fontweight="bold")
    ax2.tick_params(axis="y", labelcolor="goldenrod")
    ax2.set_ylim(bottom=0.0)
    ax.set_title("Aux heads quality", fontweight="bold"); ax.grid(alpha=0.2)
    ax.legend(fontsize=7, loc="lower left")
    ax2.legend(fontsize=7, loc="lower right")

    # ---------------- 9. Entropy + ratio ----------------
    ax = axes[2, 0]
    ax.plot(x, _safe(history, "entropy", n), color="brown", lw=2)
    ax.set_xlabel("Epoch"); ax.set_ylabel("Entropy", color="brown", fontweight="bold")
    ax.tick_params(axis="y", labelcolor="brown")
    ax2 = ax.twinx()
    ax2.plot(x, _safe(history, "entropy_ratio", n), color="darkred", lw=1.5, ls="--")
    ax2.axhline(0.3, color="green", ls=":", alpha=0.5)
    ax2.axhline(1.0, color="red", ls=":", alpha=0.5)
    ax2.set_ylabel("Entropy/|L_pi|", color="darkred", fontweight="bold")
    ax2.tick_params(axis="y", labelcolor="darkred")
    ax.set_title("Entropy balance", fontweight="bold"); ax.grid(alpha=0.2)

    # ---------------- 10. Per-head entropy ----------------
    ax = axes[2, 1]
    for key, color, label in (("entropy_type", "red", "type"),
                              ("entropy_slot", "blue", "slot"),
                              ("entropy_node", "green", "node")):
        ax.plot(x, _safe(history, key, n), color=color, lw=1.8, label=label)
    ax.axhline(np.log(3), color="red", ls=":", alpha=0.35)
    ax.axhline(np.log(8), color="blue", ls=":", alpha=0.35)
    ax.set_xlabel("Epoch"); ax.set_ylabel("Entropy (raw)")
    ax.set_title("Entropy per head", fontweight="bold")
    ax.legend(fontsize=8); ax.grid(alpha=0.2)

    # ---------------- 11. Action mix ----------------
    ax = axes[2, 2]
    build = np.array(_safe(history, "build_pct", n))
    upgrade = np.array(_safe(history, "upgrade_pct", n))
    idle = np.array(_safe(history, "idle_pct", n))
    sell = np.array(_safe(history, "sell_pct", n))
    ax.stackplot(x, build, upgrade, sell, idle,
                 labels=["build", "upgrade", "sell", "idle"],
                 colors=["#2ecc71", "#9b59b6", "#e67e22", "#95a5a6"], alpha=0.85)
    ax.set_xlabel("Epoch"); ax.set_ylabel("Actions / episode")
    ax.set_title("Action mix", fontweight="bold")
    ax.legend(fontsize=8, loc="upper right"); ax.grid(alpha=0.2)

    # ---------------- 12. Action quality ----------------
    ax = axes[2, 3]
    ax.plot(x, [v * 100 for v in _safe(history, "upgrade_ratio", n)],
            color="purple", lw=2)
    ax.set_xlabel("Epoch"); ax.set_ylabel("Upgrade ratio, %", color="purple",
                                         fontweight="bold")
    ax.tick_params(axis="y", labelcolor="purple")
    ax2 = ax.twinx()
    total = np.maximum(1e-6, build + upgrade + sell + idle)
    ax2.plot(x, (build + upgrade + sell) / total * 100, color="seagreen", lw=1.5,
             ls="--")
    ax2.set_ylabel("Productive, %", color="seagreen", fontweight="bold")
    ax2.tick_params(axis="y", labelcolor="seagreen")
    ax.set_title("Action quality", fontweight="bold"); ax.grid(alpha=0.2)

    # ---------------- 13. Time & stability ----------------
    ax = axes[3, 0]
    ax.bar(x, np.array(_safe(history, "time", n)) / 60.0, color="gray", alpha=0.35)
    ax.set_xlabel("Epoch"); ax.set_ylabel("Epoch time, min", color="gray",
                                         fontweight="bold")
    ax.tick_params(axis="y", labelcolor="gray")
    ax2 = ax.twinx()
    waves = np.array(_safe(history, "waves", n))
    if n > 3:
        std = [float(np.std(waves[max(0, i - 10):i + 1])) for i in range(n)]
        ax2.plot(x, std, color="red", lw=1.6)
    ax2.set_ylabel("Waves std (win 10)", color="red", fontweight="bold")
    ax2.tick_params(axis="y", labelcolor="red")
    ax.set_title("Diagnostics", fontweight="bold"); ax.grid(alpha=0.2)

    # ---------------- 14/15. Pairs ----------------
    pair_history = history.get("pair_history", [])
    if len(pair_history) >= 2:
        names = sorted({k for ep in pair_history for k in ep})
        series = {nm: [ep.get(nm, np.nan) for ep in pair_history] for nm in names}
        means = {nm: np.nanmean(v) for nm, v in series.items() if np.any(~np.isnan(v))}
        ordered = sorted(means.items(), key=lambda kv: kv[1], reverse=True)
        top = [k for k, _ in ordered[:5]]
        bottom = [k for k, _ in ordered[-5:]]
        px = np.arange(1, len(pair_history) + 1, dtype=float)
        empty_group = False
        for ax, group, title, cmap in (
                (axes[3, 1], top, "Top-5 synergies", plt.cm.Greens),
                (axes[3, 2], bottom, "Bottom-5 pairs", plt.cm.Reds)):
            for i, nm in enumerate(group):
                ax.plot(px, series[nm], marker="o", ms=3, lw=1.8,
                        color=cmap(0.4 + 0.12 * i),
                        label=f"{nm} ({means[nm]:.1f})")
            ax.set_xlabel("Epoch"); ax.set_ylabel("Avg waves")
            ax.set_title(title, fontweight="bold")
            if group:
                ax.legend(fontsize=6)
            else:
                ax.text(0.5, 0.5, "мало данных по парам", ha="center", va="center",
                        transform=ax.transAxes, fontsize=9, color="gray")
            ax.grid(alpha=0.2)
    else:
        for idx in (1, 2):
            axes[3, idx].text(0.5, 0.5, "collecting pair data...", ha="center",
                              va="center", transform=axes[3, idx].transAxes)
            axes[3, idx].set_title("Pairs", fontweight="bold")

    # ---------------- 16. Percentiles ----------------
    ax = axes[3, 3]
    p25 = _safe(history, "waves_p25", n)
    p50 = _safe(history, "waves_p50", n, 0.0) or _safe(history, "waves", n)
    p75 = _safe(history, "waves_p75", n)
    p90 = _safe(history, "waves_p90", n)
    ax.fill_between(x, p25, p75, alpha=0.2, color="blue", label="P25-P75")
    ax.plot(x, p50, color="blue", lw=2.2, label="median")
    ax.plot(x, waves, color="red", lw=1.4, alpha=0.8, label="mean")
    ax.plot(x, p90, color="darkblue", lw=1.0, ls=":", label="P90")
    ax.set_xlabel("Epoch"); ax.set_ylabel("Waves")
    ax.set_title("Waves distribution", fontweight="bold")
    ax.legend(fontsize=8); ax.grid(alpha=0.2)

    fig.suptitle(f"TD GNN+Sequence PPO — epoch {epoch}", fontsize=16, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.985))

    epoch_path = os.path.join(out_dir, f"td_training_epoch_{epoch}.png")
    fig.savefig(epoch_path, dpi=110)
    latest = os.path.join(out_dir, "latest.png")
    fig.savefig(latest, dpi=110)
    plt.close(fig)
    return epoch_path


def plot_deck_ranking(ranking: List[tuple], tower_usage: Dict[str, float],
                      map_stats: Dict[str, Dict[str, float]], epoch: int,
                      out_dir: str = "plots") -> Optional[str]:
    """
    Картинка «лучшие/худшие колоды + какие башни реально работали + карты».

    ranking — [(имя_колоды, {n, waves, waves_max, wins, damage}), ...],
              отсортированный по убыванию среднего числа волн.
    """
    os.makedirs(out_dir, exist_ok=True)
    fig, axes = plt.subplots(2, 2, figsize=(18, 11))

    # ---------------- 1. рейтинг колод ----------------
    ax = axes[0, 0]
    if ranking:
        show = ranking[:7] + ([None] if len(ranking) > 12 else []) + ranking[-5:] \
            if len(ranking) > 12 else ranking
        labels, values, colors = [], [], []
        for row in show:
            if row is None:
                labels.append("…")
                values.append(0.0)
                colors.append("white")
                continue
            name, d = row
            labels.append(name.replace("Tower", ""))
            values.append(d["waves"])
            colors.append("tab:green")
        ypos = np.arange(len(labels))
        bars = ax.barh(ypos, values, color=colors, alpha=0.85)
        ax.set_yticks(ypos)
        ax.set_yticklabels(labels, fontsize=6)
        ax.invert_yaxis()
        for b, v in zip(bars, values):
            ax.text(v + 0.2, b.get_y() + b.get_height() / 2, f"{v:.1f}",
                    va="center", fontsize=6)
        ax.set_xlabel("Avg waves")
        ax.set_title("Best / worst decks (average waves)", fontweight="bold")
        ax.grid(alpha=0.2, axis="x")
    else:
        ax.text(0.5, 0.5, "no episodes yet", ha="center", va="center",
                transform=ax.transAxes)
        ax.set_title("Best / worst decks", fontweight="bold")

    # ---------------- 2. использование башен ----------------
    ax = axes[0, 1]
    if tower_usage:
        items = sorted(tower_usage.items(), key=lambda kv: kv[1], reverse=True)
        names = [k.replace("Tower", "") for k, _ in items]
        vals = [v for _, v in items]
        ax.bar(range(len(vals)), vals, color="tab:blue", alpha=0.85)
        ax.set_xticks(range(len(vals)))
        ax.set_xticklabels(names, rotation=45, ha="right", fontsize=7)
        ax.set_ylabel("Построено раз (все эпохи)")
        ax.set_title(f"Tower usage: {len(vals)}/12 типов", fontweight="bold")
        ax.grid(alpha=0.2, axis="y")
    else:
        ax.text(0.5, 0.5, "no towers built yet", ha="center", va="center",
                transform=ax.transAxes)
        ax.set_title("Tower usage", fontweight="bold")

    # ---------------- 3. карты ----------------
    ax = axes[1, 0]
    if map_stats:
        items = sorted(((k, v["waves"] / max(1.0, v["n"]), v["n"])
                        for k, v in map_stats.items()),
                       key=lambda x: x[1], reverse=True)
        names = [k for k, _, _ in items]
        vals = [w for _, w, _ in items]
        ax.bar(range(len(vals)), vals, color="tab:purple", alpha=0.85)
        ax.set_xticks(range(len(vals)))
        ax.set_xticklabels(names, rotation=30, ha="right", fontsize=8)
        ax.set_ylabel("Avg waves")
        ax.set_title("Maps (average waves, all epochs)", fontweight="bold")
        ax.grid(alpha=0.2, axis="y")
    else:
        ax.text(0.5, 0.5, "no map data yet", ha="center", va="center",
                transform=ax.transAxes)
        ax.set_title("Maps", fontweight="bold")

    # ---------------- 4. среднее vs лучшее по колодам ----------------
    ax = axes[1, 1]
    if ranking:
        means = [d["waves"] for _, d in ranking]
        maxes = [d["waves_max"] for _, d in ranking]
        ax.scatter(means, maxes, s=28, color="tab:orange", alpha=0.9)
        lim = max(max(maxes), max(means), 1.0) * 1.05
        ax.plot([0, lim], [0, lim], ls=":", color="gray", lw=1)
        ax.set_xlabel("Avg waves")
        ax.set_ylabel("Best episode waves")
        ax.set_title("Decks: average vs best", fontweight="bold")
        ax.grid(alpha=0.2)
    else:
        ax.set_title("Decks: average vs best", fontweight="bold")

    fig.suptitle(f"TD decks report — epoch {epoch}", fontweight="bold", fontsize=14)
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    path = os.path.join(out_dir, f"decks_epoch_{epoch}.png")
    fig.savefig(path, dpi=110)
    fig.savefig(os.path.join(out_dir, "decks_latest.png"), dpi=110)
    plt.close(fig)
    return path


def plot_waves_histogram(waves: List[int], epoch: int, out_dir: str = "plots") -> Optional[str]:
    """Гистограмма волн по эпизодам эпохи (доп. картинка)."""
    if not waves:
        return None
    os.makedirs(out_dir, exist_ok=True)
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.hist(waves, bins=min(30, max(5, len(set(waves)))), color="steelblue",
            edgecolor="black", alpha=0.8)
    ax.axvline(float(np.mean(waves)), color="red", ls="--", label=f"mean={np.mean(waves):.1f}")
    ax.axvline(float(np.median(waves)), color="green", ls=":", label=f"median={np.median(waves):.1f}")
    ax.set_xlabel("Waves survived"); ax.set_ylabel("Episodes")
    ax.set_title(f"Waves distribution, epoch {epoch}")
    ax.legend(); ax.grid(alpha=0.2)
    path = os.path.join(out_dir, f"waves_hist_epoch_{epoch}.png")
    fig.tight_layout(); fig.savefig(path, dpi=110); plt.close(fig)
    return path

# ============================================================================
# СЕКЦИЯ: trainer.py
# ============================================================================
import json
import itertools
import math
import os
import random
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.optim as optim



# ============================================================================
# Конфиг обучения
# ============================================================================
@dataclass
class TrainConfig:
    # --- масштаб ---
    num_epochs: int = 100
    num_envs: int = 8
    segment_length: int = 64
    episodes_per_epoch: int = 64
    max_steps_per_episode: int = 3000
    # --- оптимизация ---
    lr: float = 3e-4
    gamma: float = 0.995
    lam: float = 0.99            # горизонт GAE; 0.97 при segment=32 слишком короткий
    weight_decay: float = 1e-4
    lr_warmup_steps: int = 2000  # плавный разгон LR
    lr_final_frac: float = 0.3   # cosine до lr * frac
    amp: str = "bf16"            # off | bf16 | fp16 (только CUDA)
    compile_model: bool = False  # torch.compile (Windows: нужен MSVC)
    compile_mode: str = "default"
    # --- дека 1..8 ---
    deck_size_range: Tuple[int, int] = (4, 4)
    deck_min_damage_towers: int = 2   # минимум боевых башен в колоде
    progress: bool = True             # живая строка прогресса по играм
    progress_every: int = 0           # 0 = не дублировать (только живая строка)
    detailed_report: bool = True      # подробный отчёт эпохи (блоки ┌─ ... ┐)
    # --- распределение опыта ---
    stratified_decks: bool = True     # обход ВСЕХ колод по кругу (полное покрытие)
    stratified_maps: bool = True      # round-robin по картам вместо rng.choice
    hard_deck_frac: float = 0.5       # доля эпизодов на «худших» колодах
    # --- проверка обобщения (MAPS_TEST, жадная политика) ---
    eval_test: bool = True
    eval_test_games: int = 1
    eval_seed: int = 777
    # --- среда ---
    macro_idle: bool = True           # схлопывать бесполезные IDLE-тики
    macro_idle_max: int = 60
    wave_curriculum: bool = False     # по умолчанию сразу все max_waves (как в игре)
    wave_curriculum_epochs: int = 30
    wave_curriculum_start: int = 20
    timeout_reward: float = 0.0       # было +2.0 (награда за затягивание игры)
    obs_fp16: bool = False            # fp16 для признаков узлов в буфере
    entropy_scale_final: float = 0.25 # отжиг энтропии к концу обучения
    randomize_deck: bool = True
    randomize_map: bool = True
    games_per_map: int = 5
    # --- игра ---
    max_waves: int = 80
    starting_money: float = 500.0
    starting_hp: int = 10
    max_towers_on_map: int = 50
    max_builds_per_wave: int = 6
    enable_sell: bool = False          # правило про SELL
    difficulty: float = 1.0
    shaping_scale: float = 0.3         # масштаб эвристического шейпинга (1.0 = старое)
    # --- curriculum ---
    use_curriculum: bool = True
    curriculum_epochs_at_target: int = 3
    # --- сеть ---
    hidden_dim: int = 256
    gnn_layers: int = 4
    gnn_type: str = "sage"
    transformer_layers: int = 4
    n_heads: int = 8
    n_quantiles: int = 16
    dropout: float = 0.0          # 0.0 — точные log-prob/ratio в PPO
    mem_len: int = 256
    # --- ppo ---
    ppo: PPOConfig = field(default_factory=PPOConfig)
    # --- инфраструктура ---
    device: str = "auto"
    seed: int = 0
    log_dir: str = "logs"
    checkpoint_dir: str = "checkpoints"
    plot_dir: str = "plots"
    plot_every: int = 1
    resume_from: Optional[str] = None
    auto_resume: bool = False      # подхватить checkpoints/last.pth и продолжить
    deck_report_top: int = 5       # сколько лучших/худших колод печатать
    use_subprocess_envs: bool = True
    verbose: bool = True


# ============================================================================
# Curriculum: ФИКСИРОВАННЫЕ стадии (без рандом-генератора карт)
# ============================================================================
CURRICULUM_STAGES: List[Dict] = [
    {"name": "Стадия 1: базовые башни", "maps": ["map_01"],
     "towers": [0, 1, 2, 3], "target_waves": 14.0},
    {"name": "Стадия 2: +контроль и спецбашни", "maps": ["map_01"],
     "towers": [0, 1, 2, 3, 4, 6, 7, 8, 9, 10], "target_waves": 18.0},
    {"name": "Стадия 3: +link/+income, 2 карты", "maps": ["map_01", "map_02"],
     "towers": list(range(12)), "target_waves": 20.0},
    {"name": "Стадия 4: все башни, 4 карты",
     "maps": ["map_01", "map_02", "map_03", "map_04"],
     "towers": list(range(12)), "target_waves": 25.0},
    {"name": "Стадия 5: все карты TRAIN", "maps": list(MAPS_TRAIN.keys()),
     "towers": list(range(12)), "target_waves": 30.0},
]

# DPS-ядро: при сборке деки гарантируем базовое покрытие урона
# Чистая поддержка — у этих башен урон символический (p1 = 0.05..12, только
# чтобы не делить на ноль), а смысл в эффекте:
#   Slow     — замедление,
#   Movement — толчок/телепорт,
#   Money    — доход,
#   Link     — связка/баф соседей.
# Колода из одних таких башен проигрывает по построению.
SUPPORT_TOWERS = [3, 4, 5, 11]

# Боевое ядро (по таблице игры p1 = Damage): Gun, Area, Crossbow, Poison,
# Trap, Hangman, Billy, DroneHive. Используется как «приоритетный» пул.
DPS_CORE_TOWERS = [0, 1, 2, 6, 7, 8, 9, 10]


def is_damage_tower(tower_id: int) -> bool:
    """True, если башня сама наносит урон (всё, что не чистая поддержка)."""
    return int(tower_id) not in SUPPORT_TOWERS


def deck_is_viable(deck: Sequence[int], min_damage_towers: int = 2) -> bool:
    """
    Проверяет колоду по правилам игры.

    * все башни разные (без дублей);
    * минимум `min_damage_towers` боевых башен (по умолчанию 2 из 4 слотов).

    Это автоматически выкидывает «замедление+монеты», «монеты+телепорт»,
    «телепорт+замедление» и прочие наборы, где нечем убивать.
    """
    deck = [int(t) for t in deck]
    if len(deck) != len(set(deck)):
        return False
    need = max(1, min(int(min_damage_towers), len(deck)))
    return sum(1 for t in deck if is_damage_tower(t)) >= need


class Curriculum:
    """Продвижение по стадиям при стабильном достижении порога волн."""

    def __init__(self, stages: Sequence[Dict] = CURRICULUM_STAGES,
                 epochs_at_target: int = 3, enabled: bool = True):
        self.stages = [dict(s) for s in stages]
        self.epochs_at_target = max(1, epochs_at_target)
        self.enabled = enabled
        # без curriculum сразу берём ПОСЛЕДНЮЮ стадию = все карты и все башни
        self.stage = 0 if enabled else max(0, len(self.stages) - 1)
        self.hits = 0

    @property
    def current(self) -> Dict:
        return self.stages[self.stage]

    @property
    def map_names(self) -> List[str]:
        names = [m for m in self.current["maps"] if m in MAPS_TRAIN]
        return names or list(MAPS_TRAIN.keys())[:1]

    @property
    def towers(self) -> List[int]:
        return list(self.current["towers"])

    def update(self, avg_waves: float) -> bool:
        """True, если стадия сменилась."""
        if not self.enabled or self.stage >= len(self.stages) - 1:
            return False
        if avg_waves >= self.current["target_waves"]:
            self.hits += 1
            if self.hits >= self.epochs_at_target:
                self.stage += 1
                self.hits = 0
                return True
        else:
            self.hits = max(0, self.hits - 1)
        return False

    def generate_deck(self, rng: random.Random,
                      size_range: Tuple[int, int] = (4, 4),
                      min_damage_towers: int = 2) -> List[int]:
        """
        Колода по правилам игры:

        * ровно `size` РАЗНЫХ башен из разрешённых стадией (без дублей);
        * минимум `min_damage_towers` боевых башен — иначе набор вроде
          «замедление + монеты + телепорт + связка» проигрывает по построению;
        * остальные слоты — любая поддержка (замедление, доход, толчок, ...).

        Колода собирается «по построению»: сначала боевое ядро, потом добор.
        """
        lo, hi = size_range
        lo = max(1, min(int(lo), MAX_DECK_SIZE))
        hi = max(lo, min(int(hi), MAX_DECK_SIZE))
        size = rng.randint(lo, hi)

        allowed = list(dict.fromkeys(int(t) for t in self.towers))
        core = [t for t in allowed if is_damage_tower(t)]
        rest = [t for t in allowed if not is_damage_tower(t)]

        need_dps = max(1, min(int(min_damage_towers), size, max(1, len(core))))
        # сколько боевых берём: от обязательного минимума до 3 (иногда 4),
        # чтобы в обучении были и «2 боевых + 2 поддержки», и чисто боевые наборы
        bonus = 1 if (size >= 4 and rng.random() < 0.15) else 0
        upper = min(len(core), size, max(need_dps, min(3, size)) + bonus)
        n_core = rng.randint(need_dps, max(need_dps, upper))
        deck = rng.sample(core, n_core) if core else []

        # добор поддержкой (только уникальные)
        pool = [t for t in rest if t not in deck]
        need = size - len(deck)
        if need > 0 and pool:
            deck.extend(rng.sample(pool, min(need, len(pool))))

        # если поддержки не хватило — добираем оставшимися боевыми
        if len(deck) < size:
            extra = [t for t in core if t not in deck]
            if extra:
                deck.extend(rng.sample(extra, min(size - len(deck), len(extra))))

        if not deck:
            deck = [allowed[0]]

        # страховка: правило должно выполняться всегда
        if not deck_is_viable(deck, min_damage_towers):
            deck = rng.sample(core, min(len(core), size)) or deck

        rng.shuffle(deck)
        return deck[:MAX_DECK_SIZE]


# ============================================================================
# Логгер (консоль + файл)
# ============================================================================
def term_width(default: int = 120) -> int:
    """Ширина терминала. Уважает переменную COLUMNS (важно при переадресации)."""
    try:
        import shutil as _sh
        return max(40, int(_sh.get_terminal_size((default, 24)).columns))
    except Exception:                      # noqa: BLE001
        return default


def rule(char: str = "=", limit: int = 108) -> str:
    """Горизонтальная линейка, не вылезающая за терминал."""
    return char * max(20, min(limit, term_width() - 2))


def wrap_line(line: str, width: Optional[int] = None) -> List[str]:
    """
    Переносит длинную строку по словам, сохраняя отступ.

    Для строк внутри рамки (`  │ текст`) продолжение выравнивается по тексту,
    поэтому блоки `┌─ ... ┐` не разъезжаются.
    """
    if width is None:
        width = term_width() - 1        # -1: не задевать последнюю колонку
    if not line or len(line) <= width:
        return [line]

    if line.startswith("  │ "):
        indent = "  │ "
    elif line.startswith("    "):
        indent = "    "
    elif line.startswith("  "):
        indent = "  "
    else:
        indent = ""
    body = line[len(indent):]
    out: List[str] = []
    cur = indent
    for word in body.split(" "):
        candidate = word if cur.strip() == "" else cur + (" " if cur != indent else "") + word
        if len(candidate) <= width or cur == indent:
            cur = candidate
        else:
            out.append(cur)
            cur = indent + word
    out.append(cur)
    return out


class Logger:
    def __init__(self, log_dir: str = "logs", filename: Optional[str] = None,
                 verbose: bool = True):
        os.makedirs(log_dir, exist_ok=True)
        name = filename or f"train_{time.strftime('%Y%m%d_%H%M%S')}.log"
        self.path = os.path.join(log_dir, name)
        self.verbose = verbose
        self._fh = open(self.path, "a", encoding="utf-8")
        self._fh.write(f"# старт лога {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        self._fh.flush()

    def __call__(self, msg: str = ""):
        for line in wrap_line(msg):
            self._fh.write(line + "\n")
            if self.verbose:
                try:
                    print(line, flush=True)
                except UnicodeEncodeError:      # консоль Windows cp1251
                    print(line.encode("ascii", "replace").decode("ascii"),
                          flush=True)
        self._fh.flush()

    def close(self):
        try:
            self._fh.close()
        except Exception:
            pass


# ============================================================================
# Тренер
# ============================================================================
class Trainer:
    def __init__(self, config: TrainConfig, maps_train: Optional[Dict] = None,
                 maps_test: Optional[Dict] = None):
        self.cfg = config
        self.maps_train = maps_train if maps_train is not None else MAPS_TRAIN
        self.maps_test = maps_test if maps_test is not None else MAPS_TEST

        assert len(self.maps_train) > 0, "MAPS_TRAIN пуст"
        assert len(self.maps_test) > 0, "MAPS_TEST пуст"

        self.device = self._resolve_device(config.device)
        self.rng = random.Random(config.seed)
        self.log = Logger(config.log_dir, verbose=config.verbose)
        os.makedirs(config.checkpoint_dir, exist_ok=True)
        os.makedirs(config.plot_dir, exist_ok=True)

        self.policy_cfg = PolicyConfig(
            hidden_dim=config.hidden_dim, gnn_layers=config.gnn_layers,
            gnn_type=config.gnn_type, transformer_layers=config.transformer_layers,
            n_heads=config.n_heads, n_quantiles=config.n_quantiles,
            dropout=config.dropout, mem_len=config.mem_len,
        )
        self.policy = UniversalTDPolicy(self.policy_cfg).to(self.device)
        self.compiled = False
        if config.compile_model:
            try:
                self.policy = torch.compile(self.policy, mode=config.compile_mode)
                self.compiled = True
                print("[COMPILE] torch.compile включён", flush=True)
            except Exception as exc:      # noqa: BLE001
                print(f"[COMPILE] выключен ({type(exc).__name__}: {exc})", flush=True)
        self.optimizer = optim.AdamW(self.policy.parameters(), lr=config.lr,
                                     weight_decay=config.weight_decay)
        # --- AMP: bf16 по умолчанию; GradScaler нужен только для fp16 ---
        amp = str(config.amp or "off").lower()
        if self.device.type != "cuda" or amp == "off":
            self.amp_dtype = None
        else:
            self.amp_dtype = torch.bfloat16 if amp == "bf16" else torch.float16
        self.scaler = (torch.amp.GradScaler("cuda")
                       if self.amp_dtype is torch.float16 else None)
        # --- LR-расписание: warmup + cosine ---
        self._lr_step_count = 0
        self._lr_total_steps: Optional[int] = None

        self.curriculum = Curriculum(epochs_at_target=config.curriculum_epochs_at_target,
                                     enabled=config.use_curriculum)
        self.history: Dict[str, list] = {}
        self.best_waves = 0.0
        self.start_epoch = 0
        self._crashed = False
        self._train_start = time.time()
        self._epoch_seconds: List[float] = []
        self._last_collect_time = 0.0
        self._table_header = False
        self._live_shown = False
        self._live_len = 0
        self.total_steps = 0
        self.total_episodes = 0
        self._vec = None

        self.deck_totals: Dict[str, Dict[str, float]] = {}
        self.map_totals: Dict[str, Dict[str, float]] = {}
        self.tower_totals: Dict[str, float] = {}
        self._env_map_names: List[str] = []

        # --- стратифицированное распределение опыта ---
        self._deck_pool: List[List[int]] = self._build_deck_pool()
        self._deck_by_key: Dict[Tuple[int, ...], List[int]] = {
            tuple(int(t) for t in d): d for d in self._deck_pool}
        self._deck_queue: List[List[int]] = []
        self._deck_waves: Dict[Tuple[int, ...], List[float]] = {}
        self._map_queue: List[str] = []
        self._cur_max_waves = int(config.max_waves)
        self._last_test: Dict[str, float] = {}

        resume_path = config.resume_from
        if resume_path is None and config.auto_resume:
            candidate = os.path.join(config.checkpoint_dir, "last.pth")
            if os.path.exists(candidate):
                resume_path = candidate
                self.log(f"[АВТО-ДООБУЧЕНИЕ] найден {candidate} — продолжаю с него")
            else:
                self.log("[АВТО-ДООБУЧЕНИЕ] чекпоинта нет — старт с нуля")
        elif resume_path is None:
            self.log("[АВТО-ДООБУЧЕНИЕ] отключено (--no-auto-resume) — старт с нуля")
        if resume_path:
            self.load_checkpoint(resume_path)

    # ---------------------------------------------------------------- utils
    @staticmethod
    def _resolve_device(name: str) -> torch.device:
        """
        Выбирает устройство и НЕ даёт упасть на несовместимой видеокарте.

        Например, RTX 5080/5090 (Blackwell, sm_120) требует сборку PyTorch с
        CUDA 12.8+. Если установленная сборка такие ядра не содержит,
        torch.cuda.is_available() всё равно вернёт True, а первая же операция
        упадёт с "no kernel image is available". Поэтому здесь:
          1) сверяем compute capability карты со списком архитектур сборки;
          2) реально выполняем маленькую операцию на GPU;
          3) при любой проблеме откатываемся на CPU и пишем, как починить.
        """
        wants_cuda = name in (None, "auto", "", "cuda", "cuda:0", "gpu")

        if name not in (None, "auto", "", "gpu"):
            if name.startswith("cuda") and not torch.cuda.is_available():
                warn = ("[УСТРОЙСТВО] CUDA недоступна — работаю на CPU. "
                        "Проверьте драйвер NVIDIA и сборку PyTorch.")
                print(warn, flush=True)
                return torch.device("cpu")
            if not name.startswith("cuda"):
                return torch.device(name)          # cpu / mps / что-то явное

        if not wants_cuda and name not in ("cuda", "cuda:0"):
            return torch.device("cpu")
        if not torch.cuda.is_available():
            if name in ("cuda", "cuda:0"):
                print("[УСТРОЙСТВО] CUDA недоступна — работаю на CPU.", flush=True)
            return torch.device("cpu")

        try:
            idx = torch.cuda.current_device() if name in (None, "auto", "", "gpu",
                                                          "cuda") else 0
            major, minor = torch.cuda.get_device_capability(idx)
            arch = f"sm_{major}{minor}"
            arch_list = list(torch.cuda.get_arch_list())
            gpu_name = torch.cuda.get_device_name(idx)

            if arch_list and arch not in arch_list:
                print(
                    f"[УСТРОЙСТВО] {gpu_name} ({arch}) не поддерживается этой "
                    f"сборкой PyTorch {torch.__version__} "
                    f"(есть: {', '.join(a.replace('sm_', '') for a in arch_list)}).\n"
                    f"             → перехожу на CPU, обучение продолжится.\n"
                    f"             → чтобы включить GPU, поставьте сборку с CUDA 12.8 "
                    f"(для RTX 50xx):",
                    flush=True)
                print("               pip uninstall -y torch torchvision torchaudio", flush=True)
                print("               pip install --index-url "
                      "https://download.pytorch.org/whl/cu128 torch torchvision", flush=True)
                return torch.device("cpu")

            # реальная проверка: одна операция на GPU (ловит и другие несовместимости)
            torch.zeros(8, device="cuda") + 1.0
            torch.cuda.synchronize()
            print(f"[УСТРОЙСТВО] GPU: {gpu_name} ({arch}) — используется", flush=True)
            return torch.device("cuda")
        except Exception as exc:      # noqa: BLE001 — любой сбой GPU не должен ронять обучение
            print(f"[УСТРОЙСТВО] GPU не работает ({type(exc).__name__}: {exc}) → CPU",
                  flush=True)
            return torch.device("cpu")

    # ------------------------------------------------------------ вывод
    def _console(self, msg: str = "", end: str = "\n") -> None:
        """Печать только в консоль (без записи в лог-файл)."""
        if not self.cfg.verbose:
            return
        try:
            print(msg, end=end, flush=True)
        except UnicodeEncodeError:          # консоль Windows в cp1251
            print(msg.encode("ascii", "replace").decode("ascii"), end=end, flush=True)

    @staticmethod
    def _fmt_eta(seconds: float) -> str:
        seconds = max(0.0, float(seconds))
        h, rem = divmod(int(seconds), 3600)
        m, sec = divmod(rem, 60)
        return f"{h}:{m:02d}:{sec:02d}" if h else f"{m:02d}:{sec:02d}"

    @staticmethod
    def _term_width(default: int = 120) -> int:
        return term_width(default)

    def _live_progress(self, episodes: List[Dict], buffer, collect_start: float,
                       target: int) -> None:
        """
        Одна перерисовываемая строка прогресса. Длина подбирается под ширину
        терминала, поэтому строка НЕ переносится и не «дёргается».
        В лог-файл она не пишется (там только постоянные записи), т.к. \r
        в файле выглядел бы мусором.
        """
        if not self.cfg.progress or not episodes:
            return
        n = len(episodes)
        elapsed = max(1e-6, time.time() - collect_start)
        last = episodes[-1]
        steps_done = buffer.total_steps()
        sps = steps_done / elapsed
        per_game = elapsed / n
        eta_collect = per_game * max(0, target - n)
        eta_epoch = eta_collect + self._last_collect_time * 0.35

        full = (f"ИГРА {n:3d}/{target} | волн {last['waves']:2d} | "
                f"баш {last['towers']:2d} | апгр {last['upgrades']:3d} | "
                f"${last['money']:>5.0f} | HP {last['hp']:2d} | "
                f"шаги {last['steps']:4d} | всего {steps_done:,} | "
                f"сегм {len(buffer):4d} | {sps:3.0f} шаг/с | "
                f"{self._fmt_eta(elapsed)} | ETA {self._fmt_eta(eta_epoch)}")
        medium = (f"ИГРА {n:3d}/{target} | волн {last['waves']:2d} | "
                  f"всего {steps_done:,} | сегм {len(buffer):4d} | "
                  f"{sps:3.0f} шаг/с | {self._fmt_eta(elapsed)} | "
                  f"ETA {self._fmt_eta(eta_epoch)}")
        short = (f"ИГРА {n:3d}/{target} | {steps_done:,} шаг | "
                 f"{sps:3.0f} ш/с | ETA {self._fmt_eta(eta_epoch)}")

        width = self._term_width() - 2       # запас под ANSI-очистку
        line = next((v for v in (full, medium, short) if len(v) <= width), short[:width])
        self._console("\r" + line + "\033[K", end="")
        self._live_shown = True
        self._live_len = len(line)

    def _env_config(self, deck_size: int) -> EnvConfig:
        c = self.cfg
        return EnvConfig(
            deck_size=deck_size,
            max_waves=c.max_waves,
            starting_money=c.starting_money,
            starting_hp=c.starting_hp,
            max_towers_on_map=c.max_towers_on_map,
            max_builds_per_wave=c.max_builds_per_wave,
            enable_sell=c.enable_sell,
            shaping_scale=float(c.shaping_scale),
        )

    def _env_fns(self, seeds: Sequence[int]) -> List[Callable]:
        c = self.cfg
        map_names = self.curriculum.map_names
        self._env_map_names = [map_names[i % len(map_names)] for i in range(len(seeds))]
        fns = []
        for i, seed in enumerate(seeds):
            deck = self._pick_deck()
            map_matrix = self.maps_train[map_names[i % len(map_names)]]
            fns.append(make_env_fn(map_matrix, deck, self._env_config(len(deck)),
                                   difficulty=c.difficulty, seed=seed,
                                   macro_idle=c.macro_idle,
                                   macro_idle_max=c.macro_idle_max))
        return fns

    # ------------------------------------------- стратифицированное покрытие
    def _build_deck_pool(self) -> List[List[int]]:
        """Все РАЗЛИЧНЫЕ допустимые колоды (без дублей, без безнадёжных наборов)."""
        c = self.cfg
        lo = max(1, min(int(c.deck_size_range[0]), MAX_DECK_SIZE))
        hi = max(lo, min(int(c.deck_size_range[1]), MAX_DECK_SIZE))
        towers = sorted({int(t) for t in self.curriculum.towers})
        pool: List[List[int]] = []
        for size in range(lo, hi + 1):
            for combo in itertools.combinations(towers, size):
                if deck_is_viable(combo, c.deck_min_damage_towers):
                    pool.append([int(t) for t in combo])
        if not pool:                       # страховка: пул не должен быть пустым
            pool = [list(self.curriculum.generate_deck(
                self.rng, (lo, hi), c.deck_min_damage_towers))]
        return pool

    def _pick_deck(self, current: Optional[Sequence[int]] = None) -> List[int]:
        """
        Выбор колоды на следующую игру.

        1) с вероятностью `hard_deck_frac` — из худшей четверти рейтинга колод
           (там, где агент проходит меньше волн): больше обучения на слабых местах;
        2) иначе — стратифицированный обход: каждая колода пула ровно один раз
           за цикл, поэтому за ~1.5 эпохи покрываются ВСЕ 462 комбинации.
        Повтор текущей колоды запрещён.
        """
        c = self.cfg
        if not c.randomize_deck:
            return list(current) if current else list(self._deck_pool[0])
        have = {int(t) for t in (current or [])}
        deck: Optional[List[int]] = None

        if (c.hard_deck_frac > 0 and len(self._deck_waves) >= 8
                and self.rng.random() < c.hard_deck_frac):
            ranked = sorted(self._deck_waves.items(),
                            key=lambda kv: float(np.mean(kv[1])))
            k = max(1, int(len(ranked) * 0.25))
            key = self.rng.choice(ranked[:k])[0]
            if key in self._deck_by_key:
                deck = list(self._deck_by_key[key])

        for _ in range(6):
            if deck is not None and {int(t) for t in deck} != have:
                break
            if not c.stratified_decks:
                deck = list(self.curriculum.generate_deck(
                    self.rng, c.deck_size_range, c.deck_min_damage_towers))
                continue
            if not self._deck_queue:
                self._deck_queue = [list(d) for d in self._deck_pool]
                self.rng.shuffle(self._deck_queue)
            deck = list(self._deck_queue.pop())
        return deck if deck else list(self._deck_pool[0])

    def _pick_map(self) -> str:
        """Карта следующей игры: round-robin по перемешанному списку TRAIN."""
        names = list(self.maps_train.keys())
        if not self.cfg.stratified_maps:
            return self.rng.choice(names)
        if not self._map_queue:
            self._map_queue = list(names)
            self.rng.shuffle(self._map_queue)
        return self._map_queue.pop()

    def _update_deck_waves(self, episodes: List[Dict]) -> None:
        """Скользящая статистика волн по каждой колоде (для «трудных» выборок)."""
        for e in episodes:
            key = tuple(sorted({int(t) for t in e.get("deck", [])}))
            if not key:
                continue
            lst = self._deck_waves.setdefault(key, [])
            lst.append(float(e.get("waves", 0)))
            if len(lst) > 24:
                del lst[0]

    # ------------------------------------------------------- расписание волн
    def _wave_limit(self, epoch: int) -> int:
        """Длина эпизода: wave_curriculum_start -> max_waves (НЕ баланс игры)."""
        c = self.cfg
        top = max(1, int(c.max_waves))
        if not c.wave_curriculum:
            return top
        start = max(1, min(int(c.wave_curriculum_start), top))
        span = max(1, int(c.wave_curriculum_epochs))
        frac = min(1.0, max(0.0, float(epoch) / span))
        return int(round(start + (top - start) * frac))

    def _apply_wave_curriculum(self, epoch: int) -> int:
        limit = self._wave_limit(epoch)
        if limit == self._cur_max_waves:
            return limit
        self._cur_max_waves = limit
        try:
            if self._vec is not None:
                self._vec.set_max_waves_all(limit)
        except Exception as exc:          # noqa: BLE001
            self.log(f"[WARN] лимит волн не применён: {exc}")
        self.log(f"  [РАСПИСАНИЕ] лимит волн в эпизоде: {limit}")
        return limit

    # ------------------------------------------------------------ LR-график
    def _lr_at_step(self) -> float:
        c = self.cfg
        warm = max(0, int(c.lr_warmup_steps))
        t = int(self._lr_step_count)
        if warm > 0 and t < warm:
            return float(c.lr) * (t + 1) / float(warm)
        total = int(self._lr_total_steps or (warm + 1))
        span = max(1, total - warm)
        prog = min(1.0, max(0.0, float(t - warm) / float(span)))
        final = float(c.lr) * float(c.lr_final_frac)
        return final + 0.5 * (float(c.lr) - final) * (1.0 + math.cos(math.pi * prog))

    def _lr_step(self) -> None:
        self._lr_step_count += 1
        lr = self._lr_at_step()
        for group in self.optimizer.param_groups:
            group["lr"] = lr

    def _entropy_scale(self, epoch: int) -> float:
        """Отжиг энтропии: 1.0 -> entropy_scale_final к последней эпохе."""
        c = self.cfg
        span = max(1, int(c.num_epochs) - 1)
        prog = min(1.0, max(0.0, float(epoch) / span))
        return float(1.0 - (1.0 - float(c.entropy_scale_final)) * prog)

    # ------------------------------------------------- проверка обобщения
    def _eval_test(self, epoch: int) -> Dict[str, float]:
        """Жадная оценка на MAPS_TEST (фиксированные сиды, без обучения)."""
        c = self.cfg
        try:
            decks = [list(self._deck_pool[i % len(self._deck_pool)])
                     for i in range(min(12, len(self._deck_pool)))]
            res = evaluate_greedy(
                self.policy, self.maps_test, decks, self.device,
                games_per_map=c.eval_test_games,
                max_waves=int(c.max_waves), seed=int(c.eval_seed) + epoch * 0,
                enable_sell=c.enable_sell)
            return {k: v for k, v in res.items() if isinstance(v, (int, float))}
        except Exception as exc:          # noqa: BLE001 — оценка не должна ронять обучение
            self.log(f"[WARN] TEST-оценка не удалась: {type(exc).__name__}: {exc}")
            return {}

    def _warmup_compile(self):
        """
        Пробный forward уже после torch.compile.

        На Windows без MSVC (или на экзотической сборке) компиляция падает не
        при создании, а на первом вызове — то есть посреди эпохи. Поэтому
        проверяем один раз и при ошибке молча откатываемся на eager-режим,
        сохранив веса.
        """
        if not self.compiled or self._vec is None:
            return
        try:
            with torch.no_grad():
                graphs = self._vec.reset()
                batch = build_graph_batch(list(graphs), self.device)
                mems = [self.policy.init_memory(1, self.device) for _ in graphs]
                self.policy.act_batch(batch, batch["deck_vec"],
                                      batch["deck_mask"], mems)
            self.log("[COMPILE] torch.compile работает — обучение с ускорением")
        except Exception as exc:          # noqa: BLE001
            self.log(f"[COMPILE] не работает ({type(exc).__name__}: {exc}) "
                     f"→ откат на обычный режим")
            state = {k.replace("_orig_mod.", ""): v.detach().clone()
                     for k, v in self.policy.state_dict().items()}
            self.policy = UniversalTDPolicy(self.policy_cfg).to(self.device)
            self.policy.load_state_dict(state, strict=False)
            self.compiled = False
            self.optimizer = optim.AdamW(self.policy.parameters(),
                                         lr=self.cfg.lr,
                                         weight_decay=self.cfg.weight_decay)

    def _handle(self):
        return SubprocVecEnv if self.cfg.use_subprocess_envs and self.cfg.num_envs > 1 \
            else DummyVecEnv

    def _h(self, key: str) -> list:
        return self.history.setdefault(key, [])

    # ---------------------------------------------------------------- ckpt
    def save_checkpoint(self, path: str, epoch: int, extra: Optional[Dict] = None):
        payload = {
            "epoch": epoch,
            "policy_config": self.policy_cfg.__dict__,
            "policy_state_dict": {k: v.detach().cpu()
                                  for k, v in self.policy.state_dict().items()},
            "optimizer_state_dict": self.optimizer.state_dict(),
            "best_waves": self.best_waves,
            "history": self.history,
            "curriculum_stage": self.curriculum.stage,
            "curriculum_hits": self.curriculum.hits,
            "total_steps": self.total_steps,
            "total_episodes": self.total_episodes,
            "train_config": {k: (list(v) if isinstance(v, tuple) else v)
                             for k, v in self.cfg.__dict__.items() if k != "ppo"},
            "ppo_config": self.cfg.ppo.__dict__,
            "python_random_state": self.rng.getstate(),
            "numpy_random_state": np.random.get_state(),
            "torch_random_state": torch.get_rng_state(),
        }
        if self.scaler is not None:
            payload["scaler_state_dict"] = self.scaler.state_dict()
        if extra:
            payload.update(extra)
        payload["deck_totals"] = self.deck_totals
        payload["map_totals"] = self.map_totals
        payload["tower_totals"] = self.tower_totals
        tmp = path + ".tmp"
        torch.save(payload, tmp)
        os.replace(tmp, path)          # атомарно: Ctrl+C не побьёт файл

    def load_checkpoint(self, path: str):
        if not os.path.exists(path):
            self.log(f"[CKPT] файл не найден: {path} — старт с нуля")
            return
        ckpt = torch.load(path, map_location=self.device, weights_only=False)
        state = {k.replace("_orig_mod.", ""): v
                 for k, v in ckpt["policy_state_dict"].items()}
        # Архитектура могла измениться (например, hidden_dim 96 -> 352). Тогда
        # форма тензоров не совпадёт и torch бросит RuntimeError — обучение
        # не должно из-за этого падать, поэтому фильтруем по форме.
        own = self.policy.state_dict()
        state = {k: v for k, v in state.items()
                 if k in own and tuple(v.shape) == tuple(own[k].shape)}
        missing = [k for k in own if k not in state]
        if len(missing) > len(own) // 2:
            self.log(f"[CKPT] архитектура в {os.path.basename(path)} не совпадает "
                     f"с текущей (совпало {len(state)} из {len(own)} тензоров) — "
                     f"старт с нуля; старый файл не изменён")
            self.start_epoch = 0
            return
        if missing:
            self.log(f"[CKPT] часть весов не совпала: missing={len(missing)}")
        self.policy.load_state_dict(state, strict=False)
        try:
            self.optimizer.load_state_dict(ckpt["optimizer_state_dict"])
        except Exception as exc:
            self.log(f"[CKPT] оптимизатор не загружен: {exc}")
        if self.scaler is not None and "scaler_state_dict" in ckpt:
            try:
                self.scaler.load_state_dict(ckpt["scaler_state_dict"])
            except Exception:
                pass
        self.best_waves = float(ckpt.get("best_waves", 0.0))
        self.history = ckpt.get("history", {}) or {}
        self.start_epoch = int(ckpt.get("epoch", 0))
        self.curriculum.stage = int(ckpt.get("curriculum_stage", 0))
        self.curriculum.hits = int(ckpt.get("curriculum_hits", 0))
        self.total_steps = int(ckpt.get("total_steps", 0))
        self.total_episodes = int(ckpt.get("total_episodes", 0))
        self.deck_totals = ckpt.get("deck_totals", {}) or {}
        self.map_totals = ckpt.get("map_totals", {}) or {}
        self.tower_totals = ckpt.get("tower_totals", {}) or {}
        self.log(f"[CKPT] загружен {path}: epoch={self.start_epoch}, "
                 f"best={self.best_waves:.1f} волн, стадия={self.curriculum.stage}")

    # ---------------------------------------------------------------- collect
    def _collect_epoch(self, epoch: int) -> Dict:
        c = self.cfg
        vec = self._vec
        buffer = SequencePPOBuffer(segment_length=c.segment_length,
                                   gamma=c.gamma, lam=c.lam,
                                   obs_fp16=c.obs_fp16)
        graphs = vec.reset()

        memories = [self.policy.init_memory(1, self.device)
                    for _ in range(c.num_envs)]
        for i in range(c.num_envs):
            buffer.init_env_buffer(i, memories[i])

        ep_reward = np.zeros(c.num_envs, dtype=np.float64)
        ep_actions = np.zeros((c.num_envs, 4), dtype=np.int64)
        ep_steps = np.zeros(c.num_envs, dtype=np.int64)
        games_on_map = np.zeros(c.num_envs, dtype=np.int64)
        episodes: List[Dict] = []
        collect_start = time.time()

        self.policy.eval()
        with torch.no_grad():
            while len(episodes) < c.episodes_per_epoch:
                batch = build_graph_batch(list(graphs), self.device)
                out = self.policy.act_batch(batch, batch["deck_vec"],
                                            batch["deck_mask"], memories)

                actions = out["action_type"].cpu().numpy()
                slots = out["slot"].cpu().numpy()
                nodes = out["node"].cpu().numpy()
                lp = out["log_prob"].cpu().numpy()
                lp_type = out["log_prob_type"].cpu().numpy()
                lp_slot = out["log_prob_slot"].cpu().numpy()
                lp_node = out["log_prob_node"].cpu().numpy()
                values = out["value"].cpu().numpy()

                next_graphs, rewards, dones, infos = vec.step(actions, slots, nodes)
                self.total_steps += c.num_envs

                for i in range(c.num_envs):
                    info = dict(infos[i])
                    ep_steps[i] += 1

                    # --- страховка от бесконечных эпизодов ---
                    timeout = False
                    if ep_steps[i] >= c.max_steps_per_episode and not dones[i]:
                        dones[i] = True
                        timeout = True
                        rewards[i] += float(c.timeout_reward)
                        info["result"] = "timeout"
                        next_graphs[i] = vec.reset_one(i)

                    ep_actions[i, int(actions[i])] += 1

                    # --- таргеты вспомогательных голов ---
                    died = bool(dones[i]) and info.get("result") == "defeat"
                    aux_survival = 0.0 if died else 1.0
                    aux_money = float(np.clip(
                        np.log1p(max(0.0, info.get("money", 0.0))) / LOG_MONEY_CAP,
                        0.0, 1.0))
                    aux_kills = float(np.clip(
                        np.log1p(max(0.0, info.get("total_kills", 0))) / LOG_KILLS_CAP,
                        0.0, 1.0))

                    flushed = buffer.store_step(
                        env_idx=i,
                        graph=graphs[i],
                        action_type=int(actions[i]),
                        slot=int(slots[i]),
                        node=int(nodes[i]),
                        reward=float(rewards[i]),
                        value=float(values[i]),
                        log_prob=float(lp[i]),
                        done=bool(dones[i]),
                        log_prob_type=float(lp_type[i]),
                        log_prob_slot=float(lp_slot[i]),
                        log_prob_node=float(lp_node[i]),
                        aux_survival=aux_survival,
                        aux_money=aux_money,
                        aux_kills=aux_kills,
                        credit_targets=info.get("tower_credit_targets"),
                        reward_components=info.get("reward_components"),
                    )

                    # --- память: при done сбрасываем, иначе несём дальше ---
                    if dones[i]:
                        memories[i] = self.policy.init_memory(1, self.device)
                        if flushed:
                            # новый сегмент тоже начинается с чистой памяти
                            buffer.set_pending_hidden(i, None)
                    else:
                        memories[i] = self.policy.slice_memory(
                            out["new_memory"], out["new_memory_mask"], i, self.device)
                        if flushed:
                            buffer.set_pending_hidden(i, memories[i])

                    ep_reward[i] += float(rewards[i])

                    if not dones[i]:
                        continue

                    episodes.append({
                        "waves": int(info.get("wave", 0)),
                        "reward": float(ep_reward[i]),
                        "damage": float(info.get("total_damage", 0.0)),
                        "kills": int(info.get("total_kills", 0)),
                        "towers": int(info.get("towers", 0)),
                        "upgrades": int(info.get("upgrades", 0)),
                        "sells": int(info.get("sells", 0)),
                        "money": float(info.get("money", 0.0)),
                        "hp": int(info.get("hp", 0)),
                        "deck": list(info.get("deck", [])),
                        "deck_size": len(info.get("deck", [])),
                        "steps": int(ep_steps[i]),
                        "actions": ep_actions[i].copy(),
                        "avg_tower_level": float(info.get("avg_tower_level", 0.0)),
                        "max_tower_level": int(info.get("max_tower_level", 0)),
                        "tower_damage_stats": dict(info.get("tower_damage_stats", {})),
                        "result": info.get("result", ""),
                        "map": (self._env_map_names[i]
                                if i < len(self._env_map_names) else "?"),
                    })
                    self.total_episodes += 1

                    ep_reward[i] = 0.0
                    ep_actions[i] = 0
                    ep_steps[i] = 0

                    self._live_progress(episodes, buffer, collect_start,
                                        c.episodes_per_epoch)

                    # --- смена деки (1..8 слотов) / ФИКСИРОВАННОЙ карты ---
                    if c.randomize_deck:
                        new_deck = self._pick_deck(current=info.get("deck", []))
                        vec.set_deck(i, new_deck)
                        next_graphs[i] = vec.reset_one(i)
                        memories[i] = self.policy.init_memory(1, self.device)
                        buffer.set_pending_hidden(i, None)

                    if c.randomize_map:
                        games_on_map[i] += 1
                        if games_on_map[i] >= c.games_per_map:
                            games_on_map[i] = 0
                            name = self._pick_map()
                            vec.set_map(i, self.maps_train[name])
                            self._env_map_names[i] = name
                            next_graphs[i] = vec.reset_one(i)
                            memories[i] = self.policy.init_memory(1, self.device)
                            buffer.set_pending_hidden(i, None)

                    if len(episodes) >= c.episodes_per_epoch:
                        break

                graphs = next_graphs

            # --- bootstrap value для последнего шага каждой среды ---
            final_batch = build_graph_batch(list(graphs), self.device)
            out = self.policy.act_batch(final_batch, final_batch["deck_vec"],
                                        final_batch["deck_mask"], memories)
            vals = out["value"].cpu().numpy()
            last_values = {i: float(vals[i]) for i in range(c.num_envs)}

        # --- ОБЯЗАТЕЛЬНЫЙ порядок: hidden reset -> GAE -> finalize_all ---
        buffer.finalize_all(last_values)

        collect_time = time.time() - collect_start
        self._last_collect_time = collect_time
        waves = [e["waves"] for e in episodes]
        if self._live_shown:
            # стираем живую строку целиком и уходим на новую
            self._console("\r" + " " * max(0, self._live_len) + "\r", end="")
            self._live_shown = False
        self.log(
            f"  [СБОР ЗАВЕРШЁН] {len(episodes)} игр | волны (avg): "
            f"{np.mean(waves):.1f} | шагов: {buffer.total_steps():,} | "
            f"сегментов: {len(buffer)} | SPS: "
            f"{buffer.total_steps() / max(1e-6, collect_time):.0f} | "
            f"{self._fmt_eta(collect_time)}")

        return {"buffer": buffer, "episodes": episodes,
                "collect_time": collect_time}

    # ---------------------------------------------------------------- stats
    def _epoch_stats(self, episodes: List[Dict], stats: Dict[str, float]) -> Dict[str, float]:
        waves = (np.array([e["waves"] for e in episodes], dtype=np.float32)
                 if episodes else np.zeros(1, dtype=np.float32))
        actions = (np.stack([e["actions"] for e in episodes]).astype(np.float64)
                   if episodes else np.zeros((1, 4)))
        # доли действий в процентах (а не абсолютные счётчики)
        totals = actions.sum(axis=1, keepdims=True)
        shares = 100.0 * actions / np.maximum(totals, 1.0)

        out = {
            "waves": float(waves.mean()),
            "waves_median": float(np.median(waves)),
            "waves_p25": float(np.percentile(waves, 25)),
            "waves_p75": float(np.percentile(waves, 75)),
            "waves_p90": float(np.percentile(waves, 90)),
            "waves_std": float(waves.std()),
            "waves_min": float(waves.min()),
            "waves_max": float(waves.max()),
            "rewards": float(np.mean([e["reward"] for e in episodes])) if episodes else 0.0,
            "avg_damage": float(np.mean([e["damage"] for e in episodes])) if episodes else 0.0,
            "avg_kills": float(np.mean([e["kills"] for e in episodes])) if episodes else 0.0,
            "towers": float(np.mean([e["towers"] for e in episodes])) if episodes else 0.0,
            "upgrades": float(np.mean([e["upgrades"] for e in episodes])) if episodes else 0.0,
            "avg_tower_level": float(np.mean([e["avg_tower_level"] for e in episodes])) if episodes else 0.0,
            "avg_money_end": float(np.mean([e["money"] for e in episodes])) if episodes else 0.0,
            "avg_hp": float(np.mean([e["hp"] for e in episodes])) if episodes else 0.0,
            "avg_episode_len": float(np.mean([e["steps"] for e in episodes])) if episodes else 0.0,
            "build_pct": float(shares[:, BUILD].mean()),
            "upgrade_pct": float(shares[:, UPGRADE].mean()),
            "idle_pct": float(shares[:, IDLE].mean()),
            "sell_pct": float(shares[:, SELL].mean()),
            "timeouts": float(sum(1 for e in episodes if e["result"] == "timeout")),
            "victories": float(sum(1 for e in episodes if e["result"] == "victory")),
            "defeats": float(sum(1 for e in episodes if e["result"] == "defeat")),
            "n_episodes": float(len(episodes)),
            "deck_size_mean": float(np.mean([e["deck_size"] for e in episodes])) if episodes else 0.0,
        }
        prod = out["build_pct"] + out["upgrade_pct"] + out["sell_pct"]
        out["upgrade_ratio"] = out["upgrade_pct"] / prod if prod > 0 else 0.0
        out["deck_sizes"] = sorted({e["deck_size"] for e in episodes})
        out.update({k: float(v) for k, v in stats.items()
                    if isinstance(v, (int, float))})
        return out

    @staticmethod
    def _pair_stats(episodes: List[Dict]) -> Dict[str, float]:
        """Средние волны по парам башен (для графиков синергий)."""
        acc: Dict[Tuple[int, int], List[int]] = {}
        for e in episodes:
            deck = sorted(set(e["deck"]))
            for i in range(len(deck)):
                for j in range(i + 1, len(deck)):
                    acc.setdefault((deck[i], deck[j]), []).append(e["waves"])
        return {f"{a}+{b}": float(np.mean(v)) for (a, b), v in acc.items()
                if len(v) >= 2}

    def _append_history(self, st: Dict[str, float], epoch: int, epoch_time: float,
                        buffer, lr: float):
        pairs = st.pop("_pairs", {})
        for key, val in st.items():
            if isinstance(val, (int, float)):
                self._h(key).append(float(val))
        self._h("time").append(epoch_time)
        self._h("current_lr").append(lr)
        self._h("segments_per_epoch").append(float(len(buffer)))
        self._h("steps_per_epoch").append(float(buffer.total_steps()))
        self._h("pair_history").append(pairs)
        self._h("curriculum_stage").append(float(self.curriculum.stage))
        self._h("epoch").append(float(epoch + 1))

    # ------------------------------------------------------- колоды/карты/башни
    @staticmethod
    def _deck_name(deck: Sequence[int]) -> str:
        """Имя колоды = имена башен через + (например GunTower+SlowTower)."""
        return "+".join(TOWER_TYPES_DATA[int(t)].name for t in deck)

    @staticmethod
    def _deck_variant(deck: Sequence[int]) -> str:
        """Сколько в колоде боевых башен и сколько поддержки."""
        dps = sum(1 for t in deck if is_damage_tower(t))
        return f"{dps}DPS+{len(deck) - dps}SUP"

    def _deck_map_stats(self, episodes: List[Dict]) -> Dict[str, object]:
        """Рейтинг колод, карт и фактическое использование башен за эпоху."""
        decks: Dict[str, Dict[str, float]] = {}
        maps: Dict[str, Dict[str, float]] = {}
        towers: Dict[str, float] = {}

        for e in episodes:
            name = self._deck_name(e["deck"])
            d = decks.setdefault(name, {"n": 0.0, "waves": 0.0, "waves_max": 0.0,
                                       "damage": 0.0, "wins": 0.0,
                                       "size": float(len(e["deck"]))})
            d["n"] += 1.0
            d["waves"] += float(e["waves"])
            d["waves_max"] = max(d["waves_max"], float(e["waves"]))
            d["damage"] += float(e["damage"])
            d["wins"] += 1.0 if e["result"] == "victory" else 0.0

            m = maps.setdefault(e.get("map", "?"), {"n": 0.0, "waves": 0.0})
            m["n"] += 1.0
            m["waves"] += float(e["waves"])

            for tname in e.get("tower_damage_stats", {}):
                towers[tname] = towers.get(tname, 0.0) + 1.0

        for d in decks.values():
            d["waves_mean"] = d["waves"] / max(1.0, d["n"])
            d["damage_mean"] = d["damage"] / max(1.0, d["n"])
        for m in maps.values():
            m["waves_mean"] = m["waves"] / max(1.0, m["n"])
        return {"decks": decks, "maps": maps, "towers": towers}

    def _update_totals(self, stats: Dict[str, object]) -> None:
        """Накапливает статистику по всем эпохам (а не только по текущей)."""
        for name, d in stats["decks"].items():
            t = self.deck_totals.setdefault(
                name, {"n": 0.0, "waves": 0.0, "waves_max": 0.0, "wins": 0.0,
                       "damage": 0.0})
            t["n"] += d["n"]
            t["waves"] += d["waves"]
            t["waves_max"] = max(t["waves_max"], d["waves_max"])
            t["wins"] += d["wins"]
            t["damage"] += d["damage"]
        for name, m in stats["maps"].items():
            t = self.map_totals.setdefault(name, {"n": 0.0, "waves": 0.0})
            t["n"] += m["n"]
            t["waves"] += m["waves"]
        for name, c in stats["towers"].items():
            self.tower_totals[name] = self.tower_totals.get(name, 0.0) + c

    def _ranked_decks(self) -> List[Tuple[str, Dict[str, float]]]:
        rows = []
        for name, t in self.deck_totals.items():
            if t["n"] < 1:
                continue
            rows.append((name, {"n": t["n"], "waves": t["waves"] / max(1.0, t["n"]),
                                "waves_max": t["waves_max"], "wins": t["wins"],
                                "damage": t["damage"] / max(1.0, t["n"])}))
        rows.sort(key=lambda kv: (kv[1]["waves"], kv[1]["n"]), reverse=True)
        return rows

    def _deck_lines(self) -> List[str]:
        """Строки отчёта: лучшие/худшие колоды, карты, реально построенные башни."""
        rows = self._ranked_decks()
        if not rows:
            return ["  Колоды: пока нет завершённых эпизодов"]
        n_top = max(1, self.cfg.deck_report_top)
        top = rows[:n_top]
        bottom = rows[-n_top:][::-1]
        lines = [f"  ЛУЧШИЕ КОЛОДЫ (все эпохи, среднее волн; всего колод {len(rows)}):"]
        for i, (name, d) in enumerate(top, 1):
            lines.append(f"    {i}. {name} — {d['waves']:.1f} волн "
                         f"(n={int(d['n'])}, max {d['waves_max']:.0f}, "
                         f"побед {int(d['wins'])})")
        lines.append("  ХУДШИЕ КОЛОДЫ:")
        for i, (name, d) in enumerate(bottom, 1):
            lines.append(f"    {i}. {name} — {d['waves']:.1f} волн "
                         f"(n={int(d['n'])}, max {d['waves_max']:.0f})")
        if self.map_totals:
            maps = sorted(((k, v["waves"] / max(1.0, v["n"]), int(v["n"]))
                           for k, v in self.map_totals.items()),
                          key=lambda x: x[1], reverse=True)
            lines.append("  КАРТЫ (среднее волн): " + " | ".join(
                f"{k} {w:.1f} (n={n})" for k, w, n in maps))
        if self.tower_totals:
            towers = sorted(self.tower_totals.items(), key=lambda kv: kv[1],
                            reverse=True)
            shown = " | ".join(f"{k} {int(v)}" for k, v in towers[:6])
            tail = f" … (+{len(towers) - 6})" if len(towers) > 6 else ""
            lines.append("  БАШНИ (построены раз): " + shown + tail)
            lines.append(f"  Задействовано: башен {len(self.tower_totals)}/"
                         f"{len(TOWER_TYPES_DATA)}, карт {len(self.map_totals)}/"
                         f"{len(self.maps_train)}")
        return lines

    # ------------------------------------------------- подробный отчёт эпохи
    _BOX_TOP = "  ┌─ {} " 
    _BOX_BOT = "  └" + "─" * 70

    def _box(self, title: str):
        head = f"  ┌─ {title} " + "─" * max(0, 66 - len(title))
        self.log(head + "┐")
        return lambda text: self.log("  │ " + text)

    def _detail_report(self, episodes: List[Dict], st: Dict[str, float],
                       epoch: int, epoch_time: float, collect_time: float,
                       buffer, lr: float) -> None:
        """Полный отчёт эпохи в блоках — то, что нужно для анализа руками."""
        if not self.cfg.detailed_report or not episodes:
            return
        log = self.log
        waves = np.array([e["waves"] for e in episodes], dtype=np.float32)

        # ------------------------------------------------ ВОЛНЫ
        w = self._box("ВОЛНЫ")
        w(f"Среднее: {waves.mean():.1f} | Медиана: {np.median(waves):.1f} | "
          f"σ: {waves.std():.1f}")
        w(f"Мин: {waves.min():.0f} | Макс: {waves.max():.0f} | "
          f"Best ever: {self.best_waves:.0f}")
        w(f"Перцентили: P25={np.percentile(waves, 25):.0f}  "
          f"P75={np.percentile(waves, 75):.0f}  "
          f"P90={np.percentile(waves, 90):.0f}")
        buckets = [(0, 5), (6, 10), (11, 15), (16, 20), (21, 30), (31, 10 ** 6)]
        dist = "  ".join(f"[{a}-{'∞' if b > 1000 else b}]="
                         f"{int(((waves >= a) & (waves <= b)).sum())}"
                         for a, b in buckets)
        w(f"Распределение: {dist}")
        w(f"Победы: {int(st['victories'])} | Поражения: {int(st['defeats'])} | "
          f"Таймауты: {int(st['timeouts'])} | Игр: {len(episodes)}")
        hist_waves = [float(x) for x in self.history.get("waves", [])][-5:]
        if len(hist_waves) >= 2:
            trend = hist_waves[-1] - hist_waves[0]
            w(f"Тренд ({len(hist_waves)} эпох): {trend:+.1f} "
              f"{'▲ растёт' if trend > 1 else ('▼ падает' if trend < -1 else '─ ровно')}")
        self.log(self._BOX_BOT)

        # ------------------------------------------------ ЛУЧШАЯ / ХУДШАЯ ИГРЫ
        best = max(episodes, key=lambda e: e["waves"])
        worst = min(episodes, key=lambda e: e["waves"])
        b = self._box("ЛУЧШАЯ / ХУДШАЯ ИГРЫ")
        for tag, g in (("★ Лучшая", best), ("▼ Худшая", worst)):
            deck = ", ".join(TOWER_TYPES_DATA[t].name.replace("Tower", "")
                             for t in g["deck"])
            b(f"{tag}: {g['waves']} волн | карта {g.get('map', '?')} | "
              f"башен={g['towers']} апгр={g['upgrades']} | "
              f"урон={g['damage']:,.0f} | $={g['money']:.0f} | HP={g['hp']} | "
              f"шагов={g['steps']}")
            b(f"        колода: {deck}")
        self.log(self._BOX_BOT)

        # ------------------------------------------------ БОЕВАЯ ЭФФЕКТИВНОСТЬ
        e = self._box("БОЕВАЯ ЭФФЕКТИВНОСТЬ")
        dmg = float(np.mean([x["damage"] for x in episodes]))
        tw = max(1e-6, float(np.mean([x["towers"] for x in episodes])))
        wa = max(1e-6, float(waves.mean()))
        spent = max(1.0, float(np.mean([x["money"] for x in episodes])) + tw * 100.0)
        e(f"Урон: {dmg:,.0f} | Kills: {st['avg_kills']:.0f} | "
          f"$ в конце: {st['avg_money_end']:.0f}")
        e(f"Урон/башню: {dmg / tw:,.0f} | Урон/волну: {dmg / wa:,.0f} | "
          f"Урон/$: {dmg / spent:.0f}")
        hp = [x["hp"] for x in episodes]
        e(f"HP: avg={np.mean(hp):.1f} | с полным HP: {sum(1 for h in hp if h >= 10)} | "
          f"смерть (0): {sum(1 for h in hp if h <= 0)}")
        self.log(self._BOX_BOT)

        # ------------------------------------------------ СТРОИТЕЛЬСТВО
        cbox = self._box("СТРОИТЕЛЬСТВО")
        cbox(f"Башни: {st['towers']:.1f} | Апгрейды: {st['upgrades']:.0f} | "
             f"ср.уровень: {st['avg_tower_level']:.2f} | "
             f"макс уровень: {max(x['max_tower_level'] for x in episodes)}")
        pop = {}
        for x in episodes:
            for name in x.get("tower_damage_stats", {}):
                pop[name] = pop.get(name, 0) + 1
        if pop:
            top = sorted(pop.items(), key=lambda kv: kv[1], reverse=True)[:6]
            cbox("Популярные типы: " + ", ".join(f"{k.replace('Tower', '')}({v})"
                                                for k, v in top))
        uniq = {tuple(sorted(x["deck"])) for x in episodes}
        cbox(f"Уникальных колод за эпоху: {len(uniq)} "
             f"(всего в истории: {len(self.deck_totals)})")
        self.log(self._BOX_BOT)

        # ------------------------------------------------ АНАЛИЗ КОЛОД
        d = self._box("АНАЛИЗ КОЛОД")
        by_waves = sorted(episodes, key=lambda x: x["waves"], reverse=True)
        d("★ ТОП-3 ЛУЧШИЕ ИГРЫ:")
        for i, g in enumerate(by_waves[:3], 1):
            d(f"  {i}. {g['waves']} волн | {g.get('map', '?')} | "
              f"башен={g['towers']} апгр={g['upgrades']} | "
              f"урон={g['damage']:,.0f} | колода: "
              f"{self._deck_name(g['deck'])}")
        d("▼ ТОП-3 ХУДШИЕ ИГРЫ:")
        for i, g in enumerate(by_waves[-3:][::-1], 1):
            d(f"  {i}. {g['waves']} волн | {g.get('map', '?')} | "
              f"башен={g['towers']} апгр={g['upgrades']} | "
              f"урон={g['damage']:,.0f} | колода: "
              f"{self._deck_name(g['deck'])}")

        # влияние типов башен: с ней и без неё
        infl = []
        for t in TOWER_TYPES_DATA:
            with_t = [x["waves"] for x in episodes if t in x["deck"]]
            without_t = [x["waves"] for x in episodes if t not in x["deck"]]
            if len(with_t) >= 2 and len(without_t) >= 2:
                infl.append((TOWER_TYPES_DATA[t].name, float(np.mean(with_t)),
                             len(with_t), float(np.mean(without_t)), len(without_t)))
        if infl:
            d("ВЛИЯНИЕ ТИПОВ БАШЕН НА ВЫЖИВАНИЕ (с ней / без неё):")
            for name, mw, nw, mo, no in sorted(infl, key=lambda r: r[1] - r[3],
                                               reverse=True):
                diff = mw - mo
                bar = "▲" if diff > 1 else ("▼" if diff < -1 else "─")
                d(f"  {bar} {name.replace('Tower', ''):>13}: с={mw:5.1f} "
                  f"({nw:2d} игр) | без={mo:5.1f} ({no:2d} игр) | Δ={diff:+.1f}")

        # лучшие / худшие пары башен
        pair_acc: Dict[Tuple[int, int], List[int]] = {}
        for x in episodes:
            deck = sorted(set(x["deck"]))
            for i in range(len(deck)):
                for j in range(i + 1, len(deck)):
                    pair_acc.setdefault((deck[i], deck[j]), []).append(x["waves"])
        pairs = [(k, float(np.mean(v)), len(v)) for k, v in pair_acc.items() if len(v) >= 2]
        if pairs:
            pairs.sort(key=lambda r: r[1], reverse=True)
            d("🤝 ЛУЧШИЕ КОМБИНАЦИИ (пары):")
            for (a, bb), mw, n in pairs[:3]:
                d(f"  ★ {TOWER_TYPES_DATA[a].name.replace('Tower', '')}+"
                  f"{TOWER_TYPES_DATA[bb].name.replace('Tower', '')}: "
                  f"avg={mw:.1f} волн ({n} игр)")
            d("💔 ХУДШИЕ КОМБИНАЦИИ (пары):")
            for (a, bb), mw, n in pairs[-3:][::-1]:
                d(f"  ✗ {TOWER_TYPES_DATA[a].name.replace('Tower', '')}+"
                  f"{TOWER_TYPES_DATA[bb].name.replace('Tower', '')}: "
                  f"avg={mw:.1f} волн ({n} игр)")
        self.log(self._BOX_BOT)

        # ------------------------------------------------ ПРОФИЛЬ ЭФФЕКТИВНОСТИ
        agg_dmg: Dict[str, float] = {}
        agg_cnt: Dict[str, int] = {}
        agg_time: Dict[str, float] = {}
        for x in episodes:
            game_time = max(10.0, x["waves"] * 25.0)
            for name, (dmg_t, cnt_t) in x.get("tower_damage_stats", {}).items():
                agg_dmg[name] = agg_dmg.get(name, 0.0) + float(dmg_t)
                agg_cnt[name] = agg_cnt.get(name, 0) + int(cnt_t)
                agg_time[name] = agg_time.get(name, 0.0) + game_time * int(cnt_t)
        if agg_dmg:
            pr = self._box("ПРОФИЛЬ ЭФФЕКТИВНОСТИ (на 1 башню)")
            pr(f"{'Тип':>15} | {'Dmg/Tw':>9} | {'DPS/Tw':>6} | {'Cnt/Game':>8} |")
            rows = []
            for name, total in agg_dmg.items():
                cnt = max(1, agg_cnt[name])
                games = sum(1 for x in episodes if name in x.get("tower_damage_stats", {}))
                rows.append((name, total / cnt, total / max(1.0, agg_time[name]),
                             cnt / max(1, games)))
            for name, dmg_t, dps_t, cnt_g in sorted(rows, key=lambda r: r[2],
                                                    reverse=True):
                ds = (f"{dmg_t / 1e6:.1f}M" if dmg_t > 1e6 else
                      (f"{dmg_t / 1e3:.0f}k" if dmg_t > 1e3 else f"{dmg_t:.0f}"))
                pr(f"{name.replace('Tower', ''):>15} | {ds:>9} | {dps_t:>6.0f} | "
                   f"{cnt_g:>8.1f} |")
            self.log(self._BOX_BOT)

        # ------------------------------------------------ ДЕЙСТВИЯ
        a = self._box("ДЕЙСТВИЯ")
        steps = [x["steps"] for x in episodes]
        productive = 100.0 - st["idle_pct"]
        a(f"Build={st['build_pct']:.1f}% | Upgrade={st['upgrade_pct']:.1f}% | "
          f"Idle={st['idle_pct']:.1f}% | Sell={st['sell_pct']:.2f}%")
        a(f"Всего шагов: {np.mean(steps):.0f} (min={min(steps)}, max={max(steps)}) | "
          f"продуктивных: {productive:.1f}% | upgrade ratio: "
          f"{st['upgrade_ratio'] * 100:.1f}%")
        a(f"Награда: avg={st['rewards']:.0f} | min={min(x['reward'] for x in episodes):.0f} | "
          f"max={max(x['reward'] for x in episodes):.0f}")
        self.log(self._BOX_BOT)

        # ------------------------------------------------ SEQUENCE PPO
        sp = self._box("SEQUENCE PPO")
        sp(f"Segment Length: {self.cfg.segment_length} | сегментов: {len(buffer)} | "
           f"шагов: {buffer.total_steps():,} | обновлений PPO: "
           f"{int(st.get('n_updates', 0))}")
        sp(f"Сбор эпохи: {self._fmt_eta(collect_time)} | апдейт: "
           f"{self._fmt_eta(max(0.0, epoch_time - collect_time))} | "
           f"SPS: {buffer.total_steps() / max(1e-6, epoch_time):.0f}")
        self.log(self._BOX_BOT)

        # ------------------------------------------------ LOSSES
        lo = self._box("LOSSES")
        lo(f"Policy: {st.get('loss_pi', 0):.6f} | Value: {st.get('loss_v', 0):.6f}")
        lo(f"Quantile: {st.get('loss_quantile', 0):.6f} "
           f"(spread: {st.get('quantile_spread', 0):.3f})")
        lo(f"Aux Total: {st.get('loss_aux', 0):.6f}")
        lo(f"  ├─ Survival: {st.get('loss_aux_survival', 0):.6f}")
        lo(f"  ├─ Money: {st.get('loss_aux_money', 0):.6f}")
        lo(f"  └─ Kills: {st.get('loss_aux_kills', 0):.6f}")
        lo(f"Entropy: {st.get('entropy', 0):.4f} (type {st.get('entropy_type', 0):.3f} / "
           f"slot {st.get('entropy_slot', 0):.3f} / node {st.get('entropy_node', 0):.3f})")
        lo(f"approx_kl={st.get('approx_kl', 0):.4f} | "
           f"clipfrac={st.get('clipfrac', 0):.3f} (type {st.get('clipfrac_type', 0):.2f} / "
           f"slot {st.get('clipfrac_slot', 0):.2f} / node {st.get('clipfrac_node', 0):.2f})")
        lo(f"PopArt: mu={st.get('popart_mu', 0):.2f} | sigma={st.get('popart_sigma', 0):.2f} | "
           f"credit loss: {st.get('loss_credit', 0):.4f}")
        self.log(self._BOX_BOT)

        # ------------------------------------------------ ПРЕДСКАЗАНИЯ
        pr2 = self._box("ПРЕДСКАЗАНИЯ (auxiliary)")
        pr2(f"Survival Acc: {st.get('survival_acc', 0) * 100:.1f}% | "
            f"Money MAE: {st.get('money_mae', 0):.3f} | "
            f"Kills MAE: {st.get('kills_mae', 0):.3f}")
        self.log(self._BOX_BOT)

        # ------------------------------------------------ ОБУЧЕНИЕ + ВРЕМЯ
        tr = self._box("ОБУЧЕНИЕ / ВРЕМЯ")
        total_time = time.time() - self._train_start
        avg_epoch = total_time / max(1, epoch + 1)
        left = max(0, self.cfg.num_epochs - (epoch + 1))
        tr(f"LR: {lr:.2e} | curriculum: стадия {self.curriculum.stage} "
           f"(цель {self.curriculum.current['target_waves']:.0f} волн) | "
           f"device: {self.device}")
        tr(f"Эпоха: {epoch_time:.0f}s (сбор {collect_time:.0f}s) | "
           f"Всего: {self._fmt_eta(total_time)} | "
           f"ETA: {self._fmt_eta(avg_epoch * left)} ({left} эпох осталось)")
        tr(f"Счётчики: эпох {epoch + 1}/{self.cfg.num_epochs} | "
           f"игр {self.total_episodes} | шагов {self.total_steps:,}")
        self.log(self._BOX_BOT)

    def _print_epoch(self, epoch: int, st: Dict[str, float], epoch_time: float,
                     buffer, lr: float, episodes: Optional[List[Dict]] = None,
                     collect_time: float = 0.0):
        log = self.log
        log("")
        log(rule("="))
        log(f"ЭПОХА {epoch + 1} | стадия {self.curriculum.stage} "
            f"({self.curriculum.current['name']}) | цель "
            f"{self.curriculum.current['target_waves']:.0f} волн")
        log(rule("-"))
        log(f"  Волны: mean {st['waves']:.1f} | median {st['waves_median']:.1f} | "
            f"P25/P75/P90 {st['waves_p25']:.0f}/{st['waves_p75']:.0f}/"
            f"{st['waves_p90']:.0f} | min/max {st['waves_min']:.0f}/{st['waves_max']:.0f} | "
            f"std {st['waves_std']:.1f} | BEST {self.best_waves:.1f}")
        if "test_waves" in st:
            log(f"  ТЕСТ (жадно, MAPS_TEST, не учатся): {st['test_waves']:.1f} волн "
                f"(макс {st.get('test_waves_max', 0):.0f}) | "
                f"разрыв train-test {st['waves'] - st['test_waves']:+.1f}")
        log(f"  Покрытие: колод в пуле {int(st.get('deck_pool', 0))} | "
            f"за эпоху сыграно {int(st.get('decks_seen_epoch', 0))} | "
            f"лимит волн {int(st.get('max_waves_env', 0))} | "
            f"отжиг энтропии x{st.get('entropy_scale', 1.0):.2f}")
        log(f"  Эпизоды: {int(st['n_episodes'])} | победы {int(st['victories'])} | "
            f"поражения {int(st['defeats'])} | таймауты {int(st['timeouts'])} | "
            f"размеры дек: {st.get('deck_sizes')}")
        log(f"  Бой: урон {st['avg_damage']:,.0f} | киллы {st['avg_kills']:.0f} | "
            f"$ в конце {st['avg_money_end']:,.0f} | HP {st['avg_hp']:.1f} | "
            f"шагов/эпизод {st['avg_episode_len']:.0f}")
        log(f"  Стройка: башен {st['towers']:.1f} | апгрейдов {st['upgrades']:.1f} | "
            f"ср.уровень {st['avg_tower_level']:.2f}")
        log(f"  Действия: build {st['build_pct']:.1f} | upgrade {st['upgrade_pct']:.1f} | "
            f"sell {st['sell_pct']:.2f} | idle {st['idle_pct']:.1f} | "
            f"доля апгрейдов {st['upgrade_ratio'] * 100:.1f}%")
        log(f"  PPO: L_pi {st.get('loss_pi', 0):.4f} | L_v {st.get('loss_v', 0):.4f} | "
            f"L_q {st.get('loss_quantile', 0):.4f} | L_aux {st.get('loss_aux', 0):.4f} | "
            f"L_credit {st.get('loss_credit', 0):.4f}")
        log(f"  Головы: L_surv {st.get('loss_aux_survival', 0):.4f} | "
            f"L_money {st.get('loss_aux_money', 0):.4f} | "
            f"L_kills {st.get('loss_aux_kills', 0):.4f}")
        log(f"  Энтропия: {st.get('entropy', 0):.3f} "
            f"(type {st.get('entropy_type', 0):.3f} / "
            f"slot {st.get('entropy_slot', 0):.3f} / "
            f"node {st.get('entropy_node', 0):.3f})")
        log(f"  KL {st.get('approx_kl', 0):.5f} | clipfrac {st.get('clipfrac', 0):.3f} "
            f"(type {st.get('clipfrac_type', 0):.2f} / "
            f"slot {st.get('clipfrac_slot', 0):.2f} / "
            f"node {st.get('clipfrac_node', 0):.2f})")
        log(f"  PopArt: mu {st.get('popart_mu', 0):.2f} | "
            f"sigma {st.get('popart_sigma', 0):.2f} | "
            f"IQN spread {st.get('quantile_spread', 0):.2f}")
        log(f"  Aux: survival acc {st.get('survival_acc', 0) * 100:.1f}% | "
            f"money MAE {st.get('money_mae', 0):.3f} | "
            f"kills MAE {st.get('kills_mae', 0):.3f}")
        log(f"  Буфер: {len(buffer)} сегментов, {buffer.total_steps():,} шагов | "
            f"LR {lr:.2e} | эпоха {epoch_time:.0f}с "
            f"({buffer.total_steps() / max(1e-6, epoch_time):.0f} шагов/с)")
        log(rule("-"))
        for line in self._deck_lines():
            log(line)
        # три уровня ширины таблицы: строка никогда не переносится
        width = self._term_width()
        wide = width >= 136
        test = st.get("test_waves")
        test_cell = f"{test:5.1f}" if test is not None else "    -"
        if not self._table_header:
            log("")
            log("  ЭПОХА | НАГРАДА | ВОЛНЫ | TEST  | БАШНИ | АПГР | УРОН      | "
                "KILLS | $      | ENT  | L_pi    | L_v     | L_q     | SEG | "
                "SPS | ВРЕМЯ" if wide else
                ("  ЭПОХА | ВОЛНЫ | TEST  | БАШНИ | УРОН      | KILLS | ENT  | "
                 "L_pi    | SPS" if width >= 80 else
                 "  ЭПОХА | ВОЛНЫ | БАШНИ | УРОН      | SPS"))
            self._table_header = True
        sps = buffer.total_steps() / max(1e-6, epoch_time)
        if wide:
            log(f"  {epoch + 1:5d} | {st['rewards']:7.0f} | {st['waves']:5.1f} | "
                f"{test_cell} | {st['towers']:5.1f} | {st['upgrades']:4.0f} | "
                f"{st['avg_damage']:9,.0f} | {st['avg_kills']:5.0f} | "
                f"{st['avg_money_end']:6.0f} | {st.get('entropy', 0):4.2f} | "
                f"{st.get('loss_pi', 0):7.4f} | {st.get('loss_v', 0):7.3f} | "
                f"{st.get('loss_quantile', 0):7.3f} | {len(buffer):3d} | "
                f"{sps:3.0f} | {self._fmt_eta(epoch_time)}")
        elif width >= 80:
            log(f"  {epoch + 1:5d} | {st['waves']:5.1f} | {test_cell} | "
                f"{st['towers']:5.1f} | {st['avg_damage']:9,.0f} | "
                f"{st['avg_kills']:5.0f} | {st.get('entropy', 0):4.2f} | "
                f"{st.get('loss_pi', 0):7.4f} | {sps:3.0f}")
        else:
            log(f"  {epoch + 1:5d} | {st['waves']:5.1f} | {st['towers']:5.1f} | "
                f"{st['avg_damage']:9,.0f} | {sps:3.0f}")
        if episodes:
            self._detail_report(episodes, st, epoch, epoch_time, collect_time,
                                buffer, lr)

    # ---------------------------------------------------------------- train
    def train(self) -> Dict:
        c = self.cfg
        torch.manual_seed(c.seed)
        np.random.seed(c.seed)
        random.seed(c.seed)

        self.log(rule("="))
        self.log("TD RL: GNN + PathAware + GTrXL + DeckAttention + Sequence PPO "
                 "(переписано с нуля)")
        self.log(f"  device={self.device} | envs={c.num_envs} | "
                 f"segment={c.segment_length} | эпизодов/эпоху={c.episodes_per_epoch}")
        self.log(f"  карты TRAIN (фиксированные): {list(self.maps_train.keys())}")
        self.log(f"  карты TEST (в обучении НЕ используются): {list(self.maps_test.keys())}")
        self.log(f"  enable_sell={c.enable_sell} (при False SELL маскируется -1e9)")
        self.log(f"  дека: {c.deck_size_range[0]}..{c.deck_size_range[1]} слотов "
                 f"(архитектура общая для 1..8)")
        params = sum(p.numel() for p in self.policy.parameters())
        self.log(f"  параметров модели: {params:,} "
                 f"({params * 4 / 1024 / 1024:.1f} MB fp32) | "
                 f"hidden={c.hidden_dim} gnn={c.gnn_layers} "
                 f"tf={c.transformer_layers} heads={c.n_heads} q={c.n_quantiles}")
        self.log(f"  PPO: minibatch={c.ppo.minibatch_segments} сегм. | "
                 f"train_iters={c.ppo.train_iters} | clip={c.ppo.clip_eps} | "
                 f"gamma={c.gamma} lam={c.lam}")
        self.log(f"  LR: {c.lr:.2e} -> {c.lr * c.lr_final_frac:.2e} "
                 f"(warmup {c.lr_warmup_steps}) | энтропия по головам "
                 f"(type {c.ppo.entropy_type} / slot {c.ppo.entropy_slot} / "
                 f"node {c.ppo.entropy_node}), отжиг до "
                 f"{c.entropy_scale_final:.2f}")
        self.log(f"  AMP={c.amp} | compile={'вкл' if self.compiled else 'выкл'} | "
                 f"макро-IDLE={'вкл' if c.macro_idle else 'выкл'} | "
                 f"колод в пуле: {len(self._deck_pool)} "
                 f"(стратификация: колоды={'вкл' if c.stratified_decks else 'выкл'}, "
                 f"карты={'вкл' if c.stratified_maps else 'выкл'}, "
                 f"трудных {c.hard_deck_frac * 100:.0f}%)")
        self.log(f"  лимит волн: {self._wave_limit(self.start_epoch)}"
                 + (f" -> {int(c.max_waves)} за {c.wave_curriculum_epochs} эпох"
                    if c.wave_curriculum else " (фиксированный)")
                 + f" | таймаут-награда {c.timeout_reward:+.1f} | "
                 f"шейпинг x{c.shaping_scale}")
        self.log(f"  TEST-оценка: {'вкл' if c.eval_test else 'выкл'} "
                 f"({len(self.maps_test)} карт x {c.eval_test_games} игр, жадно)")
        self.log(f"  лог-файл: {self.log.path}")
        self.log(rule("="))

        self._vec = self._handle()(self._env_fns(
            [c.seed * 1000 + i for i in range(c.num_envs)]))
        self._warmup_compile()
        try:
            for epoch in range(self.start_epoch, c.num_epochs):
                epoch_start = time.time()

                self._apply_wave_curriculum(epoch)

                collected = self._collect_epoch(epoch)
                buffer = collected["buffer"]
                episodes = collected["episodes"]
                if len(buffer) == 0:
                    self.log("[WARN] пустой буфер — эпоха пропущена")
                    continue

                segments = buffer.get_all_segments()
                stats = sequence_ppo_update(
                    self.policy, self.optimizer, segments, c.segment_length,
                    self.device, c.ppo, scaler=self.scaler, log_fn=self.log,
                    entropy_scale=self._entropy_scale(epoch),
                    lr_scheduler=self._lr_step, amp_dtype=self.amp_dtype)

                if self._lr_total_steps is None and stats.get("n_updates"):
                    self._lr_total_steps = int(max(
                        1, stats["n_updates"] * max(1, c.num_epochs)))
                    self.log(f"  [LR] всего ~{self._lr_total_steps} обновлений "
                             f"за {c.num_epochs} эпох")

                epoch_time = time.time() - epoch_start
                st = self._epoch_stats(episodes, stats)
                st["collect_time"] = float(collected["collect_time"])
                st["epoch_time"] = float(epoch_time)
                st["max_waves_env"] = float(self._cur_max_waves)
                st["entropy_scale"] = float(self._entropy_scale(epoch))
                st["deck_pool"] = float(len(self._deck_pool))
                st["decks_seen_epoch"] = float(len({
                    tuple(sorted({int(t) for t in e["deck"]})) for e in episodes}))
                self._update_deck_waves(episodes)
                if c.eval_test:
                    test = self._eval_test(epoch)
                    if "waves" in test:
                        st["test_waves"] = float(test["waves"])
                        st["test_waves_max"] = float(test.get("waves_max", 0.0))
                        self._last_test = test
                st["_pairs"] = self._pair_stats(episodes)
                deck_stats = self._deck_map_stats(episodes)
                self._update_totals(deck_stats)
                self._h("deck_history").append(
                    {n: d["waves_mean"] for n, d in deck_stats["decks"].items()})
                self._h("map_history").append(dict(deck_stats["maps"]))
                self._h("tower_usage").append(dict(deck_stats["towers"]))
                self._h("towers_used").append(float(len(self.tower_totals)))
                self._h("maps_used").append(float(len(self.map_totals)))

                lr = self.optimizer.param_groups[0]["lr"]
                stage_changed = self.curriculum.update(st["waves"])
                self._append_history(dict(st), epoch, epoch_time, buffer, lr)
                self._print_epoch(epoch, st, epoch_time, buffer, lr,
                                  episodes=episodes,
                                  collect_time=collected["collect_time"])

                if stage_changed:
                    self.log(f"[CURRICULUM] стадия {self.curriculum.stage}: "
                             f"{self.curriculum.current['name']} "
                             f"(цель {self.curriculum.current['target_waves']:.0f} волн)")
                    # на новой стадии меняется набор разрешённых башен -> пул колод
                    self._deck_pool = self._build_deck_pool()
                    self._deck_by_key = {tuple(int(t) for t in d): d
                                         for d in self._deck_pool}
                    self._deck_queue = []
                    self.log(f"  пул колод пересобран: {len(self._deck_pool)} шт.")

                if st["waves"] > self.best_waves:
                    self.best_waves = st["waves"]
                    self.save_checkpoint(
                        os.path.join(c.checkpoint_dir, "best.pth"), epoch + 1)
                    self.log(f"  ★ новый рекорд: {self.best_waves:.1f} волн")
                self.save_checkpoint(
                    os.path.join(c.checkpoint_dir, "last.pth"), epoch + 1)

                if (epoch + 1) % max(1, c.plot_every) == 0:
                    try:
                        path = plot_progress(self.history, epoch + 1, c.plot_dir)
                        plot_waves_histogram([e["waves"] for e in episodes],
                                             epoch + 1, c.plot_dir)
                        plot_deck_ranking(self._ranked_decks(), self.tower_totals,
                                          self.map_totals, epoch + 1, c.plot_dir)
                        if path:
                            self.log(f"  [PLOT] {path}")
                    except Exception as exc:  # графики не должны ронять обучение
                        self.log(f"[WARN] графики не построены: {exc}")

                self._write_history_json()
                self._write_deck_report()
                self.log(f"[CKPT] epoch={epoch + 1} best={self.best_waves:.1f} "
                         f"stage={self.curriculum.stage}")
        except BaseException as exc:      # noqa: BLE001
            self._crashed = True
            self.log(rule("="))
            self.log(f"ОБУЧЕНИЕ ПРЕРВАНО ОШИБКОЙ: {type(exc).__name__}: {exc}")
            self.log("last.pth сохранён — после исправления запустите ту же команду, "
                     "обучение продолжится с этой эпохи")
            self.log(rule("="))
            raise
        finally:
            if self._vec is not None:
                try:
                    self._vec.close()
                except Exception:
                    pass
                self._vec = None
            try:
                self.save_checkpoint(
                    os.path.join(c.checkpoint_dir, "final.pth"),
                    len(self.history.get("waves", [])))
            except Exception as exc:
                self.log(f"[WARN] финальный чекпоинт не сохранён: {exc}")
            self.log(rule("="))
            if getattr(self, "_crashed", False):
                self.log("Обучение остановлено. Последний чекпоинт: "
                         f"{os.path.join(self.cfg.checkpoint_dir, 'last.pth')}")
            else:
                self.log(f"Обучение завершено. Лучший результат: "
                         f"{self.best_waves:.1f} волн")
            self.log(rule("="))
            self.log.close()
        return self.history

    def _write_deck_report(self):
        """Полный отчёт по колодам/картам/башням (logs/decks.json)."""
        path = os.path.join(self.cfg.log_dir, "decks.json")
        rows = self._ranked_decks()
        payload = {
            "ranking": [{"deck": name, **{k: float(v) for k, v in d.items()}}
                        for name, d in rows],
            "towers_built": {k: float(v) for k, v in self.tower_totals.items()},
            "maps": {k: {"n": float(v["n"]),
                         "waves_mean": float(v["waves"] / max(1.0, v["n"]))}
                     for k, v in self.map_totals.items()},
            "episodes": float(self.total_episodes),
        }
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=1, default=float)

    def _write_history_json(self):
        path = os.path.join(self.cfg.log_dir, "history.json")

        def clean(v):
            if isinstance(v, (np.floating, np.integer)):
                return float(v)
            if isinstance(v, dict):
                return {k: clean(x) for k, x in v.items()}
            if isinstance(v, (list, tuple)):
                return [clean(x) for x in v]
            return v

        payload = {}
        for k, v in self.history.items():
            payload[k] = clean(v[-100:] if k == "pair_history" else v)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=1)

