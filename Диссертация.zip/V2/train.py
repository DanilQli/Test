#!/usr/bin/env python
"""
Точка входа обучения.

Примеры:
    python train.py                       # ДЕФОЛТ: prod (12.6M параметров), envs=8,
                                          # 300 игр/эпоху, авто-дообучение
    python train.py --smoke               # быстрый прогон (проверка работоспособности)
    python train.py --resume checkpoints/last.pth --epochs 300
    python train.py --deck 1 8 --sell     # дека 1..8 слотов + разрешить SELL
"""
from __future__ import annotations

import argparse
import multiprocessing as mp
import os

import torch

from tdai.ppo import PPOConfig
from tdai.trainer import TrainConfig, Trainer


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="TD RL training (GNN + GTrXL + Sequence PPO)")
    p.add_argument("--epochs", type=int, default=100)
    p.add_argument("--envs", type=int, default=8,
                   help="параллельных игр; больше = меньше накладных расходов на шаг")
    p.add_argument("--segment", type=int, default=32, help="длина сегмента буфера (32)")
    p.add_argument("--episodes-per-epoch", type=int, default=300,
                   help="сколько игр (эпизодов) собирать за одну эпоху")
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--gamma", type=float, default=0.995)
    p.add_argument("--lam", type=float, default=0.99,
                   help="lambda GAE; при segment=32 нужно >=0.99")
    p.add_argument("--lr-warmup-steps", type=int, default=2000)
    p.add_argument("--lr-final-frac", type=float, default=0.3,
                   help="cosine-расписание: LR падает до lr*frac")
    p.add_argument("--hidden-dim", type=int, default=256,
                   help="ширина сети; кратна 16 и n_heads (256 = 6.75M параметров)")
    p.add_argument("--gnn-layers", type=int, default=4)
    p.add_argument("--transformer-layers", type=int, default=4)
    p.add_argument("--n-heads", type=int, default=8)
    p.add_argument("--n-quantiles", type=int, default=16)
    p.add_argument("--mem-len", type=int, default=256)
    p.add_argument("--deck", type=int, nargs=2, default=[4, 4],
                   metavar=("MIN", "MAX"), help="диапазон размера деки 1..8")
    p.add_argument("--sell", action="store_true", help="разрешить действие SELL")
    p.add_argument("--games-per-map", type=int, default=2)
    p.add_argument("--max-waves", type=int, default=80)
    p.add_argument("--start-money", type=float, default=500.0)
    p.add_argument("--difficulty", type=float, default=1.0)
    p.add_argument("--device", type=str, default="auto")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--resume", type=str, default=None,
                   help="явный чекпоинт для продолжения обучения")
    p.add_argument("--auto-resume", action="store_true", default=True,
                   help="ВКЛЮЧЕНО ПО УМОЛЧАНИЮ: продолжить с "
                        "<workdir>/checkpoints/last.pth, если файл есть")
    p.add_argument("--no-auto-resume", action="store_false", dest="auto_resume",
                   help="начать обучение с нуля, даже если чекпоинт найден")
    p.add_argument("--no-subproc", action="store_true", default=True,
                   help="ВКЛЮЧЕНО ПО УМОЛЧАНИЮ: все среды в одном процессе "
                        "(стабильнее в песочнице)")
    p.add_argument("--subproc", action="store_false", dest="no_subproc",
                   help="включить отдельные процессы под среды")
    p.add_argument("--no-curriculum", action="store_true", default=True,
                   help="ВКЛЮЧЕНО ПО УМОЛЧАНИЮ: сразу все карты и все 12 башен")
    p.add_argument("--curriculum", action="store_false", dest="no_curriculum",
                   help="включить поэтапное обучение (сначала 1 карта / 4 башни)")
    p.add_argument("--train-iters", type=int, default=2)
    p.add_argument("--minibatch-segments", type=int, default=8,
                   help="сегментов в минибатче (8 = 256 шагов на обновление)")
    p.add_argument("--entropy-type", type=float, default=0.005)
    p.add_argument("--entropy-slot", type=float, default=0.005)
    p.add_argument("--entropy-node", type=float, default=0.02)
    p.add_argument("--entropy-final-frac", type=float, default=0.25,
                   help="отжиг энтропии к концу обучения")
    p.add_argument("--shaping-scale", type=float, default=0.3,
                   help="масштаб эвристического шейпинга награды (1.0 = как раньше)")
    p.add_argument("--timeout-reward", type=float, default=0.0,
                   help="награда за обрыв эпизода по лимиту шагов (было +2.0)")
    p.add_argument("--hard-deck-frac", type=float, default=0.5,
                   help="доля эпизодов на худших колодах (0 = только равномерно)")
    p.add_argument("--no-stratified-decks", action="store_false", dest="stratified_decks",
                   help="выключить обход всех колод по кругу")
    p.add_argument("--no-stratified-maps", action="store_false", dest="stratified_maps",
                   help="выключить round-robin по картам")
    p.add_argument("--no-macro-idle", action="store_false", dest="macro_idle",
                   help="выключить схлопывание бесполезных IDLE-тиков")
    p.add_argument("--wave-curriculum", action="store_true", dest="wave_curriculum",
                   help="ВЫКЛЮЧЕНО ПО УМОЛЧАНИЮ: растить лимит волн постепенно "
                        "(wave-curriculum-start -> max-waves). По умолчанию сразу "
                        "все max-waves, как в игре")
    p.add_argument("--no-wave-curriculum", action="store_false", dest="wave_curriculum",
                   help="(оставлено для совместимости; это и так дефолт)")
    p.add_argument("--wave-curriculum-epochs", type=int, default=30)
    p.add_argument("--wave-curriculum-start", type=int, default=20)
    p.add_argument("--no-eval-test", action="store_false", dest="eval_test",
                   help="не оценивать на MAPS_TEST каждую эпоху")
    p.add_argument("--eval-test-games", type=int, default=1)
    p.add_argument("--amp", choices=["off", "bf16", "fp16"], default="bf16",
                   help="autocast на CUDA (bf16 — рекомендуемый)")
    p.add_argument("--compile", action="store_true",
                   help="torch.compile (ускоряет шаг; на Windows нужен MSVC)")
    p.add_argument("--obs-fp16", action="store_true",
                   help="хранить признаки узлов в буфере как fp16 (меньше RAM)")
    p.add_argument("--workdir", type=str, default="runs/prod",
                   help="куда писать logs/checkpoints/plots (например runs/prod)")
    p.add_argument("--preset", choices=["default", "prod", "big", "fast"], default="prod",
                   help="prod = как в игре: дека ровно 4 слота, случайные башни, "
                        "все карты и все 12 башен, уровни 1..9; fast = дешёвый CPU-прогон")
    p.add_argument("--progress-every", type=int, default=0,
                   help="0 (по умолчанию) — только живая строка; N — каждые N игр "
                        "писать отдельную строку в лог-файл")
    p.add_argument("--no-progress", action="store_true",
                   help="не печатать живую строку прогресса по играм")
    p.add_argument("--no-detail", action="store_true",
                   help="печатать только компактную таблицу эпохи (без блоков)")
    p.add_argument("--smoke", action="store_true", help="крошечный прогон для проверки")
    defaults = {a.dest: a.default for a in p._actions}
    return apply_preset(p.parse_args(argv), defaults)


# Пресеты: применяются ТОЛЬКО к тем ручкам, которые не заданы явно в командной строке.
PRESETS = {
    "default": {},
    # «как в моей игре»: колода ровно 4 слота, башни случайные из всех 12, все карты,
    # апгрейды 1->9, старт 500 золота / 10 HP, SELL выключен.
    # Размер сети — бюджетный: влезает в 2 ГБ RAM (песочница).
    "prod": dict(deck=[4, 4], no_curriculum=True, episodes_per_epoch=300, envs=8,
                 segment=32, games_per_map=2, max_waves=80,
                 hidden_dim=256, gnn_layers=4, transformer_layers=4,
                 n_heads=8, n_quantiles=16, train_iters=2, minibatch_segments=8),
    # та же игра, но сеть ещё больше (GPU-класс): нужно >= 8 ГБ VRAM
    "big": dict(deck=[4, 4], no_curriculum=True, episodes_per_epoch=512, envs=12,
                segment=32, games_per_map=2, max_waves=80,
                hidden_dim=512, gnn_layers=5, transformer_layers=5,
                n_heads=8, n_quantiles=32, train_iters=3, minibatch_segments=8),
    # дешёвый вариант для слабого CPU: быстро крутится, годится для проверок
    "fast": dict(deck=[4, 4], no_curriculum=True, episodes_per_epoch=12, envs=2,
                 segment=32, games_per_map=2, max_waves=60,
                 hidden_dim=96, gnn_layers=2, transformer_layers=2,
                 n_heads=4, n_quantiles=8, train_iters=1, minibatch_segments=8),
}


def apply_preset(args: argparse.Namespace, defaults: dict) -> argparse.Namespace:
    """Накатывает пресет на аргументы, которые пользователь не задавал сам."""
    for key, value in PRESETS.get(args.preset, {}).items():
        if getattr(args, key) == defaults[key]:
            setattr(args, key, value)
    return args


def build_config(args: argparse.Namespace) -> TrainConfig:
    if args.smoke:
        return TrainConfig(
            num_epochs=2, num_envs=2, segment_length=16, episodes_per_epoch=4,
            max_steps_per_episode=200, lr=3e-4,
            deck_size_range=(2, 4), games_per_map=2,
            hidden_dim=64, gnn_layers=2, transformer_layers=2, n_heads=4,
            n_quantiles=8, mem_len=64, plot_every=1,
            ppo=PPOConfig(train_iters=1, minibatch_segments=2),
            use_subprocess_envs=False, log_dir="logs_smoke",
            checkpoint_dir="checkpoints_smoke", plot_dir="plots_smoke",
            auto_resume=False,   # smoke всегда с нуля
            eval_test=False, wave_curriculum=False, macro_idle=False,
            amp="off", shaping_scale=1.0,
        )
    wd = args.workdir
    dirs = ({} if wd in (".", "") else
            {"log_dir": os.path.join(wd, "logs"),
             "checkpoint_dir": os.path.join(wd, "checkpoints"),
             "plot_dir": os.path.join(wd, "plots")})
    return TrainConfig(
        num_epochs=args.epochs, **dirs, num_envs=args.envs, segment_length=args.segment,
        episodes_per_epoch=args.episodes_per_epoch, lr=args.lr,
        gamma=args.gamma, lam=args.lam,
        lr_warmup_steps=args.lr_warmup_steps, lr_final_frac=args.lr_final_frac,
        amp=args.amp, compile_model=args.compile, obs_fp16=args.obs_fp16,
        stratified_decks=args.stratified_decks,
        stratified_maps=args.stratified_maps,
        hard_deck_frac=args.hard_deck_frac,
        eval_test=args.eval_test, eval_test_games=args.eval_test_games,
        macro_idle=args.macro_idle,
        wave_curriculum=args.wave_curriculum,
        wave_curriculum_epochs=args.wave_curriculum_epochs,
        wave_curriculum_start=args.wave_curriculum_start,
        timeout_reward=args.timeout_reward,
        shaping_scale=args.shaping_scale,
        entropy_scale_final=args.entropy_final_frac,
        deck_size_range=(args.deck[0], args.deck[1]),
        games_per_map=args.games_per_map, max_waves=args.max_waves,
        starting_money=args.start_money, difficulty=args.difficulty,
        enable_sell=args.sell,
        hidden_dim=args.hidden_dim, gnn_layers=args.gnn_layers,
        transformer_layers=args.transformer_layers, n_heads=args.n_heads,
        n_quantiles=args.n_quantiles, mem_len=args.mem_len,
        ppo=PPOConfig(train_iters=args.train_iters,
                      minibatch_segments=args.minibatch_segments,
                      entropy_type=args.entropy_type,
                      entropy_slot=args.entropy_slot,
                      entropy_node=args.entropy_node),
        device=args.device, seed=args.seed, resume_from=args.resume,
        auto_resume=args.auto_resume,
        use_subprocess_envs=not args.no_subproc,
        use_curriculum=not args.no_curriculum,
        progress=not args.no_progress,
        progress_every=args.progress_every,
        detailed_report=not args.no_detail,
    )


def main():
    args = parse_args()
    cfg = build_config(args)

    if torch.cuda.is_available():
        torch.set_float32_matmul_precision("high")
        torch.backends.cudnn.benchmark = True

    trainer = Trainer(cfg)
    trainer.train()


if __name__ == "__main__":
    mp.set_start_method("spawn", force=True)
    main()
